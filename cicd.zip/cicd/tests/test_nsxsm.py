from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel
import unittest
import json
import yaml
import tempfile
from time import sleep
from unittest import mock
from kubernetes.client.rest import ApiException
from kubernetes import client, config
from flashpkg.infra import cluster
from flashpkg.nsxsm import (
    install_allspark,
    uninstall_allspark,
    install_tenant_cluster,
    install_tenant,
    init_tenant_cluster,
    deinit_tenant_cluster,
    list_clusters,
    upgrade_operator,
    install_tenant,
    generate_runtime_config,
    install_tenants,
    process_list_tenants,
    batch_upgrade_tenants
)
from flashpkg import nsxsmOps
from flashpkg.allspark_api import AllsparkApi
from flashpkg.infra import saas
from flashpkg.aws.dynamodb.services.cluster_pool.cp_service import CPService

class MockResponse:
    def __init__(self, json_data, text_data, status_code):
        self.json_data = json_data
        self.text_data = text_data
        self.status_code = status_code

    def json(self):
        return self.json_data

    def text(self):
        return self.text


class MockConfigMapMetadata():
    def __init__(self, name):
        self.name = name


class MockConfigMap():
    def __init__(self, data, name):
        self.metadata = MockConfigMapMetadata(name)
        self.data = data


class MockConfigMapList():
    def __init__(self, cfgmap_list):
        self.items = cfgmap_list


class TestNSXSM(unittest.TestCase):

    TSM_PRE_UPGRADE_VERSION = "v1.2.14"
    TSM_POST_UPGRADE_VERSION = "v1.2.15"
    TEST_TENANTS = 3
    PARALLEL_TENANT_UPGRADE = 3

    @classmethod
    def setUpClass(cls):
        cls.flavor = "kops_large"
        cls.pool_name = 'flash-cluster-pool'
        flavor = 'kops_medium'
        region = None
        zones = False
        cloud = False
        multi_master = False
        no_iam = False
        save_config = None
        logging_format = None
        dry_run = False

        service = CPService()
        exit_code, cls.cluster_name = service.create_in_pool(cls.pool_name,
                                                             flavor,
                                                             region,
                                                             zones,
                                                             cloud,
                                                             multi_master,
                                                             no_iam,
                                                             save_config,
                                                             logging_format,
                                                             dry_run)

        # FIXME: don't mix exit codes with exceptions at the same layer.
        if exit_code != 0:
            raise Exception(f"Exit code {exit_code} is not zero")

        cls.ingress_dns = cls.cluster_name + "-ingress.servicemesh.biz"
        cls.api_dns = cls.cluster_name + "-api.servicemesh.biz"
        cls.saas_cluster = mock.Mock()

    @classmethod
    def tearDownClass(cls):
        service = CPService()
        service.release(cls.pool_name, cls.cluster_name)

    def test_logbundle_success(self):
        self.assertEqual(nsxsmOps.collect_logbundle(
            self.cluster_name, self.cluster_name + '.k8s.local'), 0)

    def mocked_cluster_state(*args, **kwargs):
        cluster = mock.MagicMock()
        if 'type' in kwargs.keys():
            cluster_type = kwargs['type']
        else:
            cluster_type = 'kops'
        cluster = {'cluster_name': 'dummy-cluster', 'type': cluster_type, 'flavor': 'kops_medium',
                   'tenants': [{"tenant_name": "dummy-tenant", "tenant_id": "dummy_id", "username": "dummy-user"}]}
        return cluster

    def mock_tsm_api_setup(*args, **kwargs):
        return AllsparkApi('dummy-gw')

    def mocked_register_tenant(*args, **kwargs):
        # Tenant name
        assert args[0] == 'prefix01'
        # Tenant email
        assert args[1] == 'prefix01@'
        # Tenant address
        assert args[2] == 'test'
        # Tenant company size
        assert args[3] == 'test'
        # Verify async API is being invoked
        assert args[4] is True
        r = MockResponse({"Error": "Mocked register tenant response"}, "Mocked register tenant failure", 500)
        return r

    def mocked_register_tenant_email(*args, **kwargs):
        # Tenant name
        assert args[0] == 'prefix-g01'
        # Tenant email
        assert args[1] == 'prefix-g01@'
        # Tenant address
        assert args[2] == 'test'
        # Tenant company size
        assert args[3] == 'test'
        # Verify async API is being invoked
        assert args[4] is True
        r = MockResponse({"Error": "Mocked register tenant response"}, "Mocked register tenant failure", 500)
        return r

    def mocked_istio(*args, **kwargs):
        print("args:", args, ", kwargs:", kwargs)
        # Operation
        assert args[0] == 'install'
        # Client cluster name
        assert args[1] == 'dummy-cluster'
        r = MockResponse({"Error": "Mocked istio response"}, "Mocked istio (un)install failure", 400)
        return r

    def mocked_config_map(*args, **kwargs):
        cfg_data = [MockConfigMap(json.loads(
            '{".allsparkconf": "services:\\n  local:\\n    k8sConnector:\\n      clusterName: dummy-cluster\\n      clusterNameHash: abcd1234\\n"}'), 'k8s-connector-abcd1234')]
        return MockConfigMapList(cfg_data)

    def mocked_malformed_config_map(*args, **kwargs):
        cfg_data = [MockConfigMap(json.loads(
            '{".allsparkconf": "services: \\n  local: \\n    clusterName: dummy-cluster\\n    clusterNameHash: abcd1234\\n"}'), 'k8s-connector-abcd1234')]
        return MockConfigMapList(cfg_data)

    def test_install_non_existent_cluster(self):
        args = {
            "<nsxsm_version>": self.TSM_POST_UPGRADE_VERSION,
            "<cluster_name>": "non-existent-cluster",
            "<ingress_dns>": self.ingress_dns,
            "<api_dns>": self.api_dns,
            "--production": False
        }
        with self.assertRaises(Exception):
            install_allspark(args)

    def mocked_invalid_cluster_type(*args, **kwargs):
        return 1

    def mocked_logbundle_success(*args, **kwargs):
        return 0

    def mocked_logbundle_failure(*args, **kwargs):
        return 1

    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state(type="cpks"))
    def test_install_invalid_saas_cluster_type(self, mock_request):
        args = {
            "<nsxsm_version>": self.TSM_POST_UPGRADE_VERSION,
            "<cluster_name>": self.cluster_name,
            "<ingress_dns>": self.ingress_dns,
            "<api_dns>": self.api_dns,
            "--production": False
        }
        with self.assertRaises(Exception):
            install_allspark(args)

    @mock.patch("flashpkg.nsxsmOps.validate_cluster_type", side_effect=mocked_invalid_cluster_type)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_install_invalid_client_cluster_type(self, mock_request, mock_cluster):
        args = {
            "<tenant_name>": "dummy-tenant",
            "<saas_cluster_name>": "dummy-cluster",
            "<client_cluster_name>": "dummy-cluster",
            "<username>": "dummy-user",
            "--password": "password",
            "--eks": False,
            "--use-board-api": True
        }
        self.assertEqual(install_tenant_cluster(args), 1)

    def test_1_install_allspark(self):
        args = {
            "<nsxsm_version>": self.TSM_PRE_UPGRADE_VERSION,
            "<cluster_name>": self.cluster_name,
            "<ingress_dns>": self.ingress_dns,
            "<api_dns>": self.api_dns,
            "--production": False,
            "--eks": False
        }

        self.assertEqual(install_allspark(args), 0)

    def test_2_install_tenant(self):
        for i in range(self.TEST_TENANTS):
            args = {
                "<saas_cluster_name>": self.cluster_name,
                "<tenant_name>": "tenant-" + str(i),
                "--password": "tenant",
                "--username": "tenant-" + str(i),
                "--no-failure-rollback": False,
                "--eks": False,
                "--logging-format": False
            }

            exit_code, tenant_id = install_tenant(args)

            self.assertEqual(exit_code, 0)

    def test_3_upgrade_allspark(self):
        runtime_conf = generate_runtime_config(self.ingress_dns, self.api_dns, True)
        fd, runtime_conf_file = tempfile.mkstemp()
        with open(runtime_conf_file, 'w') as f:
            yaml.dump(runtime_conf, f)
        args = {
            "<saas_cluster_name>": self.cluster_name,
            "<tenant_id>": "allspark",
            "<nsxsm_version>": self.TSM_POST_UPGRADE_VERSION,
            "<config_file_path>": runtime_conf_file,
            "--force": False,
            "--production": False,
            "--eks": False
        }
        self.assertEqual(upgrade_operator(args), 0)

    @mock.patch("flashpkg.nsxsm.__get_tenantlist_from_file")
    def test_4_upgrade_tenants(self, mocked_tenantlist):
        args = {
            "<saas_cluster_name>": self.cluster_name,
            "<nsxsm_version>": self.TSM_POST_UPGRADE_VERSION,
            "--inventory_file": "dummy-file-tenant-list-is-mocked",
            "--batch": self.PARALLEL_TENANT_UPGRADE,
            "--force": False,
            "--eks": False,
            "--logs_dir": "tenant-upgrade-logs"
        }
        config.load_kube_config()
        api = client.CoreV1Api()
        tenant_list = [tenant.metadata.name for tenant in api.list_namespace(label_selector="component=nsxsm-tenant").items]
        mocked_tenantlist.return_value = tenant_list
        self.assertEqual(batch_upgrade_tenants(args), 0)

    def test_5_uninstall_allspark(self):
        cluster_name = self.cluster_name
        is_eks = False
        self.assertEqual(uninstall_allspark(cluster_name, is_eks), 0)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.register_tenant", side_effect=mocked_register_tenant_email)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_install_tenant_long_name(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": "name-greater-than-eight-bytes",
            "<saas_cluster_name>": "dummy-cluster",
            "--username": "username",
            "--password": "password",
            "--no-failure-rollback": False,
            "--verbose": True,
            "--eks": False,
            "--logging-format": False

        }
        exit_code, tenant_id = install_tenant(args)
        self.assertEqual(exit_code, 1)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.register_tenant", side_effect=mocked_register_tenant)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_install_tenant_failure(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": "dummy-name",
            "<saas_cluster_name>": "dummy-cluster",
            "--username": "username",
            "--password": "password",
            "--no-failure-rollback": False,
            "--verbose": True,
            "--eks": False,
            "--logging-format": False
        }
        exit_code, tenant_id = install_tenant(args)
        self.assertEqual(exit_code, 1)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.register_tenant", side_effect=mocked_register_tenant_email)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_install_tenants_long_name(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<num_tenants>": 1,
            "<tenant_name_prefix>": "prefix-greater-than-eight-bytes",
            "<saas_cluster_name>": "dummy-cluster",
            "--password": "password",
            "--no-failure-rollback": False,
            "--eks": False
        }
        self.assertEqual(install_tenants(args), 1)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.register_tenant", side_effect=mocked_register_tenant)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_install_tenants_failure(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<num_tenants>": 1,
            "<tenant_name_prefix>": "prefix",
            "<saas_cluster_name>": "dummy-cluster",
            "--password": "password",
            "--no-failure-rollback": False,
            "--verbose": True,
            "--eks": False
        }
        self.assertEqual(install_tenants(args), 1)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.istio", side_effect=mocked_istio)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_init_tenant_cluster_failure(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": "dummy-tenant",
            "<saas_cluster_name>": "dummy-cluster",
            "<client_cluster_name>": "dummy-cluster",
            "<username>": "dummy-user",
            "--password": "password",
            "--eks": False,
            "--tsm-version": "default"
        }
        self.assertEqual(init_tenant_cluster(args), 1)

    @mock.patch("flashpkg.allspark_api.AllsparkApi.istio", side_effect=mocked_istio)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_deinit_tenant_cluster_failure(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": "dummy-tenant",
            "<saas_cluster_name>": "dummy-cluster",
            "<client_cluster_name>": "dummy-cluster",
            "<username>": "dummy-user",
            "--password": "password",
            "--eks": False
        }
        self.assertEqual(deinit_tenant_cluster(args), 1)

    @mock.patch('kubernetes.client.CoreV1Api.list_namespaced_config_map')
    @mock.patch('kubernetes.config.load_kube_config')
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_list_clusters(self, mocked_config_map, mocked_kube_config, mocked_cluster_state):
        mocked_config_map.return_value = mocked_config_map()
        self.assertEqual(list_clusters('dummy-cluster', 'dummy', False), 0)

    @mock.patch('kubernetes.client.CoreV1Api.list_namespaced_config_map', side_effect=ApiException('Mocked API Exception!'))
    @mock.patch('kubernetes.config.load_kube_config')
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_list_cluster_exception(self, mocked_config_map, mocked_kube_config, mocked_cluster_state):
        self.assertEqual(list_clusters('dummy-cluster', 'dummy', False), 1)

    @mock.patch('kubernetes.client.CoreV1Api.list_namespaced_config_map', side_effect=mocked_malformed_config_map)
    @mock.patch('kubernetes.config.load_kube_config')
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_list_cluster_exception(self, mocked_config_map, mocked_kube_config, mocked_cluster_state):
        self.assertEqual(list_clusters('dummy-cluster', 'dummy', False), 0)

    @mock.patch("flashpkg.nsxsmOps.collect_logbundle", side_effect=mocked_logbundle_success)
    def test_logbundle_success(self, mocked_collect_logbundle):
        args = {
            "<saas_cluster_name>": "dummy-cluster"
        }
        self.assertEqual(nsxsmOps.collect_logbundle(args), 0)

    @mock.patch("flashpkg.nsxsmOps.collect_logbundle", side_effect=mocked_logbundle_failure)
    def test_logbundle_failure(self, mocked_collect_logbundle):
        args = {
            "<saas_cluster_name>": "dummy-cluster",
            "<namespace>": "dummy"
        }
        self.assertEqual(nsxsmOps.collect_logbundle(args), 1)

    @mock.patch("flashpkg.nsxsmOps.collect_logbundle", side_effect=mocked_logbundle_failure)
    @mock.patch('kubernetes.client.CoreV1Api.list_namespace', side_effect=ApiException('Mocked API Exception!'))
    def test_logbundle_exception(self, mocked_collect_logbundle, mock_list_namespace):
        args = {
            "<saas_cluster_name>": "dummy-cluster",
            "<namespace>": "dummy"
        }
        self.assertEqual(nsxsmOps.collect_logbundle(args), 1)

    @mock.patch("flashpkg.nsxsmOps.collect_logbundle", side_effect=mocked_logbundle_failure)
    @mock.patch('kubernetes.client.CoreV1Api.list_namespace')
    def test_logbundle_invalid_namespace(self, mocked_collect_logbundle, mock_list_namespace):
        args = {
            "<saas_cluster_name>": "dummy-cluster",
            "<namespace>": "dummy"
        }
        mock_list_namespace.return_value = []
        self.assertEqual(nsxsmOps.collect_logbundle(args), 1)

    def test_process_list_tenants_calls_saas_list_tenants(self):
        args = {
            "<saas_cluster_name>": "dummy-cluster",
        }
        with mock.patch.object(saas, 'list_tenants', return_value=None) as mocked_saas_list_tenants:
            process_list_tenants(args)
        mocked_saas_list_tenants.assert_called_once_with(args)


if __name__ == '__main__':
    unittest.main()
