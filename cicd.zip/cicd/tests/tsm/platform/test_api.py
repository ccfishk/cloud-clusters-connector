import unittest

class TestController(unittest.TestCase):
    def test_setup(self):
        pass
