from unittest import mock, TestCase
from flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin import CPClusterReleaseMixin, ToClassObject
from flashpkg.aws.dynamodb.models.cluster_model import ClusterModel, CLUSTER_POOL_ATTRIBUTE, CLUSTER_NAME_ATTRIBUTE, \
    CLUSTER_FLAVOR_ATTRIBUTE, CLUSTER_LOCKED_ATTRIBUTE, CLUSTER_REGION_ATTRIBUTE, CLUSTER_ZONES_ATTRIBUTE
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel, \
    POOL_THRESHOLD_ATTRIBUTE, POOL_NAME_ATTRIBUTE

class MockModel:
    def get_item(self, *args):
        pass

def mock_get_item_by_name(self, *args):
    return None

class TestCPClusterReleaseMixin(TestCase):
    def test__get_cluster(self):
        pool_name = "test_pool_name"
        cluster_name = "test_cluster_name"
        cluster_mock = {"name": cluster_name, "pool": pool_name}
        mixin = CPClusterReleaseMixin()

        with mock.patch.object(ClusterModel, 'get_item', return_value=cluster_mock) as mocked_cluster_model:
            cluster = mixin._CPClusterReleaseMixin__get_cluster(pool_name, cluster_name)

        mocked_cluster_model.assert_called_once_with({'name': cluster_name})

        self.assertEqual(cluster.name, cluster_name)
        self.assertEqual(cluster.pool, pool_name)

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_model.ClusterModel.get_item_by_name", side_effect=mock_get_item_by_name)
    def test__get_cluster_failed(self, mocked_cluster_model):
        pool_name = "test_pool_name"
        cluster_name = "test_cluster_name"

        mixin = CPClusterReleaseMixin()

        with self.assertRaises(Exception) as context:
            mixin._CPClusterReleaseMixin__get_cluster(pool_name, cluster_name)

        error_msg = f"Cluster `{cluster_name}` doesn't exist in pool `{pool_name}` "
        self.assertTrue(error_msg in str(context.exception))

    def test__get_pool(self):
        pool_name = "test_pool_name"
        pool_mock = {"name": pool_name}
        mixin = CPClusterReleaseMixin()

        with mock.patch.object(ClusterPoolModel, 'get', return_value=pool_mock) as mocked_pool_model:
            pool = mixin._CPClusterReleaseMixin__get_pool(pool_name)

        mocked_pool_model.assert_called_once_with(pool_name)

        self.assertEqual(pool.name, pool_name)

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.get", return_value=None)
    def test__get_pool_failed(self, mocked_pool_model):
        pool_name = "test_pool_name"

        mixin = CPClusterReleaseMixin()

        with self.assertRaises(Exception) as context:
            mixin._CPClusterReleaseMixin__get_pool(pool_name)

        print('\n\n context.exception : ', context.exception)
        error_msg = f"Cluster Pool `{pool_name}` doesn't exist "
        self.assertTrue(error_msg in str(context.exception))

    def test__get_unlocked_clusters(self):
        mixin = CPClusterReleaseMixin()
        unlocked_mock = [{"name": "test1"}, {"name": "test2"}]
        pool_name = "test_pool_name"
        flavor = "flavor_name"
        region = "us-west-2"
        zones = "us-west-2a,us-west-2b"

        with mock.patch.object(ClusterModel, 'get_all_unlocked_by_pool', return_value=unlocked_mock) as mocked_get_all_unlocked:
            unlocked_clusters = mixin._CPClusterReleaseMixin__get_unlocked_clusters(pool_name, flavor, region, zones)

        mocked_get_all_unlocked.assert_called_once_with(pool_name, flavor, region, zones)

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_model.ClusterModel.update")
    @mock.patch("flashpkg.aws.dynamodb.models.cluster_model.ClusterModel.unlock")
    @mock.patch('flashpkg.nsxsm.uninstall_allspark', return_value=0)
    def test__clean_off_and_unlock(self, mocked_nsxsm_uninstall, mocked_unlock, mocked_update):
        cluster_name = 'test_cluster_name'
        cluster = ToClassObject(**{
            'name': cluster_name,
            'nsxsm_version': 'v1.11.12'
        })

        mixin = CPClusterReleaseMixin()
        exit_code = mixin._CPClusterReleaseMixin__clean_off_and_unlock(cluster)

        self.assertEqual(exit_code, 0)

        mocked_nsxsm_uninstall.assert_called_once_with(cluster_name, True)
        mocked_unlock.assert_called_once_with(cluster_name)
        mocked_update.assert_called_once_with(cluster_name, nsxsm_version='')

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.update_cluster_names",)
    @mock.patch(
        "flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.get",
        return_value={'clusterNames': ['test_name1', 'test_name2']}
    )
    def test__remove_cluster_from_pool(self, mocked_pool_get, mocked_update_cluster_names):
        pool_name = 'test_pool_name'
        cluster_name = 'test_name2'

        mixin = CPClusterReleaseMixin()
        mixin._CPClusterReleaseMixin__remove_cluster_from_pool(pool_name, cluster_name)

        mocked_pool_get.assert_called_once_with(pool_name)
        mocked_update_cluster_names.assert_called_once_with(pool_name, ['test_name1'])


cluster_obj = ToClassObject(**{
    CLUSTER_NAME_ATTRIBUTE: 'test_name',
    CLUSTER_LOCKED_ATTRIBUTE: True,
    CLUSTER_FLAVOR_ATTRIBUTE: 'eks_small',
    CLUSTER_REGION_ATTRIBUTE: 'us-west-2',
    CLUSTER_ZONES_ATTRIBUTE: 'us-west-2a'
})

class TestCPReleaseDeleteOrUnlock(TestCase):
    def test_error_already_unlocked(self):
        pool_name = 'test_pool_name'
        cluster_name = 'test_name'
        mixin = CPClusterReleaseMixin()

        cluster = ToClassObject(**{
            CLUSTER_NAME_ATTRIBUTE: cluster_name,
            CLUSTER_POOL_ATTRIBUTE: pool_name,
            CLUSTER_LOCKED_ATTRIBUTE: False
        })

        with mock.patch.object(CPClusterReleaseMixin, '_CPClusterReleaseMixin__get_cluster', return_value=cluster) as mocked_get_all_unlocked:
            exit_status = mixin.release(pool_name, cluster_name)
        self.assertEqual(exit_status, 1)

    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__clean_off_and_unlock"
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_cluster",
        return_value=cluster_obj
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_pool",
        return_value=ToClassObject(**{
            POOL_NAME_ATTRIBUTE: 'test_pool_name',
            POOL_THRESHOLD_ATTRIBUTE: 3
        })
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_unlocked_clusters",
        return_value=[{CLUSTER_NAME_ATTRIBUTE: 'test_name2'}]
    )
    def test_1_unlock_story(self, mocked_unlocked_clusters, mocked_get_pool, mocked_get_cluster, mocked_clean_off):
        pool_name = "test_pool_name"
        cluster_name = "test_name"

        mixin = CPClusterReleaseMixin()
        mixin.release(pool_name, cluster_name)

        mocked_get_cluster.assert_called_once_with(pool_name, cluster_name)
        mocked_get_pool.assert_called_once_with(pool_name)
        mocked_unlocked_clusters.assert_called_once_with(pool_name, 'eks_small', 'us-west-2', 'us-west-2a')

        mocked_clean_off.assert_called_once_with(cluster_obj)

    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__clean_off_and_unlock"
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_cluster",
        return_value=cluster_obj
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_pool",
        return_value=ToClassObject(**{
            POOL_NAME_ATTRIBUTE: 'test_pool_name',
            POOL_THRESHOLD_ATTRIBUTE: 3
        })
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_unlocked_clusters",
        return_value=[{CLUSTER_NAME_ATTRIBUTE: 'test_name2'}, {CLUSTER_NAME_ATTRIBUTE: 'test_name3'}]
    )
    def test_2_unlock_story(self, mocked_unlocked_clusters, mocked_get_pool, mocked_get_cluster, mocked_clean_off):
        pool_name = "test_pool_name"
        cluster_name = "test_name"

        mixin = CPClusterReleaseMixin()
        mixin.release(pool_name, cluster_name)

        mocked_get_cluster.assert_called_once_with(pool_name, cluster_name)
        mocked_get_pool.assert_called_once_with(pool_name)
        mocked_unlocked_clusters.assert_called_once_with(pool_name, 'eks_small', 'us-west-2', 'us-west-2a')

        mocked_clean_off.assert_called_once_with(cluster_obj)

    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__remove_cluster"
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_cluster",
        return_value=cluster_obj
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_pool",
        return_value=ToClassObject(**{
            POOL_NAME_ATTRIBUTE: 'test_pool_name',
            POOL_THRESHOLD_ATTRIBUTE: 3
        })
    )
    @mock.patch(
        "flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin.CPClusterReleaseMixin._CPClusterReleaseMixin__get_unlocked_clusters",
        return_value=[{CLUSTER_NAME_ATTRIBUTE: 'test_name2'}, {CLUSTER_NAME_ATTRIBUTE: 'test_name3'}, {CLUSTER_NAME_ATTRIBUTE: 'test_name4'}]
    )
    def test_3_remove_story(self, mocked_unlocked_clusters, mocked_get_pool, mocked_get_cluster, mocked_remove_cluster):
        pool_name = "test_pool_name"
        cluster_name = "test_name"

        mixin = CPClusterReleaseMixin()
        mixin.release(pool_name, cluster_name)

        mocked_get_cluster.assert_called_once_with(pool_name, cluster_name)
        mocked_get_pool.assert_called_once_with(pool_name)
        mocked_unlocked_clusters.assert_called_once_with(pool_name, 'eks_small', 'us-west-2', 'us-west-2a')

        mocked_remove_cluster.assert_called_once_with('test_pool_name', 'test_name', 'eks_small', False, 'us-west-2', False)
