import unittest

from unittest import mock
from flashpkg.aws.dynamodb.services.cluster_pool_service import ClusterPoolService
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel

def mocked_cluster_pool_does_not_exist(*args):
    return None

def mocked_cluster_pool_exists(*args):
    return True

def mock_constructor(*args):
    return None


unlocked_cluster = 'free_cluster_name'

def mocked_get_unlocked_clusters(*args):
    return [unlocked_cluster]

def mocked_cluster_lock(*args):
    return True

class TestClusterPoolServicePoolExist(unittest.TestCase):
    def setUp(self):
        self.pool_name = 'test_pool_name'
        self.flavor_name = 'test_flavor_name'

        self.cloud = False
        self.multi_master = False
        self.no_iam = False

        self.region = None
        self.zones = None
        self.save_config = None
        self.json = False

        self.clusterPool = ClusterPoolService()

    def test_create_in_pool_pool_exist(self):
        pool_exists = {}

        with mock.patch.object(ClusterPoolModel, 'get', return_value=pool_exists) as mocked_model_get:
            self.clusterPool.create_in_pool(self.pool_name,
                                            self.flavor_name,
                                            self.cloud,
                                            self.multi_master,
                                            self.no_iam,
                                            self.region,
                                            self.zones,
                                            self.save_config)

        mocked_model_get.assert_called_once_with(self.pool_name)

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.get", side_effect=mocked_cluster_pool_does_not_exist)
    def test_create_in_pool_does_not_exist(self, mocked_cluster_pool_get):

        with self.assertRaises(Exception) as context:
            self.clusterPool.create_in_pool(self.pool_name,
                                            self.flavor_name,
                                            self.cloud,
                                            self.multi_master,
                                            self.no_iam,
                                            self.region,
                                            self.zones,
                                            self.save_config)

        self.assertTrue(f'Pool with the name {self.pool_name} doesn\'t exist' in str(context.exception))

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_model.ClusterModel.__init__", side_effect=mock_constructor)
    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.__init__", side_effect=mock_constructor)
    @mock.patch("flashpkg.aws.dynamodb.models.cluster_model.ClusterModel.lock", side_effect=mocked_cluster_lock)
    @mock.patch("flashpkg.aws.dynamodb.services.cluster_pool_service.ClusterPoolService.get_unlocked_clusters", side_effect=mocked_get_unlocked_clusters)
    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.ClusterPoolModel.get", side_effect=mocked_cluster_pool_exists)
    def test_create_in_pool_free_cluster_exists(self, mocked_get, mocked_unlocked, mocked_lock, mock_pool_constructor, mock_cluster_constructor):
        cluster_name = self.clusterPool.create_in_pool(self.pool_name,
                                                       self.flavor_name,
                                                       self.cloud,
                                                       self.multi_master,
                                                       self.no_iam,
                                                       self.region,
                                                       self.zones,
                                                       self.save_config,
                                                       self.json)

        mocked_get.assert_called_once_with(self.pool_name)
        mocked_unlocked.assert_called_once()
        mocked_lock.assert_called_once()

        self.assertEqual(cluster_name, unlocked_cluster)
