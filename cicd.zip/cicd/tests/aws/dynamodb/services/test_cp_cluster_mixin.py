from unittest import TestCase

class TestCPClusterMixin(TestCase):
