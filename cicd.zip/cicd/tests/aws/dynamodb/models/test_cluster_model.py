import json
from unittest import TestCase, mock
from flashpkg.aws.dynamodb.models import cluster_model

def mock_model_scan(*args, **kwargs):
    return {'Items': []}

class TestClusterModel(TestCase):
    @mock.patch('flashpkg.aws.dynamodb.models.cluster_model.Model.scan', side_effect=mock_model_scan)
    def test_get_all_unlocked_by_pool(self, mocked_model_scan):
        model = cluster_model.ClusterModel()
        response = model.get_all_unlocked_by_pool('test', 'test_flavor', 'us-west-2', 'us-west-2a')

        mocked_model_scan.assert_called_once()
