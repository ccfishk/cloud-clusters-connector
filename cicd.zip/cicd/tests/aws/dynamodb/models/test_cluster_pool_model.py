import unittest
from unittest import mock
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel, TABLE_NAME
from flashpkg.aws.dynamodb.models.model import Model

def mocked_cluster_pool_table_exists(*args):
    return True

def mocked_cluster_pool_table_does_not_exist(*args):
    return False

class MockedClient:
    def put_item(*args, **kwargs):
        return None

def mocked_boto_client(*args, **kwargs):
    return MockedClient()

class TestClusterPoolModel(unittest.TestCase):
    def test_constructor(self):
        pool = ClusterPoolModel()
        self.assertIs(pool.table_name, TABLE_NAME)

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.Model.table_exists", side_effect=mocked_cluster_pool_table_does_not_exist)
    def test_init_calls_create_table(self, mocked_table_does_not_exist):

        with mock.patch.object(Model, 'create_table', return_value=None) as mocked_create_table:
            ClusterPoolModel()

        mocked_create_table.assert_called_once()

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.Model.table_exists", side_effect=mocked_cluster_pool_table_exists)
    def test_init_does_not_create_table(self, mocked_table_exists):

        with mock.patch.object(Model, 'create_table', return_value=None) as mocked_create_table:
            ClusterPoolModel()

        mocked_create_table.assert_not_called()

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.Model.table_exists", side_effect=mocked_cluster_pool_table_exists)
    def test_upsert_pool_full(self, mocked_pool_table):
        name = 'test_name3'
        free_threshold = '60'
        recycle_time = '10'
        cluster_names = []

        with mock.patch.object(Model, 'put_item', return_value=None) as mocked_put_item:
            pool = ClusterPoolModel()
            pool.upsert(
                name=name,
                free_threshold=free_threshold,
                recycle_time=recycle_time,
                cluster_names=cluster_names
            )

        mocked_put_item.assert_called_once_with(
            {'name': name, 'freeThreshold': free_threshold, 'recycleTime': recycle_time, 'clusterNames': []}
        )

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.Model.table_exists", side_effect=mocked_cluster_pool_table_exists)
    def test_upsert_pool_only_cluster_names(self, mocked_pool_table):
        name = 'test_name3'
        cluster_names = ['test_cluster1', 'test_cluster2']

        with mock.patch.object(Model, 'put_item', return_value=None) as mocked_put_item:
            pool = ClusterPoolModel()
            pool.upsert(
                name=name,
                cluster_names=cluster_names
            )

        mocked_put_item.assert_called_once_with(
            {'name': name, 'clusterNames': cluster_names}
        )

    @mock.patch("flashpkg.aws.dynamodb.models.cluster_pool_model.Model.table_exists", side_effect=mocked_cluster_pool_table_exists)
    def test_get(self, mocked_cluster_pool_table_exists):
        pool_name = 'test_name_3'

        with mock.patch.object(Model, 'get_item', return_value={}) as mocked_get_item:
            model = ClusterPoolModel()
            model.get(pool_name)

        mocked_get_item.assert_called_once_with({'name': pool_name})


if __name__ == '__main__':
    unittest.main()
