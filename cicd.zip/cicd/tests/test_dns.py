import unittest
from unittest import mock
from flashpkg.aws.dns import get_cname_info

class TestDNS(unittest.TestCase):

    record_sets =  [{
        "Name": "foo.",
        "Type": "CNAME"
    }, {
        "Name": "*.foo.",
        "Type": "CNAME"
    }, {
        "Name": "\\052.bar.",
        "Type": "CNAME"
    }]

    def mock_list_resource_record_sets(zoneId, record_type=None, output=False):
        return TestDNS.record_sets

    @mock.patch("flashpkg.aws.dns.list_resource_record_sets", side_effect=mock_list_resource_record_sets)
    def test_get_cname_info(self, mock_list_resource_record_sets):
        self.assertEqual(get_cname_info("foo", "foo"), self.record_sets[0])
        self.assertEqual(get_cname_info("*.foo", "*.foo"), self.record_sets[1])
        self.assertEqual(get_cname_info("*.bar", "*.bar"), self.record_sets[2])
