import os
import uuid
import unittest
from flashpkg.infra import cluster
from flashpkg.state import state

class TestClusterState(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.flavor = "invalid_flavor"
        cls.cluster_name = "eks-test-" + os.environ.get("CI_JOB_ID", uuid.uuid4().hex[:8])
        cls.region = "us-west-2"
        cls.zones = "us-west-2a,us-west-2b"

    def test_cluster_state_on_failure(self):
        with self.assertRaises(Exception):
            cluster.create(self.flavor, self.cluster_name,
                           region=self.region, zones=self.zones)
        self.assertIs(state.get_cluster(cluster_name='invalid_flavor'), None)


if __name__ == '__main__':
    unittest.main()
