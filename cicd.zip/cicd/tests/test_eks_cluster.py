import os
import uuid
import unittest
from unittest import mock
from flashpkg.infra import cluster
from flashpkg.aws import eks
from flashpkg.state import state

class TestEksCluster(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.flavor = "eks_medium"
        cls.cluster_name = "eks-test-" + os.environ.get("CI_JOB_ID", uuid.uuid4().hex[:8])
        cls.region = "us-west-2"
        cls.zones = "us-west-2a,us-west-2b"

    @classmethod
    def tearDownClass(cls):
        state.remove_cluster(cls.cluster_name)

    def mocked_cluster_create(*args, **kwargs):
        assert 'eks-test' in args[0]
        assert args[1] == "us-west-2"
        assert len(args[2].split(',')) > 1
        assert args[3] == "t2.xlarge"
        assert args[5] == "iam"
        assert args[7] is True
        return 0

    @mock.patch("flashpkg.aws.eks.__local_start", side_effect=mocked_cluster_create)
    def test_create_eks_cluster(self, mock_request):
        self.assertEqual(cluster.create(self.flavor, self.cluster_name,
                                        region=self.region, zones=self.zones), 0)


if __name__ == '__main__':
    unittest.main()
