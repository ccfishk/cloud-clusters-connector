import unittest
from random import randint
from flashpkg import cloud
import os


global_name = 'test_task_' + str(randint(0, 99999))
print("Working on commit: %s and name: %s" % ("latest", global_name))


class TestContainer(unittest.TestCase):
    def setUp(self):
        self.name = global_name
        pass

    def test_1_start_container(self):
        r = cloud.container.start(self.name, "latest")
        self.assertEqual(r, 0)

    def test_2_cpto_container(self):
        fname = "/tmp/test_2_cpto_container"
        dname = "/tmp/test_2_cpto_container_dest"
        os.system("ls -la > %s" % fname)
        r = cloud.container.cp_to_container(self.name, fname, dname)
        self.assertEqual(r, 0)

    def test_3_cp_container(self):
        fname = "/tmp/test_2_cpto_container_dest"
        dname = "/tmp/test_2_cpto_container_rx"
        r = cloud.container.cp(self.name, fname, dname)
        self.assertEqual(r, 0)

    def test_4_rx_file_same(self):
        name1 = "/tmp/test_2_cpto_container"
        name2 = "/tmp/test_2_cpto_container_rx"
        r = os.system("diff %s %s > /dev/null" % (name1, name2))
        self.assertEqual(r, 0)

    def test_5_stop_container(self):
        r = cloud.container.stop(self.name)
        self.assertEqual(r, 0)


if __name__ == '__main__':
    unittest.main()
