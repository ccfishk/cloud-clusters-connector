import unittest
from unittest import mock
from flashpkg.infra import cluster_pool

def mock_list_short():
    return []

def mock_list_short_fail():
    raise Exception('Some Error')

def mock_create_in_pool(*args):
    return (0, 'cluster_name')

def mock_create_in_pool_fail(*args):
    raise Exception('Some error')

class MockedClusterPoolModel:
    def __init__(self):
        pass

    def upsert(self, **kwargs):
        pass

class MockedUpsertRaiseError:
    def __init__(self):
        pass

    def upsert(self, **kwargs):
        raise Exception('Some exception')

class MockPrettyTable:
    def __init__(self, headers):
        pass

    def add_row(self, item):
        pass

class TestClusterPool(unittest.TestCase):
    @mock.patch("flashpkg.infra.cluster_pool.ClusterPoolModel", side_effect=MockedClusterPoolModel)
    def test_upsert(self, mocked_cluster_pool_model):
        pool_name = 'test-name'
        free_threshold = '60'
        recycle_time = '30'

        args = {
            '<pool_name>': pool_name,
            '<free_threshold>': free_threshold
        }

        with mock.patch.object(MockedClusterPoolModel, 'upsert', return_value=None) as mocked_upsert:
            exit_code = cluster_pool.upsert(args)

        mocked_upsert.assert_called_once_with(name=pool_name, free_threshold=free_threshold)

    @mock.patch("flashpkg.infra.cluster_pool.ClusterPoolModel", side_effect=MockedUpsertRaiseError)
    def test_upsert_fail(self, mocked_cluster_pool_model):
        pool_name = 'test-name'
        free_threshold = '60'
        recycle_time = '30'

        args = {
            '<pool_name>': pool_name,
            '<free_threshold>': free_threshold,
            '<recycle_time>': recycle_time
        }

        with unittest.mock.patch('builtins.print') as mocked_print:
            exit_code = cluster_pool.upsert(args)

        self.assertEqual(exit_code, 1)
        self.assertEqual(mocked_print.mock_calls, [mock.call('Error during upserting cluster pool: Some exception')])

class TestClusterPoolList(unittest.TestCase):
    @mock.patch("flashpkg.infra.cluster_pool.PrettyTable", side_effect=MockPrettyTable)
    @mock.patch("flashpkg.aws.dynamodb.services.cluster_pool_service.ClusterPoolService.list_short", side_effect=mock_list_short)
    def test_list(self, mocked_list_short, mocked_pretty_table):
        args = {
            '--verbose': False
        }
        cluster_pool.list(args)
        mocked_list_short.assert_called_once_with()

    @mock.patch("flashpkg.infra.cluster_pool.PrettyTable", side_effect=MockPrettyTable)
    @mock.patch("flashpkg.aws.dynamodb.services.cluster_pool_service.ClusterPoolService.list_short", side_effect=mock_list_short_fail)
    def test_list_fail(self, mocked_list_short, mocked_pretty_table):
        args = {
            '--verbose': False
        }

        with unittest.mock.patch('builtins.print') as mocked_print:
            exit_code = cluster_pool.list(args)

        self.assertEqual(exit_code, 1)
        self.assertEqual(mocked_print.mock_calls, [mock.call('Error during listing pools: Some Error')])

class TestClusterPoolCreateInPool(unittest.TestCase):
    @mock.patch("flashpkg.aws.dynamodb.services.cluster_pool_service.ClusterPoolService.create_in_pool", side_effect=mock_create_in_pool_fail)
    def test_create_in_pool_fail(self, mocked_cp_service):
        args = {
            '<pool_name>': 'test-pool',
            '<flavor_name>': 'test_flavor'
        }

        exit_code = cluster_pool.create_in_pool(args)

        self.assertEqual(exit_code, 1)

    @mock.patch("flashpkg.aws.dynamodb.services.cluster_pool_service.ClusterPoolService.create_in_pool", side_effect=mock_create_in_pool)
    def test_create_in_pool(self, mocked_cp_service):
        pool_name = 'test-pool'
        flavor_name = 'test_flavor'

        args = {
            '<pool_name>': pool_name,
            '<flavor_name>': flavor_name
        }

        exit_code = cluster_pool.create_in_pool(args)

        self.assertEqual(exit_code, 0)
        mocked_cp_service.assert_called_once_with(pool_name, flavor_name, None, None, False, False, False, None, None)
