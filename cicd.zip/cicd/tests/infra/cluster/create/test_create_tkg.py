import unittest

from unittest import mock
from flashpkg.infra import cluster

flavor_name = 'tkg_small'
cluster_name = 'my_cluster'

def mocked_no_cluster_exist(*args, **kwargs):
    return None

def mocked_config_get_flavor(*args):
    return {
        'type': 'tkg',
        'workers': 2,
        'k8s_version': '1.18.3',
        'region': 'us-west-2',
        'zones': 'us-west-2a',
        'public_node_cidr': '10.0.1.0/24',
        'private_node_cidr': '10.0.0.0/24',
        'vpc_cidr': '10.0.0.0/16',
        'cluster_cidr': '100.96.0.0/11',
        'ssh_key_name': 'test-key',
        'control_plane_machine_type': 't3.medium',
        'node_machine_type': 't3.medium',
        'name': 'test_tkg_cluster',
        'flavor': 'tkg_small',
        'tenants': [],
        'ready': False
    }

class TestTKGClusterCreate(unittest.TestCase):
    @mock.patch(
        'flashpkg.infra.cluster.state.get_cluster_v2',
        side_effect=mocked_no_cluster_exist
    )
    @mock.patch(
        'flashpkg.infra.cluster.config.get_flavor',
        side_effect=mocked_config_get_flavor
    )
    @unittest.skip('Not yet implemented')
    def test_tkg(self, mocked_config, mocked_get_cluster):
        cluster.create(flavor_name, cluster_name)
