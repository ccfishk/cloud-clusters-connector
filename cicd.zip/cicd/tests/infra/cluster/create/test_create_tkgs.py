from unittest import mock, TestCase
from flashpkg.infra import cluster
from flashpkg.config import config

flavor_name = "tkgs_small"
cluster_name = 'my_cluster'
namespace = 'test_namespace'
context = 'test_context'

def mock_cluster(*args, **kwargs):
    return None

def mock_tkgs_start(*args, **kwargs):
    return 0

def mock_tkgs_start_fail(*args, **kwargs):
    return 1

def mock_add_cluster(*args, **kwargs):
    pass

class TestTKGSClusterCreate(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.flavor = config.get_flavor(flavor_name)

    @mock.patch(
        'flashpkg.infra.cluster.state.add_cluster',
        side_effect=mock_add_cluster
    )
    @mock.patch(
        'flashpkg.infra.cluster.cloud_type.tkgs.start',
        side_effect=mock_tkgs_start
    )
    @mock.patch(
        'flashpkg.infra.cluster.state.get_cluster_v2',
        side_effect=mock_cluster
    )
    def test_tkgs_succeed(self, mocked_cluster, mocked_tkgs_start, mocked_add_cluster):
        res = cluster.create(flavor_name, cluster_name)
        self.assertEqual(res, 0)

        mocked_tkgs_start.assert_called_once_with(
            cluster_name,
            namespace,
            context,
            {**self.flavor, 'name': cluster_name, 'flavor': flavor_name, 'tenants': [], 'ready': True},
            False
        )
        mocked_add_cluster.assert_called_once()

    @mock.patch(
        'flashpkg.infra.cluster.state.add_cluster',
        side_effect=mock_add_cluster
    )
    @mock.patch(
        'flashpkg.infra.cluster.cloud_type.tkgs.start',
        side_effect=mock_tkgs_start_fail
    )
    @mock.patch(
        'flashpkg.infra.cluster.state.get_cluster_v2',
        side_effect=mock_cluster
    )
    def test_tkgs_failed(self, mocked_cluster, mocked_tkgs_start, mocked_add_cluster):
        res = cluster.create(flavor_name, cluster_name)
        self.assertEqual(res, 1)

        mocked_tkgs_start.assert_called_once_with(
            cluster_name,
            namespace,
            context,
            {**self.flavor, 'name': cluster_name, 'flavor': flavor_name, 'tenants': [], 'ready': False},
            False
        )
        mocked_add_cluster.assert_not_called()
