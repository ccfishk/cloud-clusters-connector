import unittest
from fromwork.utils import run_local_sh_cmd, FORTIO_RES_SUFFIX

# mv everthing to kubernetes library after passing the flow
def bump_prometheus():
    cmd = "kubectl -n monitoring port-forward pod 9090:9090 &"
    rt, out, err = run_local_sh_cmd(cmd)
    if rt != 0:
        raise Exception("failed bringing prometheus on client cluster. {}".format(err))
    return 0

def grpc_call():
    grpc_cmd = "kubectl --context arn:aws:eks:us-west-2:284299419820:cluster/dd-cl2-dev-st -n fortioclient"\
               "exec fortioclient-66b86b65b6-v8fh8 -- fortio load -grpc -ping -grpc-ping-delay 0.25s -labels a http://fortioserver.dd-cl2-cl3-fortio.local:8079"
    rt, out, err = run_local_sh_cmd(grpc_cmd)
    if rt != 0:
        raise Exception("failed running grpc test")
    return 0

def read_ip(output=None):
    # fix me
    return "a922bfcd5351c430a85df775602345d2-1021656183.us-west-2.elb.amazonaws.com"


def generate_test_result():
    get_fortioclient_external_ip = "kubectl -n fortioclient get svc fortioclient"
    rt, out, err = run_local_sh_cmd(get_fortioclient_external_ip)
    if rt != 0:
        raise Exception("Failed get fortioclient service ip")
    ip = read_ip(output=out)
    print("read external ip from fortioclient service {}".format(ip))

    cmd = "export PROMETHEUS_URL=http://localhost:9090"
    rt, out, err = run_local_sh_cmd(cmd)
    if rt != 0:
        raise Exception("Failed export prometheous URL.")

    generate_res_cmd = 'python3 fortio.py $FORTIO_CLIENT_URL --prometheus=$PROMETHEUS_URL {}'.format(FORTIO_RES_SUFFIX)
    rt, out, err = run_local_sh_cmd(generate_res_cmd)
    if rt != 0:
        raise Exception("Failed export prometheous URL.")
    print("result json csv files are persisted somewhere.")
    return 0

class test_gns_cc(unittest.TestCase):

    @classmethod
    def setUp(self):
        bump_prometheus()

    @classmethod
    def cleanup(self):
        # cluster offboard
        # destroy cluster
        return 0

    def test_2pods_gns_cc(self):
        self.assertEqual(grpc_call(), 0)


if __name__ == '__main__':
    unittest.main()
