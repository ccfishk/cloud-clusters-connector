import os

from unittest import TestCase, mock
from flashpkg.infra import cluster

cluster_mock = {
    'name': 'test-cluster-name',
    'region': 'test-region',
    'cluster_type': 'tkgi'
}


class MockedClusterKey:
    region = 'region'

class TestTKGIClusterCleanup(TestCase):
    @mock.patch.dict(os.environ, {"JUMPER_VM": "host"})
    @mock.patch('flashpkg.cloud.tkgi.cleanup')
    @mock.patch('flashpkg.cloud.tkgi.requirements', return_value=('host', 'user', 'password'))
    @mock.patch('flashpkg.state.state.get_cluster_v2', return_value=cluster_mock)
    def test_cleanup_exist_cluster(self, mocked_state, mocked_requirements, mocked_cloud):
        cluster.cleanup(cluster_mock['name'])

        mocked_state.assert_called_once_with(cluster_name=cluster_mock['name'])
        mocked_cloud.assert_called_once_with(cluster_mock['name'])
