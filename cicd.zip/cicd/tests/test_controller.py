import unittest
from unittest import mock
from flashpkg import controller

args_list_tenants = {"list": True, "tenants": True, "install": False, "uninstall": False, "logbundle": False}
def mocked_dockopt_list_tenants(*args):
    return args_list_tenants


args_list_restores = {"list": True, "restores": True, "backups": False, "tenants": False, "install": False, "uninstall": False, "logbundle": False}
def mocked_dockopt_list_restores(*args):
    return args_list_restores


args_list_backups = {"list": True, "backups": True, "restores": False, "tenants": False, "install": False, "uninstall": False, "logbundle": False}
def mocked_dockopt_list_backups(*args):
    return args_list_backups


args_logbundle = {"logbundle": True, "list": False, "backups": False, "restores": False, "tenants": False, "install": False, "uninstall": False}
def mocked_dockopt_logbundle(*args):
    return args_logbundle


args_install = {"install": True, "logbundle": False, "list": False, "backups": False, "restores": False, "tenants": False, "uninstall": False}
def mocked_dockopt_install(*args):
    return args_install


args_uninstall = {"uninstall": True, "install": False, "logbundle": False, "list": False, "backups": False, "restores": False, "tenants": False}
def mocked_dockopt_uninstall(*args):
    return args_uninstall

class TestController(unittest.TestCase):
    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_list_tenants)
    def test_list_calls_infra_saas_list_tenants(self, mocked_docopt):
        with mock.patch.object(controller, 'list_tenants', return_value=None) as mocked_saas_list_tenants:
            controller.dispatch()
        mocked_saas_list_tenants.assert_called_once_with(args_list_tenants)

    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_list_restores)
    def test_list_calls_infra_saas_list_restores(self, mocked_docopt):
        with mock.patch.object(controller, 'list_backups_or_restores', return_value=None) as mocked_saas_list_backups_restores:
            controller.dispatch()
        mocked_saas_list_backups_restores.assert_called_once_with(args_list_restores)

    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_list_backups)
    def test_list_calls_infra_saas_list_backups(self, mocked_docopt):
        with mock.patch.object(controller, 'list_backups_or_restores', return_value=None) as mocked_saas_list_backups_restores:
            controller.dispatch()
        mocked_saas_list_backups_restores.assert_called_once_with(args_list_backups)

    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_logbundle)
    def test_logbundle_calls_infra_saas_logbundle(self, mocked_docopt):
        with mock.patch.object(controller, 'logbundle', return_value=None) as mocked_logbundle:
            controller.dispatch()
        mocked_logbundle.assert_called_once_with(args_logbundle)

    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_install)
    def test_install_calls_saas_install(self, mocked_docopt):
        with mock.patch.object(controller, 'install', return_value=None) as mocked_saas_install:
            controller.dispatch()
        mocked_saas_install.assert_called_once_with(args_install)

    @mock.patch("flashpkg.controller.docopt", side_effect=mocked_dockopt_uninstall)
    def test_uninstall_calls_saas_uninstall(self, mocked_docopt):
        with mock.patch.object(controller, 'uninstall', return_value=None) as mocked_saas_uninstall:
            controller.dispatch()
        mocked_saas_uninstall.assert_called_once_with(args_uninstall)


if __name__ == '__main__':
    unittest.main()
