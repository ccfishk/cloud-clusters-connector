import unittest
from flashpkg.config import config

SUPPORTED_FLAVORS = ("kops", "eks", "cpks", "pks", "tmc", "tkg", "tkgs", "tkgi")

class TestFlavors(unittest.TestCase):

    def setUp(self):
        self.flavors = config.get_flavors()

    def test_flavors(self):
        for f in self.flavors:
            self.assertTrue(config.get_flavor(f)['type'] in SUPPORTED_FLAVORS)


if __name__ == '__main__':
    unittest.main()
