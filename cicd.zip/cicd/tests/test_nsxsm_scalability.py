import unittest
import os
import json
import yaml
import tempfile
from time import sleep
from unittest import mock
from flashpkg.infra import cluster
from flashpkg.nsxsm import (
    install_allspark,
    uninstall_allspark,
    install_tenant_cluster,
    uninstall_tenant_cluster,
    install_tenant,
    init_tenant_cluster,
    deinit_tenant_cluster,
    list_clusters,
    upgrade_tenant,
    upgrade_operator,
    install_tenant,
    generate_runtime_config,
    install_tenants,
    process_list_tenants,
    batch_upgrade_tenants
)
from flashpkg import nsxsmOps
from flashpkg.allspark_api import AllsparkApi
from flashpkg.infra import saas


class MockResponse:
    def __init__(self, json_data, text_data, status_code):
        self.json_data = json_data
        self.text_data = text_data
        self.status_code = status_code

    def json(self):
        return self.json_data

    def text(self):
        return self.text


class MockConfigMapMetadata():
    def __init__(self, name):
        self.name = name


class MockConfigMap():
    def __init__(self, data, name):
        self.metadata = MockConfigMapMetadata(name)
        self.data = data


class MockConfigMapList():
    def __init__(self, cfgmap_list):
        self.items = cfgmap_list


class TestNsxsmScalability(unittest.TestCase):

    TSM_PRE_UPGRADE_VERSION = "v1.2.14"

    @classmethod
    def setUpClass(cls):
        #cls.cluster_name = "flash-test-" + os.environ.get("CI_JOB_ID", "12345")
        cls.cluster_name = "tsm-st-client-cluster"
        print("test cluster name {}".format(cls.cluster_name))
        cluster.create("kops_small", cls.cluster_name)

        self.tenant_name = "14804240133cb8f201ece3b8a41ed60088b25d585"
        self.saas_cluster_name = "1480424-saas-systemtest"
        self.tenant_user_name = "testuser1480424001"
        self.tenant_pwd = "test_password"

    @classmethod
    def tearDownClass(cls):
        cluster.cleanup(cls.cluster_name)


    def mocked_cluster_state(*args, **kwargs):
        cluster = mock.MagicMock()
        if 'type' in kwargs.keys():
            cluster_type = kwargs['type']
        else:
            cluster_type = 'kops'
        cluster = {'cluster_name': 'dummy-cluster', 'type': cluster_type, 'flavor': 'kops_small',
                   'tenants': [{"tenant_name": self.tenant_name, "tenant_id": "dummy_id", "username": self.tenant_user_name}]}
        return cluster

    def mock_tsm_api_setup(*args, **kwargs):
        return AllsparkApi('dummy-gw')

    def mocked_istio(*args, **kwargs):
        print("args:", args, ", kwargs:", kwargs)
        # Operation
        assert args[0] == 'install'
        # Client cluster name
        assert args[1] == 'dummy-cluster'
        # Client cluster type
        assert kwargs['type'] == 'kops'
        # Verify async API is being invoked
        assert kwargs['do_async'] is True
        r = MockResponse({"Error": "Mocked istio response"}, "Mocked istio (un)install failure", 400)
        return r

    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_install_tenant_cluster():
        args = {
            "<tenant_name>": self.tenant_name,
            "<saas_cluster_name>": self.saas_cluster_name,
            "<client_cluster_name>": cls.cluster_name,
            "<username>": self.tenant_user_name,
            "--password": self.tenant_pwd,
            "--use-board-api": True
        }
        start_time = int(round(time.time() * 1000))
        self.assertEqual((install_tenant_cluster(args), 0))
        end_time = int(round(time.time() * 1000))
        print("5 Applications: install tenant cluster starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))


    @mock.patch("flashpkg.allspark_api.AllsparkApi.istio", side_effect=mocked_istio)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_init_tenant_cluster(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": self.tenant_name,
            "<saas_cluster_name>": self.saas_cluster_name,
            "<client_cluster_name>": cls.cluster_name,
            "<username>": self.tenant_user_name,
            "--password": self.tenant_pwd,
            "--eks": False,
            "--use-v1-api": True
        }
        start_time = int(round(time.time() * 1000))
        self.assertEqual(init_tenant_cluster(args), 0)
        end_time = int(round(time.time() * 1000))
        print("5 Applications: init tenant cluster starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))


    @mock.patch('kubernetes.client.CoreV1Api.list_namespaced_config_map')
    @mock.patch('kubernetes.config.load_kube_config')
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_list_clusters(self, mocked_config_map, mocked_kube_config, mocked_cluster_state):
        mocked_config_map.return_value = mocked_config_map()
        start_time = int(round(time.time() * 1000))
        self.assertEqual(list_clusters(cls.cluster_name, self.tenant_name, False), 0)
        end_time = int(round(time.time() * 1000))
        print("5 Applications: list clusters starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))

    @mock.patch("flashpkg.allspark_api.AllsparkApi.istio", side_effect=mocked_istio)
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_deinit_tenant_cluster(self, mock_request, mock_cluster, mock_api_setup):
        args = {
            "<tenant_name>": self.tenant_name,
            "<saas_cluster_name>": self.saas_cluster_name,
            "<client_cluster_name>": cls.cluster_name,
           "<username>": self.tenant_user_name,
            "--password": self.tenant_pwd,
            "--eks": False,
            "--use-v1-api": True
        }
        start_time = int(round(time.time() * 1000))
        self.assertEqual(deinit_tenant_cluster(args), 0)
        end_time = int(round(time.time() * 1000))
        print("5 Applications: deinit tenant cluster starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))

    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    @mock.patch("flashpkg.nsxsm.api.setup", side_effect=mock_tsm_api_setup)
    def test_uninstall_tenant_cluster():
        args = {
            "<tenant_name>": self.tenant_name,
            "<saas_cluster_name>": self.saas_cluster_name,
            "<client_cluster_name>": cls.cluster_name,
            "<username>": self.tenant_user_name,
            "--password": self.tenant_pwd,
            "--use-board-api": True
        }
        start_time = int(round(time.time() * 1000))
        self.assertEqual((uninstall_tenant_cluster(args), 0))
        end_time = int(round(time.time() * 1000))
        print("5 Applications: uninstall tenant cluster starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))


    @mock.patch('kubernetes.client.CoreV1Api.list_namespaced_config_map')
    @mock.patch('kubernetes.config.load_kube_config')
    @mock.patch("flashpkg.state.state.get_cluster", side_effect=mocked_cluster_state)
    def test_list_clusters(self, mocked_config_map, mocked_kube_config, mocked_cluster_state):
        mocked_config_map.return_value = mocked_config_map()
        start_time = int(round(time.time() * 1000))
        self.assertEqual(list_clusters(cls.cluster_name, self.tenant_name, False), 1)
        end_time = int(round(time.time() * 1000))
        print("5 Applications: again list cluster starttime {} endtime {} cost {} ms".format(start_time, 
        end_time, end_time - start_time))


if __name__ == '__main__':
    unittest.main()