import unittest
from random import randint
from flashpkg import cloud, utils
import re

global_repo_name = 'test_repo_' + str(randint(0, 99999))
print('Repo Test will work on temporary rpeo: %s' % global_repo_name)


class TestRepo(unittest.TestCase):

    def setUp(self):
        self.repo_name = global_repo_name
        pass

    def test_1_create_repo(self):
        repo_arn = cloud.repo.create(self.repo_name)
        self.__class__.repo_arn = repo_arn
        # Example AWS ARN
        # arn:aws:ecr:us-west-1:284299419820:repository/test_repo_40723
        pattern = re.compile(".*:.*:.*:.*:.*:.*")
        self.assertNotEqual(repo_arn, '')
        self.assertNotEqual(pattern.match(repo_arn), None)

    def test_2_re_create_repo(self):
        repo_arn2 = cloud.repo.create(self.repo_name)
        self.assertEqual(self.__class__.repo_arn, repo_arn2)

    def test_3_get_url(self):
        repo_url = cloud.repo.url(self.repo_name)
        # Example AWS URL
        # 284299419820.dkr.ecr.us-west-1.amazonaws.com/test_repo_40723
        pattern = re.compile(".*/.*")
        self.assertNotEqual(repo_url, '')
        self.assertNotEqual(pattern.match(repo_url), None)

    def test_4_delete_repo(self):
        repo_arn2 = cloud.repo.delete(self.repo_name)
        self.assertEqual(self.__class__.repo_arn, repo_arn2)

    def test_5_pem(self):
        loc = utils.ci_key()
        self.assertNotEqual(loc, "")
        s, o = utils.command(["ls", "-la", "{}".format(loc)])
        print(s, o)
        self.assertEqual(s, 0)


if __name__ == '__main__':
    unittest.main()
