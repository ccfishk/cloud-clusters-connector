from unittest import TestCase
from flashpkg.commands.tkgi.shepherd_lock import ShepherdLock

class TestTKGIShepherdLock(TestCase):
    def test_init(self):
        lock = {'test': 'lock'}
        shepherd_lock = ShepherdLock(lock)
        self.assertEqual(shepherd_lock.lock, lock)

    def test_retrive_proxy_ip(self):
        ip = "10.10.10.10:80"
        lock = {'network': {"http proxy": {"ip": ip}}}
        shepherd_lock = ShepherdLock(lock)
        retrieved_ip = shepherd_lock.retrieve_proxy_ip()
        self.assertEqual(retrieved_ip, ip)

    def test_retrive_proxy_ip_failed(self):
        ip = "10.10.10.10:80"
        lock = {'network': {"test": {}}}

        shepherd_lock = ShepherdLock(lock)
        with self.assertRaises(KeyError) as context:
            shepherd_lock.retrieve_proxy_ip()

        self.assertTrue("http proxy" in str(context.exception))

    def test_get_jumper_vm_host(self):
        host = "10.10.10.10"
        lock = {'network': {"http proxy": {"ip": f"{host}:80"}}}
        shepherd_lock = ShepherdLock(lock)
        retrieved_host = shepherd_lock.get_jumper_vm_host()
        self.assertEqual(retrieved_host, host)
