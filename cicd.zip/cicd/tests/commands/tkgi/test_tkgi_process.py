from unittest import TestCase, mock
from flashpkg.commands.tkgi.tkgi import __doc__, process, DEFAULT_USERNAME

username = 'test_username'
docopt_with_username = {
    '--logging-format': None,
    '--username': username,
    'create': True,
    'testbed': True,
    'tkgi': True
}

docopt_without_username = {
    '--logging-format': None,
    '--username': None,
    'create': True,
    'testbed': True,
    'tkgi': True
}

docopt_logging_format = {
    '--logging-format': 'json',
    '--username': None,
    'create': True,
    'testbed': True,
    'tkgi': True
}


class TestTKGIProcess(TestCase):
    @mock.patch(
        "flashpkg.commands.tkgi.tkgi.docopt",
        return_value=docopt_with_username
    )
    @mock.patch("flashpkg.commands.tkgi.tkgi.create_testbed")
    def test_username(self, mocked_create_testbed, mocked_docopt):
        process()

        mocked_create_testbed.assert_called_once_with(username, None)

    @mock.patch(
        "flashpkg.commands.tkgi.tkgi.docopt",
        return_value=docopt_without_username
    )
    @mock.patch("flashpkg.commands.tkgi.tkgi.create_testbed")
    def test_username_default(self, mocked_create_testbed, mocked_docopt):
        process()

        mocked_create_testbed.assert_called_once_with(DEFAULT_USERNAME, None)

    @mock.patch(
        "flashpkg.commands.tkgi.tkgi.docopt",
        return_value=docopt_logging_format
    )
    @mock.patch("flashpkg.commands.tkgi.tkgi.create_testbed")
    def test_logging_format(self, mocked_create_testbed, mocked_docopt):
        process()

        mocked_create_testbed.assert_called_once_with(DEFAULT_USERNAME, 'json')
