import shutil
from unittest import mock, TestCase, skip
from flashpkg.commands.tkgi.shepherd import Shepherd
from flashpkg.commands.tkgi.shepherd_lock import ShepherdLock

USERNAME = 'test_username'

ip = '10.10.10.10'

floating_ip_pools_0 = '12dbce4a-1b0c-43cf-b19e-c67a3c83b403'
floating_ip_pools_1 = '4d1ced25-e459-46ea-994d-bbd68d4d0e4e'

pod_ip_block_0 = "7ce1c9df-f132-4869-91c7-5fb189209da0"
pod_ip_block_1 = "6024aad6-fc81-48f3-880d-a22496c882fd"
shared_id = "b61590b9-05c2-4c4a-9fad-77e62bbbb8b9"

stdout_success = """
2020/12/18 11:27:57 Retrieving lock
{
  "access": "..hidden..",
  "annotations": {
    "client": "cli",
    "user": "lgmkr"
  },
  "created_at": "2020-12-16T06:16:08.872986-08:00",
  "description": "",
  "environment_id": "198148",
  "expires_at": "2020-12-22T07:47:08.201094-08:00",
  "id": "09ce02f5-8cdb-459d-8433-67f836d6ef5e",
  "lifetime": 259200,
  "recipe": {
    "data": {
      "esx-build": "15847429",
      "nsx-edge-clusters": "2",
      "nsxt-build": "ob-16404613",
      "opsman-url": "http://files.pks.eng.vmware.com/ci/artifacts/opsman/ops-manager-vsphere-2.9.9-build.164.ova",
      "path": "pks-dev-with-nsx-t",
      "pks-stemcell-url": "http://files.pks.eng.vmware.com/ci/artifacts/stemcell/bosh-stemcell-621.84-vsphere-esxi-ubuntu-xenial-go_agent.tgz",
      "pks-tile": "true",
      "pks-tile-url": "http://files.pks.eng.vmware.com/ci/artifacts/pks/1.9.0/pivotal-container-service-1.9.0-build.32.pivotal",
      "vc-build": "ob-15952498"
    },
    "fetcher": "git",
    "launcher": "vane",
    "meta": {
      "nimbus_location": "sc",
      "nimbus_user": "svc.tsm-nimbus"
    },
    "source": "git@gitlab.eng.vmware.com:PKS/tooling/hack-nimbus.git",
    "symbol": "master"
  },
  "status": "locked",
  "updated_at": "2020-12-16T08:51:25.223269-08:00"
}
Access Info:
env_type: vmware
iaas_type: vsphere
metadata:
  iaas: vsphere
  platform: nimbus
  version: 2.0.0
modules:
  nsx: true
  opsman: true
  vrli: false
  vrops: false
network:
  common:
    dns servers:
      alternative: 192.168.139.1
      default: 192.168.111.155
    infra cluster: t0-shared
    networks:
      deployment:
        azs:
        - az-0
        - az-1
        - az-2
        dns: 192.168.111.155
        name: deployment-network
    no nat node ip blocks:
    - b4c55c83-e0fc-4701-9841-77fde030d2f5
    - 48b08f15-67cd-4e3f-92be-6493cb97ca3f
    node ip blocks:
    - f8aca2a3-59d6-4867-9e02-76353a5143af
    - 63a77425-9062-40e7-be71-9c3d4dfb5a1d
    nsx clusters: cluster-0,cluster-0,cluster-0
  http proxy:
    ip: %s:80
    password: Ponies!23
    username: kubo
  manager:
    ca cert: |
      -----BEGIN CERTIFICATE-----
      MIIDwzCCAqugAwIBAgIGAXZsC58FMA0GCSqGSIb3DQEBCwUAMHMxJDAiBgNVBAMM
      G25zeG1hbmFnZXIucGtzLnZtd2FyZS5sb2NhbDEPMA0GA1UECgwGVk13YXJlMQww
      CgYDVQQLDANDTkExCzAJBgNVBAYTAlVTMQswCQYDVQQIDAJDQTESMBAGA1UEBwwJ
      UGFsbyBBbHRvMB4XDTIwMTIxNjE0NTQyOVoXDTIxMTIxNjE0NTQyOVowczEkMCIG
      A1UEAwwbbnN4bWFuYWdlci5wa3Mudm13YXJlLmxvY2FsMQ8wDQYDVQQKDAZWTXdh
      cmUxDDAKBgNVBAsMA0NOQTELMAkGA1UEBhMCVVMxCzAJBgNVBAgMAkNBMRIwEAYD
      VQQHDAlQYWxvIEFsdG8wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC0
      JmRZEwz7eeQZ9rMAZoF9ux5Sd79/DqVBrMzYnLs5MDR2umq/XIS8md/Bl3jSFixm
      /8EpiT6eFzlwxVAkOEE3Jk07RYUHFgxe++D4flbJ52pUng+eAvODm1t9rshEAO/Q
      vRxUbWZV3QimHOGvcWrCVZ99ni0q7UZ1+SvZBxuUQk01dLlurdihIqAY60TZA5Zo
      sjRsQDO7YTwgEwfKIcjMrrpe69XLPbwiwRMj4BXLNi60t8nQcOBlm/H7PQhU7X3H
      HMknPJ3rnL8fCjtfEzXx722Zt7e2w/1Mpx3aFHIJOadFCQV1/rUXY33bQFkkiAYM
      QRkP/lLM3ba1zAaex9O/AgMBAAGjXTBbMCAGA1UdJQEB/wQWMBQGCCsGAQUFBwMC
      BggrBgEFBQcDATAMBgNVHRMBAf8EAjAAMCkGA1UdEQEB/wQfMB2CG25zeG1hbmFn
      ZXIucGtzLnZtd2FyZS5sb2NhbDANBgkqhkiG9w0BAQsFAAOCAQEAIz7DgnwHC8VC
      zy3CqdsZ2YXfgzgQeS5p/solKS7fvhZiWOr73DqTygH5Slr/GQKxjlZBzkG4VxbA
      OlUu6IaXwpLcttxD6wiq0m1M8XXPbvOJKS3z/ZPOag3h2GYUD7o4l3cqo9rFwNli
      3KUQDQGEQbzELrHn19gj5elDrr3D6ojxbjd6PHNpPR0/41McmqTkm82Ip2z9mA/0
      IJxYWgLKzEZuPrb4MQMW17pQqC6gpxif4CeG62zWrcoZlRGf+X4XY/KngFj5L9GP
      SAveKgAaSQpBxflH9I+3iRtH/7xCrpFFr7PzZgajm090Rc1V1XXtJMZ1XMhuqQVL
      LL//DVFZfA==
      -----END CERTIFICATE-----
    hostname: nsxmanager.pks.vmware.local
    ip: 192.168.111.102
    password: Admin!23Admin
    superuser cert: |
      -----BEGIN CERTIFICATE-----
      MIIDPTCCAiWgAwIBAgIEBQRYIDANBgkqhkiG9w0BAQsFADAoMSYwJAYDVQQDDB1z
      dXBlci11c2VyLXByaW5jaXBhbC1pZGVudGl0eTAeFw0yMDEyMTYxNDU0MjhaFw0z
      MDEyMTQxNDU0MjhaMCgxJjAkBgNVBAMMHXN1cGVyLXVzZXItcHJpbmNpcGFsLWlk
      ZW50aXR5MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr5SGD70MUrV1
      K9a2bU8U6YDHtoe+PPBgXE9zn5N+P+KI4PEsOmAtxRMlRu0Ef4JwOdDsu20tb1Vg
      LX4wjFwjj9KDv17S+xXnDs6Pfcfx6VJhQ7UqqKuB25HzsQdMGz786zzTNBXt63zh
      UDvwYIm+tU5IFSZjt8T8zlJFN4kUnLUJt7t9soyr//5mSCYkRe5aQXYoC2ENq6it
      ajf7jP4IBxLwpjNFlreUHlMa6MltYYK0KNbFuVK9fCs7CrAgZOCG6IPkLEmEps35
      ifjG6mzkkFexYhk4CV8hst/WvkScC3tHJOd7+47LPErPJjuUStgtoPkeDMqFMZR0
      eDlEcb74EQIDAQABo28wbTAJBgNVHRMEAjAAMB0GA1UdDgQWBBTaOaPuXmtLDTJV
      v++VYBiQr9gHCTAfBgNVHSMEGDAWgBTaOaPuXmtLDTJVv++VYBiQr9gHCTATBgNV
      HSUEDDAKBggrBgEFBQcDAjALBgNVHQ8EBAMCB4AwDQYJKoZIhvcNAQELBQADggEB
      ACsP/YjEKhM5nK2c/LoN+rhW8o0g7w/kQe+F+aSzdwRXwHLZ0DuneiAoWi9svieB
      vx0pTe3R5RAL2gdBVN9nSKK0xxqNCcBdbqPvMsuEno43RrBNHUV2QJWKqHgTtTvB
      m+nRCWrxzkD1FaoBeD8hXk+/lOf17ES3BDseQxzY0VG3X16vfV/ptuWjUgSOpXTd
      J1U1JPIABk/eG9cM8fo2KrOiySv4ZyaInVKFtiIuC5fhiFulzO5xJf6ftKjZN6Fc
      TOtM/g/o9ILctCEzrB+/GZa61s+vJTD8jy32oP3h3FdYPyrWAY5vDxnoGSgeJafc
      R9HCIPdyMWAOAqEZQVCtCgA=
      -----END CERTIFICATE-----
    superuser key: |
      -----BEGIN PRIVATE KEY-----
      MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCvlIYPvQxStXUr
      1rZtTxTpgMe2h7488GBcT3Ofk34/4ojg8Sw6YC3FEyVG7QR/gnA50Oy7bS1vVWAt
      fjCMXCOP0oO/XtL7FecOzo99x/HpUmFDtSqoq4HbkfOxB0wbPvzrPNM0Fe3rfOFQ
      O/Bgib61TkgVJmO3xPzOUkU3iRSctQm3u32yjKv//mZIJiRF7lpBdigLYQ2rqK1q
      N/uM/ggHEvCmM0WWt5QeUxroyW1hgrQo1sW5Ur18KzsKsCBk4Ibog+QsSYSmzfmJ
      +MbqbOSQV7FiGTgJXyGy39a+RJwLe0ck53v7jss8Ss8mO5RK2C2g+R4MyoUxlHR4
      OURxvvgRAgMBAAECggEAWieGKsCkejeIQYlPRJNNppQkd/n9WacHo358XRzLv5vf
      MrlDP3oxJjctddyv6ZUdcOJxG8/0e204JEPeQ8Pv0qKCWZoj9R8K9FRl42zuLyLI
      pI56p/7gf9DSczzO/FJ8ZYFm5SC5eKg3vQ354Gf6D3hxlMKQg0TXlk0yE1EEz21g
      JGiHcrNpvxTcVLPRRGTvO2Y/kFo+NowV/JkHGQdssn4c4yZoaGcmuZ182LahogmN
      2WfgXwK95KfWRGomhSfjUg+Tw2dnLJ3LXWSsRB0zuUHczUVKEPeZ5KLihbMi+FkN
      VIoFS4iLhOLkv0WbEBw3YgfuaB3yUd/XqW/h2M2/wQKBgQDVepT38aUaryy4LJky
      jlPVahi7BlzF25LrvzBPlfKTuYtWgYU5yH5dd/5+azdR5cTxZrB58POWQn22F4uk
      QjUTeXqmml+nikUcZTMlbr1s5ZG8k654HZERqcUP2eEN/Y8ym6UCJvJnBQEZJOFC
      fzPFrdfVOLoceDpnIfBCcM/xOQKBgQDSjXch9OM+QNTCDNoL5Junv+Jxewp740TR
      73GxMtP/agtHB4Kt2rfmdAcxoF0iOeOphk2weffKdNforqQzOvzgwvKWMo9SjF14
      hoFZNLYj9VCQgg1ddI1ifdAdnu1ptazNsM0AjCp3//KlWei200NG//BL5NIboYgM
      8mrZ9781mQKBgBPsEKLi5imLV30IjHNvXNt5vz0U5uuABkIB4ZxLvguTMTGtfKVb
      1I8cd5+MmekGrE5q6uU2W0UWh2zK3blChHmAyLVriqmz+acgupkvsHXNJsCWd522
      BKfFVCKajqojk42BgPCmedCrYuLZ0jvGaypzgsTfOl8VyT1+qVFJ/d3hAoGAGszy
      +xmGy2fJLSIhpx3kSkf8dOFqhjZ5jhdia2HC5mIDKXllQufyPJ1MRR7ae/7OYce8
      n9gGmHii+vUv5W1+vsVRx5iL8b/4Ld1BHa+993nEVYCYXur1DDJjiUGviqMbads1
      XPp6dWfY5P86xfrCN4lgduibbfTzsmIxA6mrZxECgYAUbd1CHCptwJum1WQKlnsC
      FjCK5g0tQAsfl+aSFDVcZ6oy9paBoPkDQv+xIwV/qNth5njHwt5POfQ7XU2Xghff
      HS/5I8mVj90q/XAPde4Sn9OYgNWd0BoCqliFiYcR8vgzB3D36ng6gupofDHr52GM
      XThxBk98TOYUHqiRq7g5sQ==
      -----END PRIVATE KEY-----
    username: admin
  network_type: nsx-t
  routers:
    t0-shared:
      floating ip pools:
      - %s
      - %s
      id: %s
      no nat pod ip blocks:
      - 222-222-222-222
      - 333-333-333-333
      pod ip blocks:
      - %s
      - %s
  version: 3.0.1.0.0.16404613
ops manager:
  azs:
  - az-0
  - az-1
  - az-2
  password: Admin!23
  private key: |
    -----BEGIN OPENSSH PRIVATE KEY-----
    b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABFwAAAAdzc2gtcn
    NhAAAAAwEAAQAAAQEAtF3LUqzRO9OuJH7+KrDk06hTLUNtzgeVHFv9kCkWex7sR0Q+fDaF
    3c0TJ8uKOJCoLQ4N+5XcUTfGrytfUjYgcUwEPQ1PxhFtc9rvAvEa8AXWCBWm8s3xvZ2gri
    Anr6v8NfXJM9cczNNASa8tLhpfddkeY+ibu6d63vTmaBuZIo8lz5zopoRfwTHX+ogJYKzv
    ottLnMd8K8/FyOFEXzEURSzbELJRp4Za4rba0jx6QRnarvZxsharrxrTIm9EEARfCIWBNX
    lWkAu4BwWA3B6dLEY5oVrzAwToZT7tZGXq+u/FUwqlrhIAqsgNiMJTF8cskpj68tJRW267
    i3pmJD2ygQAAA9hv7NGmb+zRpgAAAAdzc2gtcnNhAAABAQC0XctSrNE7064kfv4qsOTTqF
    MtQ23OB5UcW/2QKRZ7HuxHRD58NoXdzRMny4o4kKgtDg37ldxRN8avK19SNiBxTAQ9DU/G
    EW1z2u8C8RrwBdYIFabyzfG9naCuICevq/w19ckz1xzM00BJry0uGl912R5j6Ju7p3re9O
    ZoG5kijyXPnOimhF/BMdf6iAlgrO+i20ucx3wrz8XI4URfMRRFLNsQslGnhlrittrSPHpB
    Gdqu9nGyFquvGtMib0QQBF8IhYE1eVaQC7gHBYDcHp0sRjmhWvMDBOhlPu1kZer678VTCq
    WuEgCqyA2IwlMXxyySmPry0lFbbruLemYkPbKBAAAAAwEAAQAAAQAyCguMplFuLa4Uhf7x
    zR3O8tYQqrJeBJCDy6mvQxbvlYarxu0m/OFqxahY1AlG5CskRM/wSoVTKww+MORDJK0fgZ
    1zaqwFIXSiPc0tncKBcL0OhSNKHYTBvGeFp3obLLXOKqBld3qQANPHHYiFT9/IDDJ4OWJr
    T22xSXRa0b1Mbr8W/dqF1g7Op74fmRrv9dRiaUu2nX2G9f1sHInTQWlvPRIEB0pv0Yhxed
    r3t9cLGB20cFjh8XB3srX+a6kf4Che5EnCtvPAyCVXYKr/QcqFGTMy+p8zaBWv+adGFNop
    aN8ceTq/q12tTVS0Wu6s1zh28QMGMUoHsi579jxQWVoBAAAAgQDWzbIiFVlANMft+6jhMM
    uGP0noJ5kqd7TfKIUugwfUViiCeMCCvePhydyb/3MQaIUGs6j2AUm+AnxwUYYYoNok0jTw
    9d6eGEBljSr2tNxrcullnpi79sJl2JuLP+EWCrzt3rX4tVsOULS8M+4RBVakXM+dpOgBcG
    aG95AgrAoa/gAAAIEA304KQFJepIzn5jTa36kKdU1SC9n/XLO86oF2+lP8gabf5IfQ1bVZ
    WtItyALp2WVaeBnX6lSP7cQbvComxwP939ITcqzgFXPE5B2RQ+XcfT+nKMezOAzLvpLWhz
    nnVEioyIXdJKVicggcy8GL15r74yoNE5dtpoex8A2wvNNnpbEAAACBAM7GU1x/uv8zLtDO
    cehJjCunCOxoy2Mv0pc3KucQtQ5JZFiZegTQlOfq4bbKNuiRavN02PSmLIMpKBEDISfez5
    wz0UFup0yo4Sth+j61etdtvNOSeE6L5vpYAb1EilsiiRlkj0HjHnzNCQAkbTXaCEpdEJCN
    QnpvUSNDX9VSOH3RAAAAHm5pc2hhZG1AbmlzaGFkbS1hMDEudm13YXJlLmNvbQECAwQ=
    -----END OPENSSH PRIVATE KEY-----
  url: https://30.0.0.5
  username: admin
  version: 2.9.9-build.164
pks tile:
  api-url: api.pks.local
  ip: 30.0.0.13
  version: 1.9.0-build.32
vcenter:
  ca cert: |
    -----BEGIN CERTIFICATE-----
    MIIEVzCCAz+gAwIBAgIJAOjuz4hWgg2lMA0GCSqGSIb3DQEBCwUAMIGwMQswCQYD
    VQQDDAJDQTEXMBUGCgmSJomT8ixkARkWB3ZzcGhlcmUxFTATBgoJkiaJk/IsZAEZ
    FgVsb2NhbDELMAkGA1UEBhMCVVMxEzARBgNVBAgMCkNhbGlmb3JuaWExMjAwBgNV
    BAoMKXZ4bGFuLXZtLTExMS0xMDEubmltYnVzLXRiLmVuZy52bXdhcmUuY29tMRsw
    GQYDVQQLDBJWTXdhcmUgRW5naW5lZXJpbmcwHhcNMjAxMjE2MTQyNzU0WhcNMjIx
    MjE3MDIyNzU0WjBBMTIwMAYDVQQDDCl2eGxhbi12bS0xMTEtMTAxLm5pbWJ1cy10
    Yi5lbmcudm13YXJlLmNvbTELMAkGA1UEBhMCVVMwggEiMA0GCSqGSIb3DQEBAQUA
    A4IBDwAwggEKAoIBAQCfMCUOkd3efdX65yEYvWs6vy3ylcR3zhOn3oTqGJci2TjJ
    wKCrGz2rhbFfzgIW+PmSt4VjfqM0F+M6mIVk/c5snQp2VnRfr9GrRFJzFFk2dSnO
    S3in6jjr/Myq44tSMsZ0LYimIj2bSOJxNZvCBqXzf/VZ283bQNMMIMD0XsJoy2D3
    1lxdZT0zBGA6qdu8G1RD5v5Vd/Y7zDgsyoC4zx/PZdOq3DZ2186bHai8CIa3dfiO
    CVGgRh48VfoNcbbFsUQrYUCKzrksnrwHY3hID0AYx9/VOc0izsixZD7oDqcEJrCZ
    /CpvPNvNIwMMvRU/NUKCcwX3j1M6RVUzJUMqi/m7AgMBAAGjgeEwgd4wCwYDVR0P
    BAQDAgOoMDQGA1UdEQQtMCuCKXZ4bGFuLXZtLTExMS0xMDEubmltYnVzLXRiLmVu
    Zy52bXdhcmUuY29tMB0GA1UdDgQWBBTlFURFU/Zm2feG1FofXmYVnqRA/TAfBgNV
    HSMEGDAWgBTdXcADCdBDWl/Ygqo9g1oAlQZV3zBZBggrBgEFBQcBAQRNMEswSQYI
    KwYBBQUHMAKGPWh0dHBzOi8vdnhsYW4tdm0tMTExLTEwMS5uaW1idXMtdGIuZW5n
    LnZtd2FyZS5jb20vYWZkL3ZlY3MvY2EwDQYJKoZIhvcNAQELBQADggEBAL/hKjDK
    +23po4MY3wcWKxnmgIXrvouhIUEiZBILiLFDUIA5nuFMOq4bbUevrWM8Ei9PipPv
    um155WsstZceXVjzCo/UOBjln5WZOwd2UmMWv5PgL4EdUPCD1B3AJsVe0TB8QXTu
    tQXp6oH2g1Ljsva4C8g5kpnFqKnCSQzKqfIz/m/OmsVWn4h+x64XeuhcgK+A3TYy
    YfrLT64onRNN02jywlPRZWcNgJ+bWV5B2OG08ydv9apD+5yuWU2PB+fAoYKJMr8x
    K7AIhafuqZPblV8Sa031+R/CgB4Z59Xl/LJfcBbxukZ1VD0JQChX1/AOL443UxAW
    WYJeXuvZuVESclE=
    -----END CERTIFICATE-----
  clusters:
  - cluster-0
  - cluster-0
  - cluster-0
  datacenter: kubo-dc
  datastore: iscsi-ds-0
  hostname: vxlan-vm-111-101.nimbus-tb.eng.vmware.com
  insecure: true
  ip: 192.168.111.101
  users:
    admin:
      password: Admin!23
      username: administrator@vsphere.local
    master:
      password: '''Mb^T6SVI?[5B**8'''
      username: master@vsphere.local
    opsman:
      password: '''D2*X1YpJFRH$)Tw'''
      username: opsman@vsphere.local
  versions:
    esxi:
      build: '15847429'
      version: 7.0.0
    vcenter:
      build: '15952599'
      version: 7.0.0
  vm folder: pcf_vms
""" % (ip, floating_ip_pools_0, floating_ip_pools_1, shared_id, pod_ip_block_0, pod_ip_block_1)


class TestTKGIShepherdGetLock(TestCase):
    @mock.patch(
        'flashpkg.commands.tkgi.shepherd.Shepherd._Shepherd__execute_cmd_output',
        return_value=(0, stdout_success, None)
    )
    def test_succeed_launch(self, mocked_execute_cmd):
        lock_id = '111-222-333'
        sheep = Shepherd(USERNAME, False)
        details = sheep.get_lock(lock_id)

        lock = ShepherdLock(details)

        self.assertEqual(lock.find('network.routers.t0-shared.id'), shared_id)
        self.assertEqual(lock.find('network.routers.t0-shared.floating ip pools')[0], floating_ip_pools_0)
        self.assertEqual(lock.find('network.routers.t0-shared.floating ip pools')[1], floating_ip_pools_1)
        self.assertEqual(lock.find('network.routers.t0-shared.pod ip blocks')[0], pod_ip_block_0)
        self.assertEqual(lock.find('network.routers.t0-shared.pod ip blocks')[1], pod_ip_block_1)
        self.assertEqual(lock.get_jumper_vm_host(), ip)
