import shutil
from unittest import mock, TestCase, skip
from flashpkg.commands.tkgi.shepherd import Shepherd, ShepherdError
from flashpkg.commands.tkgi.tkgi import PrerequisitesError

USERNAME = 'test_username'

def mock_is_sheepctl_installed(*args):
    pass

class TestTKGIShepherd(TestCase):
    @mock.patch(
        'flashpkg.commands.tkgi.shepherd.Shepherd._Shepherd__is_sheepctl_installed'
    )
    def test_init(self, mocked_installed):
        Shepherd(USERNAME)
        mocked_installed.assert_called_once()

    @mock.patch('flashpkg.commands.tkgi.shepherd.which', return_value=False)
    def test_is_sheepctl_not_installed(self, mocked_which):
        with self.assertRaises(PrerequisitesError) as context:
            Shepherd(USERNAME)

        self.assertTrue('sheepctl tool isn\'t installed' in str(context.exception))

    @mock.patch('flashpkg.commands.tkgi.shepherd.Shepherd._Shepherd__is_sheepctl_installed', side_effect=mock_is_sheepctl_installed)
    def test_create_user(self, mocked_installed):
        cmd = f'sheepctl target set -n {USERNAME} -u shepherd.run'
        obj = Shepherd(USERNAME)
        with mock.patch.object(Shepherd, '_Shepherd__execute_cmd', return_value=(0, 'test', 'test')) as mocked_exec_cmd:
            obj.create_user()
        mocked_exec_cmd.assert_called_once_with(cmd)

    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__execute_cmd', return_value=(1, 'test', 'test'))
    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__is_sheepctl_installed', side_effect=mock_is_sheepctl_installed)
    def test_create_user_fail(self, mocked_installed, mocked_exec_cmd):
        cmd = f'sheepctl target set -n {USERNAME} -u shepherd.run'
        obj = Shepherd(USERNAME)
        with self.assertRaises(ShepherdError) as context:
            obj.create_user()

        mocked_exec_cmd.assert_called_once_with(cmd)
        self.assertTrue('Error creating shepard user!' in str(context.exception))

    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__execute_cmd', return_value=(0, 'test', 'test'))
    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__is_sheepctl_installed', side_effect=mock_is_sheepctl_installed)
    def test_create_lock(self, mocked_installed, mocked_exec_cmd):
        lock_file = '/path/to/lock/file'
        pattern = 'Lock request accepted with ID (.*?)$'

        cmd = f"sheepctl lock create -f {lock_file} --lifetime 72h"

        obj = Shepherd(USERNAME)
        obj.create_lock(lock_file)

        mocked_exec_cmd.assert_called_once_with(cmd, pattern)

    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__execute_cmd', return_value=(1, 'test', 'test'))
    @mock.patch('flashpkg.commands.tkgi.tkgi.Shepherd._Shepherd__is_sheepctl_installed', side_effect=mock_is_sheepctl_installed)
    def test_create_lock_failed(self, mocked_installed, mocked_exec_cmd):
        lock_file = '/path/to/lock/file'
        pattern = 'Lock request accepted with ID (.*?)$'

        cmd = f"sheepctl lock create -f {lock_file} --lifetime 72h"

        obj = Shepherd(USERNAME)

        with self.assertRaises(ShepherdError) as context:
            obj.create_lock(lock_file)

        mocked_exec_cmd.assert_called_once_with(cmd, pattern)
        self.assertTrue('Error creating lock!' in str(context.exception))
