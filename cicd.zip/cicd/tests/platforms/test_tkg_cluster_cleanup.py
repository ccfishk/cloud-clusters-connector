import unittest

from unittest import mock
from flashpkg.platforms import tkg

cluster_name = 'test_cluster_name'
def mocked_get_status(*args):
    return None

def mocked_tkg_remove_cluster(*args):
    return None


tkg_remove_error_message = 'Error when removing clusters, code: 1, response: Some error response'
def mocked_tkg_remove_cluster_raise_error(*args):
    raise Exception(tkg_remove_error_message)

class TestTKGClusterCleanup(unittest.TestCase):
    @mock.patch('flashpkg.platforms.tkg.get_status', side_effect=mocked_get_status)
    @mock.patch('flashpkg.platforms.tkg.tkg_remove_cluster', side_effect=mocked_tkg_remove_cluster)
    def test_cleanup(self, mock_tkg_remove, mock_get_status):
        rc = tkg.cleanup(cluster_name)

        self.assertEqual(rc, 0)
        mock_tkg_remove.assert_called_once_with(cluster_name)
        mock_get_status.assert_called_once_with(cluster_name)

    @mock.patch('flashpkg.platforms.tkg.get_status', side_effect=mocked_get_status)
    @mock.patch('flashpkg.platforms.tkg.tkg_remove_cluster', side_effect=mocked_tkg_remove_cluster_raise_error)
    @unittest.skip('Not yet implemented')
    def test_tkg_remove_cluster(self, mock_tkg_remove_error, mock_get_status):
        with self.assertRaises(Exception) as context:
            rc = tkg.cleanup(cluster_name)

        self.assertTrue(tkg_remove_error_message in str(context.exception))

        self.assertEqual(rc, 1)
