import os
import uuid
import unittest
import socket
import http.client
from unittest import mock
from flashpkg import cspService
from flashpkg.state import state

TENANTS = '[{"tenantID": "123456", "userEmail": "dummy1@invalid.web"}, {"tenantID": "abcdef", "userEmail": "dummy2@invalid.web"}]'
TOKEN = 'abcd1234-9876-0000'

class MockResponse:
    def __init__(self, status_code):
        self.status = status_code

    def read(self):
        return TENANTS.encode('utf-8')


class TestCsp(unittest.TestCase):

    def mocked_token(*args, **kwargs):
        return TOKEN

    def mocked_conn_resp(*args, **kwargs):
        if 'status_code' in kwargs.keys():
            resp = MockResponse(kwargs['status_code'])
        else:
            resp = MockResponse(200)
        return resp

    @mock.patch("flashpkg.state.state.get_csp_access_token", side_effect=mocked_token)   
    def test_list_tenant_invalid_host(self, mock_token):
        with self.assertRaises(socket.gaierror):
            cspService.listTenants('invalid.host', True, None)

    @mock.patch("http.client.HTTPSConnection.getresponse", side_effect=mocked_conn_resp(status_code=400))
    @mock.patch("flashpkg.state.state.get_csp_access_token", side_effect=mocked_token)   
    def test_list_tenant_error_response(self, mocked_conn, mock_token):
        with self.assertRaises(TypeError):
            cspService.listTenants('www.google.com', True, None)

    @mock.patch("http.client.HTTPSConnection.getresponse", side_effect=mocked_conn_resp)
    @mock.patch("flashpkg.state.state.get_csp_access_token", side_effect=mocked_token)   
    def test_valid_response(self, mocked_conn, mock_token):
        self.assertEqual(cspService.deleteTenant('www.google.com', 'Test'), None)
        self.assertEqual(cspService.listTenants('www.google.com', False, None), None)


if __name__ == '__main__':
    unittest.main()
