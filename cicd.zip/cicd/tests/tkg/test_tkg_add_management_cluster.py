import unittest

from unittest import mock
from flashpkg import tkg
import subprocess

TKG_CLI_CMD = 'tkg'

cluster_name = 'my_cluster_name'
kubeconfig = '/kube/config/to/merge'

tkg_add_error = 'Exception occurred during adding management cluster: error: some error'
def mocked_run_cmd_add_error(*args):
    if [TKG_CLI_CMD, 'add', 'management-cluster', '--kubeconfig', kubeconfig] == [*args]:
        raise subprocess.CalledProcessError(
            cmd=f'{TKG_CLI_CMD} add management-cluster --kubeconfig {kubeconfig}', output=tkg_add_error.encode('utf-8'), returncode=1)


tkg_set_error = 'Exception occurred during setting management cluster: error: some error'
def mocked_run_cmd_set_error(*args):
    if [TKG_CLI_CMD, 'set', 'management-cluster', cluster_name] == [*args]:
        raise subprocess.CalledProcessError(
            cmd=f'{TKG_CLI_CMD} set management-cluster {cluster_name}', output=tkg_set_error.encode('utf-8'), returncode=1)


def mocked_tkg_set_management_cluster(*args):
    return None

def mocked_tkg_add_management_cluster(*args):
    return None

class TestTKGAddManagementCluster(unittest.TestCase):
    @mock.patch("flashpkg.tkg.tkg_add_management_cluster", side_effect=mocked_tkg_add_management_cluster)
    @mock.patch("flashpkg.tkg.tkg_set_management_cluster", side_effect=mocked_tkg_set_management_cluster)
    def test_add_management_cluster(self, mocked_tkg_set, mocked_tkg_add):
        tkg.add_management_cluster(cluster_name, kubeconfig)

        mocked_tkg_set.assert_called_once_with(cluster_name)
        mocked_tkg_add.assert_called_once_with(kubeconfig)

    @mock.patch("flashpkg.tkg.run_cmd", side_effect=mocked_run_cmd_add_error)
    def test_add_management_cluster_raise_add_error(self, mocked_run_cmd):
        with self.assertRaises(Exception) as context:
            tkg.add_management_cluster(cluster_name, kubeconfig)

        self.assertTrue(tkg_add_error in str(context.exception))

    @mock.patch("flashpkg.tkg.tkg_add_management_cluster", side_effect=mocked_tkg_add_management_cluster)
    @mock.patch("flashpkg.tkg.run_cmd", side_effect=mocked_run_cmd_set_error)
    def test_add_management_cluster_raise_set_error(self, mocked_run_cmd, mocked_tkg_add):
        with self.assertRaises(Exception) as context:
            tkg.add_management_cluster(cluster_name, kubeconfig)

        self.assertTrue(tkg_set_error in str(context.exception))


if __name__ == '__main__':
    unittest.main()
