import unittest

from unittest import mock
from flashpkg import tkg

cluster_name = 'my_cluster_name'
kubeconfig = "path/to/cpnfig"

def mocked_docopt(*args):
    return {
        'add': True,
        'management-cluster': True,
        'tkg': True,
        '<cluster_name>': cluster_name,
        '--kubeconfig': kubeconfig
    }

def mock_does_tkg_kubeconfig_exist(*args):
    return None

def mock_is_tkg_cli_installed():
    return None


error = "Prerequisites error"
def mock_tkg_cli_not_installed():
    raise Exception(error)

class TestTKGProcess(unittest.TestCase):
    @mock.patch("flashpkg.tkg.docopt", side_effect=mocked_docopt)
    @mock.patch("flashpkg.tkg.does_tkg_kubeconfig_exist", side_effect=mock_does_tkg_kubeconfig_exist)
    @mock.patch("flashpkg.tkg.is_tkg_cli_installed", side_effect=mock_is_tkg_cli_installed)
    def test_process_point_to_add_management_cluster(self, mocked_docopt, mock_check_requirements, mock_is_tkg):
        with mock.patch.object(tkg, "add_management_cluster", return_value=None) as mocked_add_management_cluster:
            tkg.process()

        mocked_add_management_cluster.assert_called_once_with(cluster_name, kubeconfig)

    @mock.patch("flashpkg.tkg.docopt", side_effect=mocked_docopt)
    @mock.patch("flashpkg.tkg.does_tkg_kubeconfig_exist", side_effect=mock_does_tkg_kubeconfig_exist)
    @mock.patch("flashpkg.tkg.is_tkg_cli_installed", side_effect=mock_tkg_cli_not_installed)
    def test_process_tkg_not_installed(self, mocked_docopt, mock_check_requirements, mock_is_tkg):
        with self.assertRaises(Exception) as context:
            tkg.process()

        self.assertTrue(error in str(context.exception))


if __name__ == '__main__':
    unittest.main()
