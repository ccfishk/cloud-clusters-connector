import unittest
from random import randint
from flashpkg import cloud
import os

global_store_name = 'teststore' + str(randint(0, 99999))
test_file_name = 'store_test_file' + str(randint(0, 99999)) + '.txt'
print('Storage Test will work on temporary storage: %s' % global_store_name)


class TestStorage(unittest.TestCase):

    def setUp(self):
        self.store_name = global_store_name
        self.file_name = test_file_name
        self.file_path = '/tmp/' + self.file_name
        f = open(self.file_path, "w+")
        f.close()

    def tearDown(self):
        if os.path.exists(self.file_path):
            os.remove(self.file_path)
        pass

    def test_1_create_store(self):
        res = cloud.storage.create(self.store_name)
        self.assertEqual(res, 0)

    def test_2_store_upload(self):
        res = cloud.storage.upload(
            self.store_name, self.file_path, self.file_name)
        self.assertEqual(res, 0)

    def test_3_store_download(self):
        res = cloud.storage.download(
            self.store_name, self.file_name, self.file_path)
        self.assertEqual(res, 0)

    def test_4_store_upload(self):
        res = cloud.storage.upload(
            self.store_name, self.file_path, self.file_name + '-public',
            "--public")
        self.assertEqual(res, 0)

    def test_5_store_upload(self):
        res = cloud.storage.upload(
            self.store_name, self.file_path, self.file_name + '-public',
            "--public",
            "--force")
        self.assertEqual(res, 0)

    def test_6_store_download(self):
        res = cloud.storage.download(
            self.store_name, self.file_name, self.file_path + '-public')
        self.assertEqual(res, 0)

    def test_7_delete_file(self):
        res = cloud.storage.delete(self.store_name, self.file_path + '-public')
        self.assertEqual(res, 0)

    def test_8_delete_repo(self):
        res = cloud.storage.delete(self.store_name, None)
        self.assertEqual(res, 0)
        pass


if __name__ == '__main__':
    unittest.main()
