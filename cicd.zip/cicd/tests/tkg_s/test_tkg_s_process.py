from unittest import mock, TestCase, skip
from flashpkg import tkg_s
from docopt import DocoptExit

help_message = """Usage:
    flash tkgs login <sc_ip> <username> <password>"""

def mock_docopt_login(*args):
    return {
        '<password>': 'PasswordTest',
        '<sc_ip>': '10.10.10.10',
        '<username>': 'UsernameTest',
        'client': False,
        'login': True,
        'tkgs': True,
    }

def mock_which(*args):
    return False

def mock_vsphere_validation(*args):
    return True

def mock_login_success(*args):
    return 0

def mock_login_raises_error(*args):
    raise tkg_s.LoginError('Test Error message', 1)

class TestTKGSProcessLogin(TestCase):
    def test_process_help(self):
        with self.assertRaises(DocoptExit) as context:
            tkg_s.process()

        self.assertTrue(help_message in str(context.exception))

    @skip
    @mock.patch("flashpkg.tkg_s.docopt", side_effect=mock_docopt_login)
    @mock.patch("flashpkg.tkg_s.is_kubectl_vsphere_installed", side_effect=mock_vsphere_validation)
    @mock.patch("flashpkg.tkg_s.login", side_effect=mock_login_success)
    def test_login_succeed(self, mocked_docopt, mocked_vsphere, mocked_login):
        exit_code = tkg_s.process()
        self.assertEqual(exit_code, 0)

    @skip
    @mock.patch("flashpkg.tkg_s.docopt", side_effect=mock_docopt_login)
    @mock.patch("flashpkg.tkg_s.is_kubectl_vsphere_installed", side_effect=mock_vsphere_validation)
    @mock.patch("flashpkg.tkg_s.login", side_effect=mock_login_raises_error)
    def test_login_failed(self, mocked_docopt, mocked_vsphere, mocked_login):
        exit_code = tkg_s.process()
        self.assertEqual(exit_code, 1)


cluster_name = "my_cluster"
cluster_namespace = "my_cluster_namespace"
sc_ip = '10.10.10.10'
username = 'UsernameTest'
password = 'PasswordTest'
def mock_docopt_client_login(*args):
    return {
        '<password>': password,
        '<sc_ip>': sc_ip,
        '<username>': username,
        'client': True,
        'login': True,
        'tkgs': True,
        '<cluster_name>': cluster_name,
        '<cluster_namespace>': cluster_namespace
    }

class TestTKGSProcessClientLogin(TestCase):
    @skip
    @mock.patch("flashpkg.tkg_s.login_client")
    @mock.patch("flashpkg.tkg_s.docopt", side_effect=mock_docopt_client_login)
    def test_client_login_invoked(self, mocked_docopt_client_login, mocked_login_client):
        tkg_s.process()

        mocked_login_client.assert_called_once_with(sc_ip, cluster_name, cluster_namespace, username, password)

    @mock.patch("flashpkg.tkg_s.docopt", side_effect=mock_docopt_client_login)
    def test(self, mocked_docopt_client_login):
        tkg_s.process()
