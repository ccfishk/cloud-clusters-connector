from unittest import TestCase, mock
from flashpkg.platforms import tkgs
from flashpkg.config import config

cluster_name = 'my_tkgs_cluster'
namespace = 'test-gc-e2e-demo-ns'
context = 'test-gc-e2e-demo-ns'


def mocked_apply_config_failed(*args):
    return 1

def mocked_apply_config_succeed(*args):
    return 0

def mocked_substitute(*args):
    return 'mocked_substitute'

class TestTKGSStart(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.flavor = config.get_flavor('tkgs_small')

    @mock.patch("flashpkg.platforms.tkgs.apply_config", side_effect=mocked_apply_config_failed)
    def test_start_failed(self, mock_apply_config):
        res = tkgs.start(cluster_name, namespace, context, self.flavor)

        self.assertEqual(res, 1)
        mock_apply_config.assert_called_once()

    @mock.patch("flashpkg.platforms.tkgs.string.Template.substitute", side_effect=mocked_substitute)
    @mock.patch("flashpkg.platforms.tkgs.apply_config", side_effect=mocked_apply_config_succeed)
    def test_start_substitute(self, mock_apply_config, mock_template_substitute):
        res = tkgs.start(cluster_name, namespace, context, self.flavor)

        data = dict(
            cluster_name=cluster_name,
            namespace=namespace,
            version=self.flavor.get('version'),
            control_plane=self.flavor.get('control_plane'),
            control_plane_class=self.flavor.get('control_plane_class'),
            control_plane_storage_class=self.flavor.get('control_plane_storage_class'),
            workers=self.flavor.get('workers'),
            workers_class=self.flavor.get('workers_class'),
            workers_storage_class=self.flavor.get('workers_storage_class'),
            cni_name=self.flavor.get('cni_name'),
            services_cidr_blocks=self.flavor.get('services_cidr_blocks'),
            pods_cidr_blocks=self.flavor.get('pods_cidr_blocks')
        )

        mock_template_substitute.assert_called_once_with(data)

    @mock.patch("flashpkg.platforms.tkgs.apply_config", side_effect=mocked_apply_config_succeed)
    def test_start_succeed(self, mock_apply_config):
        res = tkgs.start(cluster_name, namespace, context, self.flavor)

        self.assertEqual(res, 0)
        mock_apply_config.assert_called_once()
