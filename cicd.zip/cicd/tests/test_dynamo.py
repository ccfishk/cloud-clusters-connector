import unittest
from flashpkg.aws.dynamo import Dynamo

class TestDynamo(unittest.TestCase):
    testTableName = 'ddb-test-table'
    ddb = Dynamo(tableName=testTableName, bsize=3)

    def testCleanupExisting(self):
        tbl = TestDynamo.ddb.getTable()
        if tbl is not None:
            TestDynamo.ddb.deleteTable()

        print("testCreateTable")
        TestDynamo.ddb.createCICDTable()
        print("testRepeateCreateTable")
        with self.assertRaises(Exception) as context:
            TestDynamo.ddb.createCICDTable()
        self.assertTrue("Table Already exists when create table is called" ==  "%s" % context.exception)
        print("testLoadSingleUserWhenEmpty")
        ft = TestDynamo.ddb.loadUserTable('bob')
        self.assertTrue(ft == {})
        print("testAddTableEntries")
        for uid in range(0, 10):
            for cid in range(0, 10):
                TestDynamo.ddb.upsertItem('bob-%d' % uid, 'cluster-%d' % cid, {
                    "region": 'us-%d' % uid,
                    "zone": 'zone-%d' % cid
                })
        print("testVerifyFullRead")
        ft = TestDynamo.ddb.loadFullTable()
        self.assertTrue(len(ft) == 10)
        for itmkey in ft:
            val = ft[itmkey]
            self.assertTrue(len(val) == 10)
        print("testVerifyUserRead")
        ft = TestDynamo.ddb.loadUserTable('bob-1')
        self.assertTrue(len(ft) == 10)
        print("testDeleteItem")
        TestDynamo.ddb.deleteItem('bob-2', 'cluster-1')
        ft = TestDynamo.ddb.loadUserTable('bob-2')
        self.assertTrue(len(ft) == 9)

        print("testDeleteTable")
        TestDynamo.ddb.deleteTable()

        print("testRepeateDeleteTable")
        TestDynamo.ddb.deleteTable()
