import json
import unittest
from unittest.mock import patch
from flashpkg import docker


class TestDocker(unittest.TestCase):
    os_environ = {
        'APPCHECK_USERNAME': 'servicemesh@vmware.com',
        'APPCHECK_PASSWORD': 'my-password',
    }
    appcheck_resp = {
        'meta': {
            'code': 200
        },
        'results': {
            'report_url': 'http://localhost/1234'
        }
    }

    @patch("flashpkg.docker.__client")
    def test_prune_images(self, mock_docker):
        status = docker.prune_images()
        self.assertEqual(status, 0)

    @patch("flashpkg.docker.__client")
    def test_prune_containers(self, mock_docker):
        status = docker.prune_containers()
        self.assertEqual(status, 0)

    @patch("flashpkg.docker.__client")
    def test_prune_volumes(self, mock_docker):
        status = docker.prune_volumes()
        self.assertEqual(status, 0)

    @patch("flashpkg.docker.__client")
    def test_delete_image(self, mock_client):
        status = docker.delete_image("test")
        self.assertEqual(status, 0)

    @patch("flashpkg.docker.__client")
    @patch("flashpkg.docker.os")
    @patch("flashpkg.docker.requests")
    @patch("builtins.open")
    @patch.object(json, 'loads', return_value=appcheck_resp)
    @patch.dict('os.environ', os_environ)
    def test_scan_image(self, mock_client, mock_os, mock_request, mock_open, mock_reply):
        status = docker.scan_image("busybox:latest")
        self.assertEqual(status, 0)


if __name__ == '__main__':
    unittest.main()
