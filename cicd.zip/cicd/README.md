# Flash

[![Quality Gate Status](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=alert_status)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Bugs](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=bugs)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Code Smells](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=code_smells)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Duplicated Lines (%)](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=duplicated_lines_density)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Lines of Code](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=ncloc)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Maintainability Rating](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=sqale_rating)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Reliability Rating](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=reliability_rating)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Security Rating](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=security_rating)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Technical Debt](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=sqale_index)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)
[![Vulnerabilities](https://nsxsm.svc.eng.vmware.com/api/project_badges/measure?project=flash&metric=vulnerabilities)](https://nsxsm.svc.eng.vmware.com/dashboard?id=flash)

Contains the flash CLI which provides various capabilities:

* nsxsm lifecycle management
* csp management
* cloud infra resource cleanup
* cloud build
* cloud storage
* cloud registry
* cloud containers
* docker cleanup
* cluster management
  * k8s
    * kops
    * cpks
    * pks (enterprise)
    * eks
  * cf

## Installation

Flash uses Python 3 now that Python 2 is EOL as of 2020. No version lower than 3.6 is supported.
If you're installing natively on OSX then you'll need to install some extra dependencies from brew. This is because there are some extra build tools needed to build some of the dependencies.
Follow instructions on this page https://docs.python-guide.org/starting/install3/osx/ to install Python3 from Homebrew.
```
make macsetup
make install
```

For any other platform the below should work.
```
make install
```

To install the extras:
```
pip3 install -e .[extras]
```

Flash requires:
 * [kops](https://github.com/kubernetes/kops) to be installed for launching KOPS clusters in AWS.
 * [awscli](https://pypi.org/project/awscli/) version 1.16.156 or greater (this has EKS support)
 * [eksctl](https://github.com/weaveworks/eksctl#installation) to be installed for launching EKS clusters in AWS
 * [aws-iam-authenticator](https://docs.aws.amazon.com/eks/latest/userguide/install-aws-iam-authenticator.html) to be able to manage EKS clusters.
 * [velero](https://github.com/vmware-tanzu/velero/releases/tag/v1.1.0) CLI tool to perform any cluster wide backup/restore operations, especially for the below commands. Velero v1.1.0 is the current recommended (and required) version for this tool.
   ** flash nsxsm list backups
   ** flash nsxsm list restores
   ** flash nsxsm restore tenant

## Uninstallation

```
make uninstall
```

## Usage

Flash now has state tracking built in. If you don't have a state file already the tool will create one at `~/.flash.state.conf`.

Set the following enviorment variables:
```
AWS_ACCESS_KEY_ID=<ACCESS_KEY>
AWS_SECRET_ACCESS_KEY=<SECRET_KEY>
ALLSPARK_PASSWORD=<Password>
```

### Flash

Run `flash` to see the usage:
```
Usage:
  flash <command>...

Commands:
  flash list flavors    : list all of the flavors defined in the config.
  flash list testbeds   : list all of the testbeds defined in the config.
  flash container       : commands to interact with a CI container on the cloud.
  flash runner          : commands to interact with the VM hosting the CI containers on the cloud.
  flash jn              : commands to interact with jn on the cloud.
  flash build           : commands to interact with codebuild in the cloud.
  flash bbl             : commands to interact with "bbl".
  flash cluster         : commands to manage clusters of different types/flavors.
  flash repo            : commands to interact with container registry on the cloud.
  flash storage         : commands to interact with cloud storage.
  flash docker          : commands to interact with Docker.
  flash csp             : commands to interact with Common Services Platfrom.
  flash nsxsm           : commands to install and configure allspark services.
  flash dns             : commands to add delete cname DNS records in AWS route53
```

### Flash container

Run `flash container` to see the usage:
```
Usage:
  flash container status <name>
  flash container stop <name>
  flash container start <name> <commit_id>
  flash container run <name> <cmd>
  flash container shell <name>
  flash container cp <name> <from> <to>
  flash container cpto <name> <from> <to>

Description:
  flash container : commands to interact with a CI container on the cloud.
```

### Flash runner

Run `flash runner` to see the usage:
```
Usage:
  flash runner get vmname <name>
  flash runner get ip <name>
  flash runner get id <name>
  flash runner get key

Description:
  flash runner : commands to interact with the VM hosting the CI containers on the cloud.
```

### Flash jn

Run `flash jn` to see the usage:
```
Usage:
  flash jn start <name> <commit_id>
  flash jn stop <name>
  flash jn tunnel <name> [--local=<local_port> --remote=<remote port>]

Description:
  flash jn : commands to interact with jn on the cloud.

Options:
  --local=<local port>                 local port to forward tunnel traffic [default: 8888].
  --remote=<remote port>               remote port from which to forward tunnel traffic [default: 8888].
```

### Flash build

Run `flash build` to see the usage:
```
Usage:
  flash build <name> <commit_id> <build_command> <runner_image> <artifacts_folder> <artifacts_cloud_storage_location>

Description:
  flash build : commands to interact with codebuild in the cloud.
```

For code build in the cloud:
```
create a service role for code build using the following guide
https://docs.aws.amazon.com/codebuild/latest/userguide/setting-up.html

stick it in your `.flash.conf`
cloud_build_arn=

also setup the image type for your build container in the config

cloud_build_image_type=BUILD_GENERAL1_LARGE or BUILD_GENERAL1_SMALL or BUILD_GENERAL1_MEDIUM
```

### Flash bbl

Run `flash bbl` to see the usage:
```
Usage:
  flash bbl start bosh <name> [--cloud]
  flash bbl start cf <name> [--cloud]
  flash bbl cleanup <name> [--cloud]

Description:
  flash bbl : commands to interact with "bbl".

Options:
  --cloud   Run the command remotely in the cloud.
```

### Flash cluster

Run `flash cluster` to see the usage:
```
Usage:
  flash cluster create using flavor <flavor_name> <cluster_name> [--cloud --region=<region> --zones=<zones>]
  flash cluster status <cluster_name> [--cloud]
  flash cluster envsetup <cluster_name> [--cloud --external_cluster=<cluster_type>]
  flash cluster cleanup <cluster_name> [--cloud --external_cluster=<cluster_type> --region=<region> --assume-yes]
  flash cluster list [--cloud]

Description:
  flash cluster : commands to manage clusters of different types/flavors. Builtin flavors are kops_small, kops_medium, kops_large, cpks_privileged, and cpks_unprivileged.

Options:
  --cloud                              Run the command remotely in the cloud. WARNING: this is not yet implemented.
  --region=<region>                    Specifies the region to use.
  --assume-yes                         Assume "yes" for any confirmation prompts.
  --external_cluster=<cluster_type>    Specifies the external cluster type to work with. This could be kops, cpks, etc.
```

### Flash repo

Run `flash repo` to see the usage:
```
Usage:
  flash repo login <repo_name>
  flash repo remove <repo_name> <commit_id>
  flash repo url <repo_name>
  flash repo create <repo_name>
  flash repo delete <repo_name>
  flash repo list <repo_name>

Description:
  flash repo : commands to interact with container registry on the cloud.
```

### Flash storage

Run `flash storage` to see the usage:
```
Usage:
  flash storage create <store_name>
  flash storage delete <store_name>
  flash storage upload <store_name> <source_file> <destination_file>
  flash storage download <store_name> <source_file> <destination_file>

Description:
  flash storage : commands to interact with cloud storage.
```

### Flash docker

Run `flash docker` to see the usage:
```
Usage:
  flash docker cleanup images
  flash docker cleanup containers
  flash docker cleanup volumes
  flash docker delete image <image_id>
  flash docker build <name> <version> <dockerfile>
  flash docker publish <name> <version>

Description:
  flash docker : commands to interact with Docker.
```

### Flash csp

Run `flash csp` to see the usage:
```
Usage:
  flash csp set orgid <org_id>
  flash csp get access token <refresh_token>
  flash csp register service <csp_service_name> <csp_service_display_name> <service_url> <service_description>
  flash csp register service <service_definition_yaml_file>
  flash csp unregister service <csp_service_name>
  flash csp getinvite service <csp_service_name> [--cnt=<cnt>]
  flash csp get service <csp_service_name> [--displayname]
  flash csp list services [--expand --all --names --name=<service_name>]
  flash csp register client <client_name> <csp_service_name> <client_secret> <redirect_url>
  flash csp register client <client_definition_json_file>
  flash csp unregister client <client_name>
  flash csp get client <client_name>

Description:
  flash csp : commands to interact with Common Services Platfrom.

Options:
  --cnt=<cnt>                      Number of invites to generate.
  --displayname                    Show the display name.
  --expand                         Expand services.
  --all                            Show all services.
  --names                          Show names.
  --name=<service_name>            Show name where name is equal to <service_name>.
```

### Flash nsxsm

Run `flash nsxsm` to see the usage:
```
Usage:
  flash nsxsm config apply <config_file_path> [--template_dir=<template_dir> --template_file=<template_file> --output_dir=<output_dir>]
  flash nsxsm install <nsxsm_version> <cluster_name> <ingress_dns> <api_dns>
  flash nsxsm install tenants <num_tenants> <tenant_name_prefix> <saas_cluster_name> [--password=<password>]
  flash nsxsm install tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password>]
  flash nsxsm list tenants <saas_cluster_name>
  flash nsxsm list tenant clusters <saas_cluster_name> <tenant_id>
  flash nsxsm init tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password>]
  flash nsxsm deinit tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password>]
  flash nsxsm uninstall tenant cluster <saas_cluster_name> <client_cluster_name> <username> [--password=<password>]
  flash nsxsm uninstall tenant <tenant_name> <saas_cluster_name>
  flash nsxsm uninstall <cluster_name>
  flash nsxsm upgrade tenant <saas_cluster_name> <tenant_id> <nsxsm_version> [--force]

Description:
  flash nsxsm : commands to install and configure allspark services.

Options:
  --istio=<istio_type>                 Specifies whether to install minimal or full Istio [default: minimal].
  --password=<password>                Password to use for the user(s). Defaults to the username as displayed during provisioning.
  --template_dir=<template_dir>        Specifies the directory that holds templates to be modified.
  --template_file=<template_file>      Specifies the template file to be modified.
  --output_dir=<output_dir>            Specifies the output directory to use.
```

### Flash dns

Run `flash dns` to see the usage:
```
Usage:
  flash dns add cname <zone_id> <cname> <value>
  flash dns remove cname <zone_id> <cname> <value>
  flash dns list zones
  flash dns list record_sets <zone_id> [--record_type=<record_type>]
  flash dns test answer <zone_id> <record_name> <record_type>

Description:
  flash dns : commands to add delete cname DNS records in AWS route53

Options:
  --record_type=<record_type>   DNS record type (for e.g. NS, SOA, CNAME etc.). Returns all record types by default.
```

### Flash cleanup

Run `flash cleanup` to see the usage:
```Usage:
  flash cleanup infra [<tag_key> <tag_values>]... [--region=<region> --assume-yes]

Description:
  flash cleanup : Clean up provisioned resources on cloud infra.

Options:
  --region=<region>     Specifies the region to use.
  --assume-yes          Assume "yes" for any confirmation prompts.
```
This command supports multiple tag filters and keys.
For e.g. to just filter on elements with tag `cid` with value `1234` you can use `flash cleanup infra cid 1234`.
To filter on elements with tag `cid` with values `1234` or `abcd` you can use `flash cleanup infra cid 1234,abcd`
To filter on elements with tag cid with value `1234` and tid with values `abcd` or `dead-beef` you can use `flash cleanup infra cid 1234 tid abcd,dead-beef`

## Docker Usage

Example of running from Docker:
```
docker run -it -e ALLSPARK_FLASH_CONFIG=/.flash.conf -e ALLSPARK_FLASH_STATE=/.state.conf -e AWS_SECRET_ACCESS_KEY=<YOUR_KEY> -e AWS_ACCESS_KEY_ID=<YOUR_KEY> -v /path/to/your/.state.conf:/.state.conf -v /path/to/your/.flash.conf:/.flash.conf 284299419820.dkr.ecr.us-west-2.amazonaws.com/cicd:latest flash <YOUR COMMANDS>
```

## Known Issues

