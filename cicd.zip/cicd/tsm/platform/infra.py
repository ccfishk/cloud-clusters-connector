
import time
from flashpkg import nsxsmOps
from kubernetes import client, config

DEFAULT_PERIOD = 3.0  # 3 seconds

def get_lb(cluster_name, namespace, timeout_in_seconds, selector,
           context=None, period_in_seconds=DEFAULT_PERIOD, is_eks=False):
    """Return API GW from cluster info"""
    if not context:
        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    end_time = time.time() + timeout_in_seconds
    selector = 'metadata.name=' + selector
    while time.time() < end_time:
        ret = v1.list_namespaced_service(namespace, field_selector=selector)
        for i in ret.items:
            # Always only one item will be returned ?
            if i.status.load_balancer.ingress:
                return i.status.load_balancer.ingress[0].hostname
        time.sleep(period_in_seconds)
