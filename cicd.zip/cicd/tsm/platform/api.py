import os
from flashpkg.allspark_api import AllsparkApi
from flashpkg import utils
from tsm.platform.infra import get_lb
import time

verbose_flag = False
LB_TIMEOUT = 60
DEFAULT_USERNAME = 'admin'
ENV_PASSWORD_KEY = "ALLSPARK_PASSWORD"
LB_SELECTOR = 'global-api-gateway'

def get_password():
    return os.environ.get(ENV_PASSWORD_KEY, None)

def setup(saas_cluster_name, username=DEFAULT_USERNAME, password=None, verbose=False):
    """Setup and login to API GW"""
    if not password:
        password = get_password()
    if not password:
        print(f"Please set the {ENV_PASSWORD_KEY} environment variable for the default allspark admin user")
        return None

    api_gw = get_lb(saas_cluster_name, utils.OPERATOR_NAMESPACE, LB_TIMEOUT, LB_SELECTOR)
    assert api_gw is not None

    api = AllsparkApi(api_gw, verbose=verbose)
    assert wait_global_api_online(api) == 0, "failed to get a live api-gw"
    # TODO: Until CSP authenticated admin/operator user role is available, need to disable this
    # Commenting out the following lines since admin support is not available on CSP
    # Until then we need to continue using this backdoor
    # r = api.check_csp_auth()
    # if r.status_code == 200 and r.json()['csp']:
    # TODO: Handle csp authenticated APIs`
    #    print("CSP flow currently not supported")
    #    return None
    # else:

    r = api.login(username, password)
    if r.status_code != 200:
        print("Failed to login to API service. Please check your password")
        return None

    return api

def wait_global_api_online(api):
    """Wait until global api is ready"""
    TOTAL_TRIES = 10
    count = TOTAL_TRIES
    while count > 0:
        try:
            r = api.get_global_gw_version()
            if verbose_flag:
                print('gw response')
                print(r)
            assert r.status_code == 200, 'did not get 200 from version api'
            assert len(r.json()) > 0, 'failed gw version call, should report service versions array'
            if verbose_flag:
                print('continuing')
            return 0
        except BaseException as err:
            print('error getting global-gw version, trying again {}'.format(count))
            print(err)
            time.sleep(10)
            count = count - 1
    raise Exception('api gw was not up after {}'.format(TOTAL_TRIES))
