import os
import sys
import signal
import time
import requests
import json
import errno
from functools import wraps
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import urllib3
import urllib.parse
from urllib.parse import urlencode, urlparse

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # Otherwise we flood the user with warnings.
DEFAULT_TIMEOUT = 15 * 60

def logAndExit(err, response, missing):
    print("error: ", err)
    print("response: ", response)
    print("missing: ", missing)
    sys.exit(1)

class AllsparkApi(object):
    def __init__(self, server_root, api_token=None, verbose=False):
        self.server_root = server_root
        self.api_token = api_token
        self.verbose = verbose

    def __request(self, verb, uri, params=None, data=None, verify=False, header=None):
        r = None
        try:
            retry_policy = Retry(total=3, status_forcelist=[
                                 418], raise_on_status=False)
            session = requests.Session()
            session.mount("https://", HTTPAdapter(max_retries=retry_policy))
            headers = {'Accept': 'application/json'}
            if header:
                headers.update(header)
            request_url = "https://{}/{}".format(
                self.server_root, uri)
            if self.verbose:
                print("request_url " + request_url)
            r = requests.request(
                verb,
                url=request_url,
                params=params,
                data=data,
                headers=headers,
                verify=verify)

        except requests.exceptions.Timeout as e:
            print("Timed out connecting to the Allspark API: {}".format(e))
        except requests.exceptions.HTTPError as e:
            print("Request failed\n{}\n{}".format(e, r.text))
        except requests.exceptions.ConnectionError as e:
            print("Failed to connect to the Allspark API: {}".format(e))
        except TimeoutError as e:
            print("Execution timed out: {}".format(e))
        except Exception as e:
            print("Failed to send request: {}".format(e))

        return r

    # pylint: disable=no-self-argument
    def __timeout(seconds=10, error_message=os.strerror(errno.ETIME)):
        def decorator(func):
            def _handle_timeout(signum, frame):
                raise TimeoutError(error_message)

            def wrapper(*args, **kwargs):
                signal.signal(signal.SIGALRM, _handle_timeout)
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    signal.alarm(0)

                return result

            return wraps(func)(wrapper)

        return decorator
    # pylint: enable=no-self-argument

    def set_api_token(self, api_token):
        self.api_token = api_token

    def login(self, username, password):
        '''
        Login and get auth (api) token
        '''
        data = {
            "username": username,
            "password": password
        }
        response = self.__request("POST", "v0/users/login", data=data)
        if response.status_code == 200:
            token = response.json()['id']
            if token is None:
                raise Exception("Failed to retrieve API token")
            self.set_api_token(token)
        return response

    def list_tenants(self, tenant_id=None):
        '''
        List tenant(s)
        '''
        url = 'v0/tenants'
        if tenant_id:
            url = url + '/' + tenant_id
        params = {
            "access_token": self.api_token
        }
        response = self.__request("GET", url, params=params)
        return response

    @__timeout(DEFAULT_TIMEOUT, 'timeout creating tenant')
    def register_tenant(self, name, email, address, company_size, do_async=False):
        '''
        Register tenant
        '''
        params = {
            "access_token": self.api_token
        }
        data = {
            "tenantName": name,
            "contactEmail": email,
            "address": address,
            "companySize": company_size,
        }
        response = None

        if do_async:
            async_create_tenant_resp = self.__request("PUT", "v0/tenants/instance", params=params, data=data)
            tenant_id = async_create_tenant_resp.json().get("tenantID")
            pollT = 1
            while True:
                status_response = self.__request("GET", "v0/tenants/status", params={
                    "access_token": self.api_token,
                    "tenantID": tenant_id,
                })
                try:
                    tenant_status = status_response.json().get("lifeCycle").get("state")
                except AttributeError as err:
                    logAndExit(err, status_response, "{ lifeCycle: { state: value }")
                if tenant_status == 'LIVE':
                    break
                if tenant_status == 'ERROR':
                    logAndExit('ERROR creating tenant', status_response.json(), '')
                time.sleep(pollT)
                pollT = 3
                if self.verbose:
                    print(status_response)
                    print(status_response.json())
            response = self.__request("GET", "v0/tenants/{}".format(tenant_id), data={}, params={
                "access_token": self.api_token,
                "tenantID": tenant_id,
            })
        else:
            response = self.__request("POST", "v0/tenants", params=params, data=data)
        return response

    @__timeout(DEFAULT_TIMEOUT, 'timeout unregistering tenant')
    def unregister_tenant(self, tenant_id, do_async=False):
        '''
        Unregister tenant
        '''
        params = {
            "access_token": self.api_token
        }
        response = None
        if do_async:
            response = self.__request("DELETE", "v0/tenants/instance/{}".format(tenant_id), params=params)
            pollT = 1
            while True:
                response = self.__request("GET", "v0/tenants/status", params={
                    "access_token": self.api_token,
                    "tenantID": tenant_id,
                })
                try:
                    tenant_status = response.json().get("lifeCycle").get("state")
                except AttributeError as err:
                    logAndExit(err, response, "{ lifeCycle: { state: value }")
                if tenant_status == 'NOT_PRESENT':
                    break
                time.sleep(pollT)
                pollT = 3
        else:
            response = self.__request("DELETE", "v0/tenants/{}".format(tenant_id), params=params)
        return response

    def create_user(self, fname, lname, phone, realm, username, password, email, tenant_id):
        '''
        Create a user
        '''
        response = self.__request("POST", "v0/tenants/{}/accessTokens".format(tenant_id), data={}, params={
            "access_token": self.api_token
        })
        if response.status_code != 200:
            return response
        tenant_token = response.json()['id']
        data = {
            "firstName": fname,
            "lastName": lname,
            "phone": phone,
            "realm": realm,
            "username": username,
            "password": password,
            "email": email,
            "tenantToken": tenant_token,
            "tenantId": tenant_id
        }
        response = self.__request("POST", "v0/users", data=data)
        return response

    def check_csp_auth(self):
        '''
        Check if CSP authentication is enabled
        '''
        response = self.__request("GET", "v0/temp/authmode")
        return response

    @__timeout(DEFAULT_TIMEOUT, 'timeout fetching logs')
    def fetch_logs(self, log_type, namespace, cluster, type=None):
        '''
        Fetch logs from the target cluster
        '''
        header = {"Content-type": "application/json"}
        url_params = {"access_token": self.api_token}
        response = None
        if namespace is None:
            namespace = ""

        response = self.__request("GET", "tsm/v1alpha1/clusters/{}/logs/{}?namespace={}".format(cluster, log_type, namespace), params=url_params, header=header)
        if response.status_code != 200:
            raise Exception("Failed to create client cluster log fetch request, message: {}".format(response.json().get('message')))

        print('Fetching {} logs from cluster {}, namespace: {}'.format(log_type, cluster, namespace))
        job_id = response.json().get("id")

        pollT = 1
        while True:
            response = self.__request("GET", "tsm/v1alpha1/jobs/{}".format(job_id), params=url_params, header=header)
            job_state = response.json().get("state")
            if job_state == "Completed":
                break
            elif job_state == "Failed":
                raise Exception("Failed to fetch {} logs from cluster {}".format(log_type, cluster))
            time.sleep(pollT)
            pollT = 3

        response = self.__request("GET", "tsm/v1alpha1/jobs/{}/download".format(job_id), params=url_params, header=header)
        return response

    @__timeout(DEFAULT_TIMEOUT, 'timeout installing/upgrading/uninstalling istio')
    def istio(self, operation, cluster, tsm_version=None):
        '''
        Install, upgrade or uninstall istio in the target cluster using V1 APIs
        '''
        header = {"Content-type": "application/json"}
        url_params = {"access_token": self.api_token}
        response = None

        if operation == 'install' and tsm_version is not None:
            response = self.__request("GET", "tsm/v1alpha1/clusters/{}/apps".format(cluster), params=url_params, header=header)
            if response.status_code != 200:
                raise Exception("Failed to list apps for cluster {}".format(operation))
            tsm_app = [x for x in response.json() if x.get('id') == 'tsm'][0]
            if tsm_app.get('state') != 'NotInstalled':
                operation = 'upgrade'
            if tsm_app.get('version') == tsm_version:
                print("Cluster {} is already on TSM version {}. Skipping Istio {} operation.".format(cluster, tsm_version, operation))
                return response

        if operation == 'install':
            start_state = "Connected"
            expected_state = "Ready"
        elif operation == 'upgrade':
            start_state = "Ready"
            expected_state = "Ready"
        elif operation == 'uninstall':
            start_state = "Ready"
            expected_state = "Connected"
        else:
            raise Exception("Unknown {} Istio operation".format(operation))

        pollT = 1
        while True:
            response = self.__request("GET", "tsm/v1alpha1/clusters/{}".format(cluster), params=url_params, header=header)
            try:
                cluster_status = response.json().get("status").get("state")
            except AttributeError as err:
                logAndExit(err, response, "{ status: { state: value }")
            if cluster_status == start_state:
                break
            elif cluster_status == expected_state:
                print("Cluster {} is already in the '{}' state. Skipping Istio {} operation.".format(cluster, expected_state, operation))
                return response
            time.sleep(pollT)
            pollT = 3

        tsm_version = tsm_version or "default"
        print("Performing {} on cluster {} with TSM version {}".format(operation, cluster, tsm_version))

        if operation == 'install' or operation == 'upgrade':
            data = json.dumps({"version": tsm_version})
            response = self.__request("PUT", "tsm/v1alpha1/clusters/{}/apps/tsm".format(cluster), params=url_params, header=header, data=data)
        elif operation == 'uninstall':
            response = self.__request("DELETE", "tsm/v1alpha1/clusters/{}/apps/tsm".format(cluster), params=url_params, header=header)
        else:
            raise Exception("Unknown {} Istio operation".format(operation))

        if response.status_code != 200:
            raise Exception("Failed to {} Istio".format(operation))

        try:
            job_id = response.json().get("id")
        except AttributeError as err:
            logAndExit(err, response, "{ id }")

        pollT = 1
        while True:
            response = self.__request("GET", "tsm/v1alpha1/jobs/{}".format(job_id), params=url_params, header=header)
            try:
                job_status = response.json().get("state")
            except AttributeError as err:
                logAndExit(err, response, "{ state }")
            if job_status != 'NotStarted':
                break
            time.sleep(pollT)
            pollT = 3

        pollT = 1
        while True:
            response = self.__request("GET", "tsm/v1alpha1/clusters/{}".format(cluster), params=url_params, header=header)
            try:
                cluster_status = response.json().get("status").get("state")
            except AttributeError as err:
                logAndExit(err, response, "{ status: { state: value }")
            if cluster_status == expected_state:
                break
            time.sleep(pollT)
            pollT = 3
        return response

    def get_global_gw_version(self):
        response = self.__request("GET", 'v0/version')
        if response is None:
            raise Exception('Version api response was None')
        return response

    @__timeout(DEFAULT_TIMEOUT, 'timeout deleting cluster')
    def delete_cluster(self, cluster):
        print('delete_cluster {}'.format(cluster))
        params = {
            "clusterName": cluster,
            "access_token": self.api_token
        }
        header = {"Content-type": "application/json"}
        response = self.__request("DELETE", "tsm/v1alpha1/clusters/{}".format(cluster), params=params, header=header)
        if response.status_code != 202:
            return response

        pollT = 1
        while True:
            print('polling delete_cluster')
            resp = self.__request("GET", "tsm/v1alpha1/clusters/{}".format(cluster), params=params, header=header)
            print('response {} {}'.format(resp.status_code, resp.reason))
            if resp.status_code == 404:
                break
            time.sleep(pollT)
            pollT = 3
        return response

    def get_services(self, name):
        '''
        Get Allspark services
        '''
        cluster_data = None
        params = {
            "access_token": self.api_token
        }
        response = self.__request("GET", "local/v0/services", params=params)
        clusters = response.json()["clusters"]
        for cluster in clusters or []:
            cluster_name = cluster.get("name")
            if cluster_name == name:
                cluster_data = cluster
        return cluster_data

    def get_cluster(self, name):
        params = {
            "clusterName": name,
            "access_token": self.api_token
        }
        header = {"Content-type": "application/json"}
        return self.__request("GET", "tsm/v1alpha1/clusters/{}".format(name), params=params, header=header)

    def get_tenant_installer(self, tenant_name):
        '''
        Get tenant cluster installer bash script
        '''
        url_params = {"filter": {"where": {"tenantName": tenant_name}}, "access_token": self.api_token}
        temp_params = urlencode(url_params, quote_via=urllib.parse.quote)
        req_params = temp_params.replace('%27', '%22')
        return self.__request("GET", "v0/tenants", params=req_params)

    def get_client_clusters(self, data_query):
        '''
        Run graphql query to get all the client clusters registered with the SaaS cluster
        '''
        header = {"Content-type": "application/json"}
        data = json.dumps(data_query)
        url_params = {"token": self.api_token}
        return self.__request("POST", "v0/graphql", params=url_params, data=data, header=header)

    def get_cluster_agent_script(self, is_upgraded=False):
        '''
        Get the YAML installer given a cluster name
        '''
        if is_upgraded:
            print("specified --use-board-api go to operator deployment.yaml")
            url_params = {"access_token": self.api_token}
            header = {"Content-type": "application/json"}
            response = self.__request("GET", "tsm/v1alpha1/clusters/onboard-url", params=url_params, header=header)
            if response.status_code != 200:
                raise Exception("Failed to get onboard yaml url, message: {}".format(response.json().get('message')))
            yaml_url = response.json()['url']
            parsed_url = urlparse(yaml_url)
            header = {"Content-type": "application/octet-stream"}
            return self.__request("GET", parsed_url.path, header=header)
        else:
            print("not specified --use-board-api go to old installation.yaml")
            yaml_url = self.__request("GET", "v0/cluster-registration/k8s/url").json()["url"]
            parsed_url = urlparse(yaml_url)
            header = {"Content-type": "application/octet-stream"}
            return self.__request("GET", parsed_url.path, header=header)

    def get_cluster_token(self, cluster_name, is_upgraded=False):
        '''
        Get the token needed to authenticate cluster registration
        '''
        url_params = {"access_token": self.api_token}
        try:
            print("Using v1 API for generating token for cluster: {}".format(cluster_name))
            header = {"Content-type": "application/json", "user-id": "flash", "team-id": "flash"}
            if is_upgraded:
                data = json.dumps({
                    "displayName": cluster_name,
                    "description": "",
                    "tags": [],
                    "labels": [],
                    "autoInstallServiceMesh": False,
                    "enableNamespaceExclusions": True,
                    "namespaceExclusions": []
                })
                response = self.__request("PUT", "tsm/v1alpha1/clusters/{}".format(cluster_name), params=url_params, header=header, data=data)
            else:
                # The generate token API is deprecated and will be replaced with upsert cluster API soon.
                response = self.__request("PUT", "tsm/v1alpha1/clusters/{}/token".format(cluster_name), params=url_params, header=header)
            response.raise_for_status()
            return response.json()["token"]
        except requests.exceptions.HTTPError as e:
            print("Failed to obtain cluster token: {}".format(e))
            raise e
