import os
import time
import ast
from flashpkg import utils, logging

TKG_CLI_CMD = 'tkg'

STATUS_POLLING_ATTEMPTS = 30
ERROR_STATUS_ATTEMPTS = 3
SLEEP = 30

def start(*args, **kwargs):
    return __local_start(*args, **kwargs)

def cleanup(*args, **kwargs):
    return __local_cleanup(*args)

def tkg_create_cluster(cluster_name, workers, k8s_version, plan, env, logging_format):
    log = logging.log(logging_format)

    cmd = [TKG_CLI_CMD,
           'create', 'cluster', cluster_name,
           '--plan', plan,
           '--worker-machine-count', str(workers),
           '--kubernetes-version', f'v{k8s_version}']

    rc, res = utils.command(cmd, env=env, streaming=True, lex=False)

    if rc != 0:
        raise Exception(f'Error when creating clusters, code: {rc}, response: {res} ')
    else:
        log('The cluster successfully created')

def tkg_get_credentials(cluster_name, env, logging_format):
    log = logging.log(logging_format)

    cmd = [TKG_CLI_CMD,
           'get',
           'credentials',
           cluster_name]

    rc, res = utils.command(cmd, env=env, streaming=True, lex=False)

    if rc != 0:
        raise Exception(f'Error when setting credentials, code: {rc}, response: {res} ')
    else:
        log('The cluster successfully setted with credentials')

def tkg_remove_cluster(cluster_name):
    cmd = [TKG_CLI_CMD,
           'delete',
           'cluster',
           cluster_name,
           '--yes']
    rc, res = utils.command(cmd, streaming=True, lex=False)

    if rc != 0:
        raise Exception(f'Error when removing clusters, code: {rc}, response: {res} ')
    else:
        print('The cluster is marked as deleted')

def get_clusters_output():
    cmd = [TKG_CLI_CMD,
           'get',
           'clusters',
           '--output',
           'json']
    rc, res = utils.command(cmd)

    if rc != 0:
        raise Exception(f'Error when fetching clusters, code: {rc}, response: {res}')

    return ast.literal_eval(res)

def status(cluster_name):
    response = get_clusters_output()
    clusters = [el for el in response if el.get('name') == cluster_name]

    return clusters and clusters[0]['status'] == 'deleting'

def status_error_reties(cluster_name, attempt=ERROR_STATUS_ATTEMPTS):
    result = 1
    try:
        result = status(cluster_name)
    except Exception as e:
        if attempt:
            attempt -= 1
            time.sleep(SLEEP)
            return status_error_reties(cluster_name, attempt)
        else:
            raise Exception(e)

    return result

def get_status(cluster_name):
    cnt = 0
    print('Checking deleting cluster progress...')
    while(True):
        result = status_error_reties(cluster_name)

        if not result:
            break

        if (cnt > STATUS_POLLING_ATTEMPTS):
            raise Exception('Cluster still NOT removed')

        time.sleep(SLEEP)
        cnt += 1

def __local_cleanup(cluster_name):
    try:
        tkg_remove_cluster(cluster_name)
        get_status(cluster_name)

        print('Cluster successfully removed!')

        return 0
    except Exception as e:
        print(e)
        return 1

def __local_start(workers, k8s_version, plan, cluster, logging_format):
    log_error = logging.log_error(logging_format)

    cluster_name = cluster.get('name')

    aws_region = os.environ.get('AWS_REGION', cluster.get('region'))
    aws_node_az = os.environ.get('AWS_NODE_AZ', cluster.get('zones'))
    aws_public_node_cidr = os.environ.get('AWS_PUBLIC_NODE_CIDR', cluster.get('public_node_cidr'))
    aws_private_node_cidr = os.environ.get('AWS_PRIVATE_NODE_CIDR', cluster.get('private_node_cidr'))
    aws_vpc_cidr = os.environ.get('AWS_VPC_CIDR', cluster.get('vpc_cidr'))
    cluster_cidr = os.environ.get('CLUSTER_CIDR', cluster.get('cluster_cidr'))
    aws_ssh_key_name = os.environ.get('AWS_SSH_KEY_NAME', cluster.get('ssh_key_name'))
    control_plane_machine_type = os.environ.get('CONTROL_PLANE_MACHINE_TYPE', cluster.get('control_plane_machine_type'))
    node_machine_type = os.environ.get('NODE_MACHINE_TYPE', cluster.get('instance_type'))

    envs = {
        'AWS_REGION': aws_region,
        'AWS_NODE_AZ': aws_node_az,
        'AWS_PUBLIC_NODE_CIDR': aws_public_node_cidr,
        'AWS_PRIVATE_NODE_CIDR': aws_private_node_cidr,
        'AWS_VPC_CIDR': aws_vpc_cidr,
        'CLUSTER_CIDR': cluster_cidr,
        'AWS_SSH_KEY_NAME': aws_ssh_key_name,
        'CONTROL_PLANE_MACHINE_TYPE': control_plane_machine_type,
        'NODE_MACHINE_TYPE': node_machine_type
    }

    env = {**os.environ, **envs}

    try:
        tkg_create_cluster(cluster_name, workers, k8s_version, plan, env, logging_format)
        tkg_get_credentials(cluster_name, env, None)

        return 0
    except Exception as e:
        log_error(e)
        return 1
