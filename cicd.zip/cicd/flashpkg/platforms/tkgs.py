import os
import string
from flashpkg import utils, logging

CONFIG_TEMPLATE = 'clusterTKGS.tmpl.yaml'

GATEWAY_HOST = 'GATEWAY_HOST'
GATEWAY_USERNAME = 'GATEWAY_USERNAME'
GATEWAY_PASSWORD = 'GATEWAY_PASSWORD'
TKGS_NAMESPACE = 'TKGS_NAMESPACE'
TKGS_SUPERVISOR_HOST = 'TKGS_SUPERVISOR_HOST'
TKGS_SERVICES_CIDR = 'TKGS_SERVICES_CIDR'
TKGS_PODS_CIDR = 'TKGS_PODS_CIDR'

class PrerequisitesError(Exception):
    DEFAULT_ERROR_CODE = 1

    def __init__(self, message, code=DEFAULT_ERROR_CODE):
        self.message = message
        self.code = code

def start(*args):
    return __local_start(*args)

def cleanup(*args, **kwargs):
    return __local_cleanup(*args)

def __local_cleanup(cluster_name):
    pass

def create_temp_config():
    pass

def execute_command(cmd):
    ssh_host = os.environ.get(GATEWAY_HOST)
    if not ssh_host:
        raise PrerequisitesError(f'Environment variable {GATEWAY_HOST} isn\'t presented')

    ssh_username = os.environ.get(GATEWAY_USERNAME)
    if not ssh_username:
        raise PrerequisitesError(f'Environment variable {GATEWAY_USERNAME} isn\'t presented')

    ssh_password = os.environ.get(GATEWAY_PASSWORD)
    if not ssh_password:
        raise PrerequisitesError(f'Environment variable {GATEWAY_PASSWORD} isn\'t presented')

    client = utils.ssh_setup(ssh_host, ssh_username, ssh_password)

    sin, sout, serr = client.exec_command(cmd)
    status = sout.channel.recv_exit_status()

    resp = ''
    if status != 0:
        for err in serr:
            print(err.strip('\n'))
            resp += err.strip('\n')
    else:
        for out in sout:
            print(out.strip('\n'))
            resp += out.strip('\n')

    return status, resp


def create_config_file(cluster_config):
    status, tempfile = execute_command('mktemp')
    if status != 0:
        raise Exception('Error during creating temporary file: ', tempfile)

    cmd_insert = f'cat <<EOT >> {tempfile}\n' \
        f'{cluster_config}\n' \
        'EOT'

    status, resp = execute_command(cmd_insert)
    if status != 0:
        raise Exception('Error during updating temporary file: ', resp)

    return tempfile

def rm_config_file(path):
    cmd = f'rm {path}'
    execute_command(cmd)

def __local_start(cluster_name, cluster, logging_format=False):
    log = logging.log(logging_format)
    log_error = logging.log_error(logging_format)

    path, filename = os.path.split(os.path.realpath(__file__))
    file_path = os.path.join(path, CONFIG_TEMPLATE)

    with open(file_path, 'r') as f:
        cluster_tmpl = string.Template(f.read())

    namespace = os.environ.get(TKGS_NAMESPACE)
    if not namespace:
        print(f'Environment variable {TKGS_NAMESPACE} isn\'t presented')
        return 1

    context = os.environ.get(TKGS_SUPERVISOR_HOST)
    if not context:
        print(f'Environment variable {TKGS_SUPERVISOR_HOST} isn\'t presented')
        return 1

    services_cidr_blocks = os.environ.get(TKGS_SERVICES_CIDR)
    if not services_cidr_blocks:
        print(f'Environment variable {TKGS_SERVICES_CIDR} isn\'t presented')
        return 1

    pods_cidr_blocks = os.environ.get(TKGS_PODS_CIDR)
    if not pods_cidr_blocks:
        print(f'Environment variable {TKGS_PODS_CIDR} isn\'t presented')
        return 1

    data = dict(
        cluster_name=cluster_name,
        namespace=namespace,
        version=cluster.get('version'),
        control_plane=cluster.get('control_plane'),
        control_plane_class=cluster.get('control_plane_class'),
        control_plane_storage_class=cluster.get('control_plane_storage_class'),
        workers=cluster.get('workers'),
        workers_class=cluster.get('workers_class'),
        workers_storage_class=cluster.get('workers_storage_class'),
        cni_name=cluster.get('cni_name'),
        services_cidr_blocks=services_cidr_blocks,
        pods_cidr_blocks=pods_cidr_blocks
    )
    cluster_config = cluster_tmpl.substitute(data)

    try:
        config_path = create_config_file(cluster_config)

        try:
            r = apply_config(context, config_path)
        except Exception as e:
            raise e
        else:
            rm_config_file(config_path)

    except PrerequisitesError as e:
        print(e.message)
        return 1
    except Exception as e:
        print(e.message)
        return 1

    if r != 0:
        log_error("Error applying config!")
        return r

    log('Config successfully applied')
    return 0

def create_secret(client_cluster_name, token, namespace):
    cmd = f"kubectl --context {client_cluster_name} -n {namespace} create secret generic cluster-token --from-literal=token={token}"
    r, _ = execute_command(cmd)
    return r

def apply_config(context, cluster_yaml):
    cmd = f"kubectl --context {context} apply -f {cluster_yaml}"
    r, _ = execute_command(cmd)
    return r

def apply_config_inline(context, namespace, config):
    cmd = f'OUTPUT=$(cat <<\'EOF\'\n{config}\nEOF\n) && echo "$OUTPUT" | kubectl apply --context {context} --namespace {namespace} -f -'
    r, _ = execute_command(cmd)
    return r

def apply_agent_script(client_cluster_name, namespace, config):
    r = apply_config_inline(client_cluster_name, namespace, config)
    return r

def delete_config_inline(context, namespace, config):
    cmd = f'OUTPUT=$(cat <<\'EOF\'\n{config}\nEOF\n) && echo "$OUTPUT" | kubectl delete --context {context} --ignore-not-found=true -f -'
    r, _ = execute_command(cmd)
    return r

def delete_agent_script(client_cluster_name, namespace, config):
    r = delete_config_inline(client_cluster_name, namespace, config)
    return r
