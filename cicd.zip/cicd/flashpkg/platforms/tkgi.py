import os
import traceback
from pexpect import pxssh
from flashpkg import cloud as cloud_type
from flashpkg.commands.tkgi.ssh_executor import SSHExecutor
from flashpkg import pks

class PrerequisitesError(Exception):
    pass

def start(*args):
    return __local_start(*args)

def cleanup(*args):
    return __local_cleanup(*args)

def requirements():
    ssh_host = os.environ.get("JUMPER_VM")
    if not ssh_host:
        raise PrerequisitesError("JUMPER_VM doesn't exist")

    ssh_username = os.environ.get("JUMPER_USERNAME")
    if not ssh_username:
        raise PrerequisitesError("JUMPER_USERNAME doesn't exist")

    ssh_password = os.environ.get("JUMPER_PASSWORD")
    if not ssh_password:
        raise PrerequisitesError("JUMPER_PASSWORD doesn't exist")

    return ssh_host, ssh_username, ssh_password

def __local_start(cluster_name, pks_workers, pks_plan, pks_region, pks_version, region, cloud):
    (ssh_host, ssh_username, ssh_password) = requirements()
    print('TKGI: run cluster creating!')

    try:
        res = cloud_type.pks.start(
            cluster_name,
            pks_region,
            pks_plan,
            pks_workers,
            pks_version,
            False
        )

        if res != 0:
            return res

        details = cloud_type.pks.get_cluster_details_json(cluster_name)
        master_ip = details['kubernetes_master_ips'][0]

        ssh_executor = SSHExecutor(ssh_host, ssh_username, ssh_password)
        ssh_executor.ssh_add_host(master_ip, cluster_name)

        print('TKGI cluster created successfully!')

        print('Let\'s envsetup it!')
        pks.envsetup(cluster_name)
        print('Cluster added to kubernetes!')

    except pxssh.ExceptionPxssh as e:
        print('Pxssh failed: ', e)
        return 1
    except PrerequisitesError as e:
        print(e)
        return 1
    except Exception as e:
        print(e)
        traceback.print_exc()
        return 1

    return 0

def __local_cleanup(cluster_name):
    try:
        (ssh_host, ssh_username, ssh_password) = requirements()

        pks.cleanup(cluster_name)

        ssh_executor = SSHExecutor(ssh_host, ssh_username, ssh_password)
        ssh_executor.ssh_remove_host(cluster_name)
    except Exception as e:
        print(e)
        traceback.print_exc()
        return 1

    return 0
