"""
Usage:
    flash tkgs login <sc_ip> <username> <password>
    flash tkgs login client <sc_ip> <cluster_name> <username> <password>

Description:
    flash tkgs : commands to manage tkgs clusters
    flash tkgs login:
    Requirements (environment variables):
        GATEWAY_HOST            Specifies gateway ssh host
        GATEWAY_USERNAME        Specifies gateway ssh username
        GATEWAY_PASSWORD        Specifies gateway ssh password
    flash tkgs login client:
    Requirements (environment variables):
        GATEWAY_HOST            Specifies gateway ssh host
        GATEWAY_USERNAME        Specifies gateway ssh username
        GATEWAY_PASSWORD        Specifies gateway ssh password
        TKGS_NAMESPACE          Specifies client cluster namespace
"""

import sys
import pexpect
import os
from docopt import docopt
from pexpect import pxssh

KUBECTL_VSPHERE_BIN = 'kubectl-vsphere'

GATEWAY_HOST = 'GATEWAY_HOST'
GATEWAY_USERNAME = 'GATEWAY_USERNAME'
GATEWAY_PASSWORD = 'GATEWAY_PASSWORD'
TKGS_NAMESPACE = 'TKGS_NAMESPACE'

class PrerequisitesError(Exception):
    def __init__(self, message, code):
        self.message = message
        self.code = code

class LoginError(Exception):
    def __init__(self, message, code):

        self.message = message
        self.code = code

def prerequisites():
    ssh_host = os.environ.get(GATEWAY_HOST)
    if not ssh_host:
        raise PrerequisitesError(f'Environment variable {GATEWAY_HOST} isn\'t presented', 1)

    ssh_username = os.environ.get(GATEWAY_USERNAME)
    if not ssh_username:
        raise PrerequisitesError(f'Environment variable {GATEWAY_USERNAME} isn\'t presented', 1)

    ssh_password = os.environ.get(GATEWAY_PASSWORD)
    if not ssh_password:
        raise PrerequisitesError(f'Environment variable {GATEWAY_PASSWORD} isn\'t presented', 1)

    return ssh_host, ssh_username, ssh_password

def add_context(supervisor_ip, username, password, ssh_host, ssh_username, ssh_password):
    cmd = f'kubectl vsphere login --vsphere-username {username} --server=https://{supervisor_ip} --insecure-skip-tls-verify=true'
    return execute_command(cmd, password, ssh_host, ssh_username, ssh_password)

def add_client_context(supervisor_ip, cluster_name, cluster_namespace, username, password, ssh_host, ssh_username, ssh_password):
    cmd = f"kubectl vsphere login --server={supervisor_ip} " \
        f"--tanzu-kubernetes-cluster-name={cluster_name} " \
        f"--tanzu-kubernetes-cluster-namespace={cluster_namespace} " \
        f"--vsphere-username {username} "\
        "--insecure-skip-tls-verify=true"

    return execute_command(cmd, password, ssh_host, ssh_username, ssh_password)


def execute_command(cmd, password, ssh_host, ssh_username, ssh_password):
    s = pxssh.pxssh()
    s.logfile_read = sys.stdout.buffer

    s.login(ssh_host, ssh_username, ssh_password)

    default_timeout = 120  # seconds
    s.sendline(cmd)

    password_line = 'Password:'
    try:
        s.expect(password_line, timeout=default_timeout)
    except Exception as e:
        raise LoginError(str(e), 1)

    s.sendline(password)

    login_result_line = ["Logged in successfully.", 'invalid or missing credentials', 'Login failed:']
    success_login = s.expect(login_result_line, timeout=default_timeout)
    if success_login == 1:
        raise LoginError('Invalid or missing credentials', s.exitstatus)
    if success_login == 2:
        s.expect(pexpect.EOF)
        raise LoginError('Login failed', s.exitstatus)

    s.expect('To change context, use `kubectl config use-context <workload name>`', timeout=default_timeout)
    s.close()
    return 0

def login_client(supervisor_ip, cluster_name, username, password):
    try:
        ssh_host, ssh_username, ssh_password = prerequisites()

        cluster_namespace = os.environ.get(TKGS_NAMESPACE)
        if not cluster_namespace:
            raise PrerequisitesError(f'Environment variable {TKGS_NAMESPACE} isn\'t presented', 1)

        return add_client_context(supervisor_ip, cluster_name, cluster_namespace, username, password, ssh_host, ssh_username, ssh_password)
    except PrerequisitesError as e:
        print(e.message)
        return e.code
    except pxssh.ExceptionPxssh as e:
        print(f'Failed login to SSH host {ssh_host} :', str(e))
        return 1


def login(supervisor_ip, username, password):
    try:
        ssh_host, ssh_username, ssh_password = prerequisites()
        return add_context(supervisor_ip, username, password, ssh_host, ssh_username, ssh_password)
    except PrerequisitesError as e:
        print(e.message)
        return e.code
    except pxssh.ExceptionPxssh as e:
        print(f'Failed login to SSH host {ssh_host} :', str(e))
        return 1

def process():
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)

    supervisor_ip = args['<sc_ip>']
    username = args['<username>']
    password = args['<password>']

    if args['client']:
        cluster_name = args['<cluster_name>']

        exit_code = login_client(supervisor_ip, cluster_name, username, password)
    else:
        exit_code = login(supervisor_ip, username, password)

    return exit_code
