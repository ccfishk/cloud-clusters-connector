"""
Usage:
    flash tmc login <org_id> <refresh_token> [--verbose] [--env=<env>]
    flash tmc attach cluster <cluster_name> <cluster_group> <tmc_stack>\
 [--context=<context>] [--verbose] [--eks]
    flash tmc cluster agentinstallation <cluster_name> <tmc_stack>
    flash tmc onboard cluster <cluster_name> <tmc_stack> [--verbose] [--eks]
    flash tmc offboard cluster <cluster_name> <tmc_stack> [--verbose] [--eks]
    flash tmc detach cluster <cluster_name> <tmc_stack> [--verbose] [--eks]
    flash tmc staging0context
    flash tmc merge-to-kube-config <tmc_kubeconfig_yaml> [--verbose]
"""
from docopt import docopt
import sys
from flashpkg.state import state
from flashpkg import cspAuth
import time
import tempfile
import os
from pathlib import Path
import shutil
from flashpkg import utils

TMC_UNSTABLE_URL = 'https://tmc-users-unstable.tmc-dev.cloud.vmware.com'
TMC_STABLE_URL = 'https://tmc-users.stable.tmc-dev.cloud.vmware.com'
TMC_PROD_URL = 'https://tmc-users.prod.tmc-dev.cloud.vmware.com'

TSM_STAGING0 = 'https://staging-0.servicemesh.biz'
TSM_STAGING2 = 'https://staging-2.servicemesh.biz'
TSM_PROD = 'https://prod-1.nsxservicemesh.vmware.com'

TMCSTACK_UNSTABLE = 'unstable'
TMCSTACK_STABLE = 'stable'
TMCSTACK_PROD = 'prod'

CSP_ENV = {
    'prod': 'console.cloud.vmware.com',
    'stg': 'console-stg.cloud.vmware.com'
}

verbose_flag = False


def get_access_token_onthefly(usr_csp_token):
    url = 'https://console-stg.cloud.vmware.com/'\
        'csp/gateway/am/api/auth/api-tokens/'\
        'authorize?refresh_token={}'.format(usr_csp_token)
    resp = utils.tmc_request(url, operation='POST').json()
    return resp['access_token']


def get_access_token():
    return state.get_tmc_access_token()


def create_tmc_cluster_group(tmc_stack, token, group_name):
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    post_url = "{}/v1alpha1/clustergroups".format(tmc_endpoint)
    json_payload = {
        "clusterGroup": {
            "full_name": {
                "name": "{}".format(group_name)
            },
            "meta": {
                "description": "",
                "labels": {}
            }
        }
    }
    headers = {'authorization': token}
    status_code = [200, 409]
    utils.tmc_request(post_url, data=json_payload,
                      csp_url=get_csp_host_url(tmc_stack),
                      operation='POST', status_code=status_code,
                      headers=headers, verbose_flag=verbose_flag).json()
    return


def get_tmc_endpoint(tmc_stack):
    tmcstack_switcher = {
        TMCSTACK_UNSTABLE: TMC_UNSTABLE_URL,
        TMCSTACK_STABLE: TMC_STABLE_URL,
        TMCSTACK_PROD: TMC_PROD_URL
    }
    return tmcstack_switcher.get(tmc_stack)


def get_tsm_endpoint(tmc_stack):
    tsmendpoint_switcher = {
        TMCSTACK_UNSTABLE: TSM_STAGING0,
        TMCSTACK_STABLE: TSM_STAGING2,
        TMCSTACK_PROD: TSM_PROD
    }
    return tsmendpoint_switcher.get(tmc_stack)


def get_csp_host_url(tmc_stack):
    csp_switcher = {
        TMCSTACK_UNSTABLE: cspAuth.CFG['Stage'],
        TMCSTACK_STABLE: cspAuth.CFG['Stage'],
        TMCSTACK_PROD: cspAuth.CFG['Prod']
    }
    return csp_switcher.get(tmc_stack)


def install_tmc_agent(link, cluster_name, tmc_stack, context=None):
    deploy_cmd = 'kubectl create -f "{}" --validate=false'.format(link)
    if context is not None:
        deploy_cmd = 'kubectl --context={} create -f "{}" '\
                     '--validate=false'.format(context, link)
    if verbose_flag:
        print(deploy_cmd)
    os.system(deploy_cmd)


def attach_cluster_to_tmc(cluster_name, group_name, tmc_stack, context=None):
    print(verbose_flag)
    if verbose_flag:
        print("attach cluster {} to tmc {} under group {}".format(
              cluster_name, tmc_stack, group_name))
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    csp_access_token = get_access_token()
    create_tmc_cluster_group(tmc_stack, csp_access_token, group_name)
    if verbose_flag:
        print("successfully created tmc cluster group {}"
              "under {}".format(group_name, tmc_endpoint))
    post_url = "{}/v1alpha1/clusters".format(tmc_endpoint)
    json_payload = {"cluster": {"fullName": {
                    "name": "{}".format(cluster_name),
                    "managementClusterName": "attached",
                    "provisionerName": "attached"}, "meta":
                   {"description": "",
                    "labels": {}}, "spec": {"clusterGroupName": "{}".format(group_name)}}}
    token = 'Bearer {}'.format(csp_access_token)
    headers = {'authorization': token}
    try:
        resp = utils.tmc_request(post_url, data=json_payload,
                                 operation='POST',
                                 csp_url=get_csp_host_url(tmc_stack),
                                 status_code=[409], headers=headers,
                                 verbose_flag=verbose_flag).json()
        return 0
    except Exception:
        return 1

    deploy_link = None
    try:
        resp = utils.tmc_request(post_url, data=json_payload,
                                 operation='POST',
                                 csp_url=get_csp_host_url(tmc_stack),
                                 status_code=[200], headers=headers,
                                 verbose_flag=verbose_flag).json()
        deploy_link = resp['cluster']['status']['installerLink']
        if verbose_flag:
            print("successfully attach cluster {} to tmc"
                  ", execute {} on client cluster to "
                  "proceed".format(cluster_name,
                                   deploy_link))
    except Exception:
        url = '{}/v1alpha1/clusters/{}?full_name.managementClusterName=attached&full_name.provisionerName=attached'.format(tmc_endpoint, cluster_name)
        try:
            resp = utils.tmc_request(url, operation='GET', headers=headers,
                                     csp_url=get_csp_host_url(tmc_stack),
                                     verbose_flag=verbose_flag).json()
            clsstatus = resp['cluster']['status']
            link = resp['cluster']['status']['installerLink']
            if clsstatus and link:
                link = resp['cluster']['status']['installerLink']
                install_tmc_agent(link, cluster_name, tmc_stack,
                                  context=context)
        except Exception:
            print('failed to install TMC agent on'
                  ' {}'.format(cluster_name))
            return 1
        read = is_tmc_agent_installation_completed(cluster_name, tmc_stack)
        if read is True:
            return 0
        return 1
    install_tmc_agent(deploy_link, cluster_name, tmc_stack, context=context)
    read = is_tmc_agent_installation_completed(cluster_name, tmc_stack,
                                               context=context)
    if read is True:
        return 0
    return 1


def get_tsmname_tmc(cluster_name, tmc_stack, access_token):
    endpoint = get_tmc_endpoint(tmc_stack)
    url = "{}/v1alpha1/clusters/{}/integrations/tanzu-service-mesh?"\
        "full_name.management_cluster_name=attached&"\
        "full_name.provisioner_name=attached".format(endpoint, cluster_name)

    token = 'Bearer {}'.format(access_token)
    headers = {'authorization': token}
    i = 0
    while True:
        resp = utils.tmc_request(url, operation='GET', headers=headers,
                                 csp_url=get_csp_host_url(tmc_stack),
                                 verbose_flag=verbose_flag).json()
        if resp['integration']['spec'] is not None and\
           'configurations' in resp['integration']['spec'] and\
                'clusterName' in resp['integration']['spec']['configurations']:
            nm = resp['integration']['spec']['configurations']['clusterName']
            if nm is not None:
                if verbose_flag:
                    print("cluster {} TSM name {}".format(cluster_name, nm))
            return nm
        i = i + 1
        if i > 100:
            raise Exception('failed to get cluster {} '
                            'tsm name.'.format(cluster_name))
        if verbose_flag:
            print("retry querying cluster name. prev resp {}".format(resp))
        time.sleep(10)


def get_tsm_cls_name(cluster_name, tmc_stack, access_token):
    tsm_endpoint = get_tsm_endpoint(tmc_stack)
    url = "{}/tsm/v1alpha1/clusters".format(tsm_endpoint)
    if verbose_flag:
        print("clm query url {}".format(url))
    headers = {'csp-auth-token': '{}'.format(access_token)}
    i = 0
    while True:
        resp = utils.tmc_request(url, operation='GET',
                                 headers=headers,
                                 csp_url=get_csp_host_url(tmc_stack),
                                 verbose_flag=verbose_flag).json()
        for tsm_cls_name in resp['ids']:
            if cluster_name in tsm_cls_name:
                if verbose_flag:
                    print('cluster {} registered'.format(cluster_name))
                return
        if verbose_flag:
            print("looking for {} in {}".format(cluster_name, resp))
        i = i + 1
        if i > 100:
            raise Exception('failed to get cluster {} '
                            'from CLM.'.format(cluster_name))
        if verbose_flag:
            print("retry {} query cluster from clm after ".format(i*10))
        time.sleep(10)


def pull_onboard_status(cluster_name, tmc_stack, csp_access_token):
    if verbose_flag:
        print("check cluster onboard status.")
    cls_tsm_name = get_tsmname_tmc(cluster_name,
                                   tmc_stack, csp_access_token)
    get_tsm_cls_name(cls_tsm_name, tmc_stack, csp_access_token)
    i = 0
    while True:
        try:
            onboarded = get_tmc_clusteronboard_status(cls_tsm_name,
                                                      tmc_stack,
                                                      csp_access_token)
            if onboarded:
                print(cls_tsm_name)
                return 0
            i += 1
            if i >= 100:
                print("onboard timed out.")
                raise
            delay = 10 * i
            if verbose_flag:
                print('Retry: %s after %s seconds' % (i, delay))
            time.sleep(15)
        except Exception:
            return 1


def onboard_cluster_from_tmc(cluster_name, tmc_stack):
    if verbose_flag:
        print("onboard cluster {} to tsm from tmc {}".format(
              cluster_name, tmc_stack))
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    csp_access_token = get_access_token()
    post_v1alpha1_url = "{}/v1alpha1/clusters/{}/integrations".format(
        tmc_endpoint, cluster_name)
    json_payload = {
        "integration": {
            "full_name": {
                "provisionerName": "attached",
                "managementClusterName": "attached",
                "name": "tanzu-service-mesh"
            },
            "spec": {
                "configurations": {
                    "enableNamespaceExclusions": True
                }
            }
        }
    }
    token = 'Bearer {}'.format(csp_access_token)
    headers = {'authorization': token}
    try:
        utils.tmc_request(post_v1alpha1_url, data=json_payload,
                          operation='POST',
                          csp_url=get_csp_host_url(tmc_stack),
                          status_code=[200], headers=headers,
                          verbose_flag=verbose_flag)
    except Exception:
        pass
    return pull_onboard_status(cluster_name, tmc_stack, csp_access_token)


def build_path(*args):
    return os.path.join(os.path.expanduser('~'), *args)


def merge_kube_config(yaml_path):
    default_kube_config_dir = build_path('.kube')
    default_kube_config = build_path('.kube', 'config')
    back_config_path = build_path('.kube', 'config.flash.back')
    temp_merge_path = tempfile.NamedTemporaryFile(delete=False).name
    try:
        if verbose_flag:
            paths = {
                "default_kube_config_dir": default_kube_config_dir,
                "default_kube_config": default_kube_config,
                "back_config_path": back_config_path,
                "temp_merge_path": temp_merge_path,
                "yaml_path": yaml_path
            }
            print(paths)
        if not os.path.isdir(default_kube_config_dir):
            if verbose_flag:
                print('kubeconfig dir not found, creating')
            os.mkdir(default_kube_config_dir)
        if not os.path.isfile(default_kube_config):
            if verbose_flag:
                print('kubeconfig file not found adding empty')
            Path(default_kube_config).touch()

        shutil.copy(default_kube_config, back_config_path)
        merge_cmd = f'KUBECONFIG={default_kube_config}:{yaml_path} kubectl config view --merge --flatten > {temp_merge_path}'
        if verbose_flag:
            print(merge_cmd)
        os.system(merge_cmd)
        shutil.copy(temp_merge_path, default_kube_config)
    finally:
        os.remove(temp_merge_path)
    print(f'kubeconfigs merged into {default_kube_config}, a backup was stored {back_config_path}')
    return 0


def login_tmc(org_id, refresh_token, env):
    if verbose_flag:
        print('tmc login {} {}'.format(org_id, refresh_token))
    url = CSP_ENV.get(env)
    if url is None:
        url = 'console.cloud.vmware.com'
    if verbose_flag:
        print('using {} for login. env {}'.format(url, env))
    state.set_tmc_orgid(org_id)
    access_token = cspAuth.getAccessToken(refresh_token, url)
    state.set_tmc_access_token(access_token)
    state.set_tmc_refresh_token(refresh_token)
    if verbose_flag:
        print('tmc associated with org {} and'
              ' access token {}'.format(org_id, access_token))
    return 0


def is_tmc_agent_installation_completed(cluster_name, tmc_stack, context=None):
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    access_token = get_access_token()
    token = 'Bearer {}'.format(access_token)
    headers = {'authorization': token}
    get_url = "{}/v1alpha1/clusters/{}?full_name.managementClusterName=attached&full_name.provisionerName=attached".format(tmc_endpoint, cluster_name)
    i = 0
    while True:
        try:
            rsp = utils.tmc_request(get_url, operation='GET',
                                    headers=headers,
                                    csp_url=get_csp_host_url(tmc_stack),
                                    verbose_flag=verbose_flag).json()
            print("remove me {}".format(rsp))
            extState = rsp['cluster']['status']['status']['state']['state']
            hSts = rsp['cluster']['status']['status']['health']
            ast = rsp['cluster']['status']['agent']['status']['state']['state']
            if extState == 'READY'\
                and ('health' in hSts and hSts['health'] == 'HEALTHY') \
                    and ast == 'COMPLETE':
                if verbose_flag:
                    print("tmc agent extension installation on"
                          " cluster {} complete.".format(cluster_name))
                return True
            i += 1
            if i >= 60:
                print("tmc agent extension installation exceeds 5 minutes.")
                raise
            delay = 10 * i
            if verbose_flag:
                print('Retry: %s after %s seconds' % (i, delay))
            time.sleep(10)
        except Exception:
            try:
                url = '{}/v1alpha1/clusters/{}'.format(tmc_endpoint,
                                                       cluster_name)
                resp = utils.tmc_request(url, operation='GET',
                                         headers=headers,
                                         csp_url=get_csp_host_url(tmc_stack),
                                         verbose_flag=verbose_flag).json()
                deplink = resp['cluster']['status']['agent']['deploymentLink']
                install_tmc_agent(deplink, cluster_name, tmc_stack,
                                  context=context)
                time.sleep(3)
                continue
            except Exception as ex:
                print('failed retrieving {} deploy link, exception {}'.format(
                      cluster_name, ex))
                return False
            return False


def offboard_cluster_from_tmc(cluster_name, tmc_stack):
    tmc_endpont = get_tmc_endpoint(tmc_stack)
    delete_url = "{}/v1alpha1/clusters/{}/integrations/tanzu-service-mesh?"\
        "full_name.management_cluster_name=attached&"\
        "full_name.provisioner_name=attached".format(tmc_endpont, cluster_name)
    access_token = get_access_token()
    token = 'Bearer {}'.format(access_token)
    headers = {'authorization': token}
    if verbose_flag:
        print("successfully get csp access token on the fly")
    try:
        utils.tmc_request(delete_url, operation='DELETE',
                          status_code=[200, 404],
                          csp_url=get_csp_host_url(tmc_stack),
                          headers=headers,
                          verbose_flag=verbose_flag).json()
    except Exception as ex:
        if verbose_flag:
            print('failed offboard cluster {}, exception {}'.format(
                  cluster_name, ex))
        return 1
    if verbose_flag:
        print("successfully offboard cluster {} "
              "from tmc {}".format(cluster_name, tmc_stack))
    return 0


def detach_cluster_from_tmc(cluster_name, tmc_stack):
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    csp_access_token = get_access_token()
    if verbose_flag:
        print("successfully get csp access token on the fly")
    delete_url = "{}/v1alpha1/clusters/{}?full_name.managementClusterName=attached&full_name.provisionerName=attached".format(tmc_endpoint, cluster_name)
    token = 'Bearer {}'.format(csp_access_token)
    headers = {'authorization': token}
    try:
        utils.tmc_request(delete_url, operation='DELETE',
                          status_code=[200, 404],
                          headers=headers,
                          csp_url=get_csp_host_url(tmc_stack),
                          verbose_flag=verbose_flag).json()
    except Exception as ex:
        if verbose_flag:
            print('failed detach cluster {}, exception {}'.format(
                  cluster_name, ex))
        return 1
    if verbose_flag:
        print("started detach cluster {} from tmc".format(cluster_name))
    return get_tmc_cluster_status(cluster_name, tmc_stack, csp_access_token)


def get_tmc_clusteronboard_status(cluster_name, tmc_stack, csp_access_token):
    tsm_endpoint = get_tsm_endpoint(tmc_stack)
    url = "{}/tsm/v1alpha1/clusters/{}/apps".format(tsm_endpoint, cluster_name)
    headers = {'csp-auth-token': '{}'.format(csp_access_token)}
    resp = utils.tmc_request(url, operation='GET', headers=headers,
                             csp_url=get_csp_host_url(tmc_stack),
                             verbose_flag=verbose_flag).json()
    if verbose_flag:
        print("get cluster app status {}".format(resp))
    if resp[0]['state'] == 'Healthy':
        if verbose_flag:
            print('cluster {} onboarded successfully.'.format(cluster_name))
        return True
    return False


def get_tmc_cluster_status(cluster_name, tmc_stack, csp_access_token):
    tmc_endpoint = get_tmc_endpoint(tmc_stack)
    url = '{}/v1alpha1/clusters/{}?full_name.managementClusterName=attached&full_name.provisionerName=attached'.format(tmc_endpoint, cluster_name)
    token = 'Bearer {}'.format(csp_access_token)
    headers = {'authorization': token}
    i = 0
    while True:
        try:
            utils.tmc_request(url, operation='GET', headers=headers,
                              csp_url=get_csp_host_url(tmc_stack),
                              verbose_flag=verbose_flag).json()
            i = i + 1
            if i > 100:
                raise Exception('detach {} timedout.'.format(cluster_name))
            time.sleep(10)
        except Exception:
            if verbose_flag:
                print("cluster resource is removed.")
            return 0


def process():
    if len(sys.argv) == 2:
        sys.argv.append('-h')
    args = docopt(__doc__)
    if args['--verbose']:
        global verbose_flag
        verbose_flag = True
    if args['login']:
        org_id = args.get('<org_id>')
        refresh_token = args.get('<refresh_token>')
        env = args.get('--env')
        return login_tmc(org_id, refresh_token, env)
    if args['attach']:
        cluster_name = args.get('<cluster_name>')
        group_name = args.get('<cluster_group>')
        tmc_stack = args.get('<tmc_stack>')
        context = args['--context']
        return attach_cluster_to_tmc(cluster_name,
                                     group_name,
                                     tmc_stack,
                                     context=context)
    elif args['agentinstallation']:
        cluster_name = args.get('<cluster_name>')
        tmc_stack = args.get('<tmc_stack>')
        return is_tmc_agent_installation_completed(
            cluster_name,
            tmc_stack)
    elif args['onboard']:
        cluster_name = args.get('<cluster_name>')
        tmc_stack = args.get('<tmc_stack>')
        return onboard_cluster_from_tmc(cluster_name,
                                        tmc_stack)
    elif args['offboard']:
        cluster_name = args.get('<cluster_name>')
        tmc_stack = args.get('<tmc_stack>')
        return offboard_cluster_from_tmc(cluster_name,
                                         tmc_stack)
    elif args['detach']:
        cluster_name = args.get('<cluster_name>')
        tmc_stack = args.get('<tmc_stack>')
        return detach_cluster_from_tmc(cluster_name, tmc_stack)
    elif args['merge-to-kube-config']:
        yaml_path = args.get('<tmc_kubeconfig_yaml>')
        return merge_kube_config(yaml_path)
