"""
Usage:
  flash cluster create using flavor <flavor_name> <cluster_name> [--cloud --multi-master --region=<region> --zones=<zones> --no-iam --save-config=<configpath> --verbose \
                                                                    --logging-format=<logging-format>]
  flash cluster status <cluster_name> [--cloud]
  flash cluster envsetup <cluster_name> [--cloud --external_cluster=<cluster_type> --region=<region>]
  flash cluster cleanup <cluster_name> [--cloud --external_cluster=<cluster_type> --region=<region> --assume-yes --no-iam --force --restricted_cluster=<restricted_action_ack>]
  flash cluster list [--cloud]

Description:
  flash cluster : commands to manage clusters of different types/flavors. Builtin flavors are kops_small, kops_medium, kops_large, cpks_privileged, and cpks_unprivileged.

Options:
  --cloud                              Run the command remotely in the cloud. WARNING: this is not yet implemented.
  --multi-master                       Create a multi-master (3 master nodes) cluster. WARNING: implemented for kops clusters only.
  --region=<region>                    Specifies the region to use.
  --assume-yes                         Assume "yes" for any confirmation prompts.
  --force                              Do not wait for cluster cleanup to complete (valid only for EKS clusters)
  --no-iam                             Do not add IAM roles to cluster/worker nodes
  --external_cluster=<cluster_type>    Specifies the external cluster type to work with. This could be kops, cpks, etc.
"""
from prettytable import PrettyTable
import os
import sys
import json
from docopt import docopt
from flashpkg import cloud as cloud_type
from flashpkg.state import state
from flashpkg.config import config

RESTRICTED_CLUSTER_PREFIX = ["prod", "staging", "preprod"]
RESTRICTED_ACTION_CONFIRMATION = "iunderstandtherisk"

verbose_flag = False

def restricted_cluster_check(cluster, args):
    for prefix in RESTRICTED_CLUSTER_PREFIX:
        if cluster.lower().startswith(prefix):
            if args['--restricted_cluster']:
                if args['--restricted_cluster'] == RESTRICTED_ACTION_CONFIRMATION:
                    return 1
                else:
                    print("Invalid input for --restricted_cluster. Retry with correct confirmation string.. ")
                    return 0
            else:
                print("Operation attempted on a restricted prod or staging cluster {}, use the --restricted_cluster option if you understand the risk".format(cluster))
                return 0
    return 1

def __log_error(output_format):
    def echo(message):
        if output_format == 'json':
            response = {"error": {"message": message}}
            print(response)
        else:
            print(message)
    return echo

def __log_result(logging_format):
    def echo(cluster_name):
        if logging_format == 'json':
            response = json.dumps({"data": {"cluster_name": cluster_name}})
            print(response)
    return echo

def create(flavor_name, cluster_name, region=None, zones=None,
           cloud=False, cluster_group_name=None, multi_master=False,
           iam_role=True, skip_iam=False, configpath=None, logging_format=False,
           is_cluster_pool=False, username=None):

    res = -1
    log_error = __log_error(logging_format)
    log_result = __log_result(logging_format)
    cluster = state.get_cluster_v2(cluster_name=cluster_name)
    if cluster:
        raise Exception("Cluster {} already exists".format(cluster_name))

    flavor = config.get_flavor(flavor_name)

    if not flavor:
        raise Exception("No such flavor {}".format(flavor_name))

    cluster = flavor
    cluster["name"] = cluster_name
    cluster["flavor"] = flavor_name
    cluster["tenants"] = []
    cluster["ready"] = False

    if cluster_group_name:
        cluster["cluster_group_name"] = cluster_group_name

    if region is None:
        region = cluster.get("region")
    cluster["region"] = region

    if not zones:
        zones = cluster.get('zones')

    if zones is None and cluster.get("type").lower() != "pks":
        zones = "%sa,%sb" % (region, region)

    if cluster.get("type").lower() != "pks":
        for zone in zones.split(','):
            assert zone.startswith(region), 'Zone is not in provided region'
        cluster["zones"] = zones

    version = cluster.get("version")

    if skip_iam:
        iam_role = False

    if cluster.get("type").lower() == "kops":
        # Input validation for the region on AWS
        # To prevent infra from being deployed in all around the world,
        # at this time we only support a limited number of AWS regions
        assert region in [
            'us-west-1', 'us-west-2',
            'us-east-1', 'us-east-2',
            'eu-west-1', 'eu-west-2'
        ], ' Invalid or restricted AWS region'
        version = os.environ.get("KOPS_VERSION", version)
        instance = cluster.get("instance_type")
        workers = os.environ.get("KOPS_WORKERS", cluster.get("workers"))
        auth = cluster.get("authorization")
        network = cluster.get("networking")
        try:
            res = cloud_type.kops.start(cluster_name,
                                        region,
                                        zones,
                                        instance,
                                        workers,
                                        auth,
                                        network,
                                        multi_master,
                                        iam_role,
                                        cloud=cloud,
                                        version=version,
                                        logging_format=logging_format)
        except ValueError as e:
            log_error("Failed to create cluster: {}".format(e))
            return res

    elif cluster.get("type").lower() == 'tmc':
        assert region in [
            'us-west-2',
            'us-east-1', 'us-east-2',
            'eu-west-1',
        ], ' Invalid or restricted AWS region'

        group = cluster.get("group")
        kube_version = cluster.get("version")
        instance_type = cluster.get("instance_type")
        worker_node_count = cluster.get("workers")
        region = cluster.get("region")
        zones = cluster.get("zones")
        ssh_key_name = cluster.get("ssh_key_name")
        account_name = cluster.get("account_name")

        if verbose_flag:
            print("creating tmc cluster")
            print("group: {}, version: {}, instance: {}, worker count: {}, region {}, zone: {}, ssh key: {}, save config: {}".format(
                group,
                version,
                instance_type,
                worker_node_count,
                region,
                zones,
                ssh_key_name,
                configpath
            ))
        zones_list = zones.split(',')
        res = cloud_type.tmc.start(cluster_name,
                                   region,
                                   zones_list,
                                   instance_type,
                                   worker_node_count,
                                   group=group,
                                   account_name=account_name,
                                   ssh_key_name=ssh_key_name,
                                   kube_version=kube_version,
                                   configpath=configpath,
                                   verbose_flag=verbose_flag,
                                   logging_format=logging_format)

    elif cluster.get("type").lower() == "eks":
        # Input validation for the region on AWS
        # To prevent infra from being deployed in all around the world,
        # at this time we only support a limited number of AWS regions
        assert region in [
            'eu-west-1', 'us-west-2',
            'us-east-1', 'us-east-2'
        ], ' Invalid or restricted AWS region'
        version = os.environ.get("EKS_VERSION", version)
        instance = cluster.get("instance_type")
        workers = os.environ.get("EKS_WORKERS", cluster.get("workers"))
        auth = cluster.get("authorization")
        network = cluster.get("networking")

        res = cloud_type.eks.start(cluster_name,
                                   region,
                                   zones,
                                   instance,
                                   workers,
                                   auth,
                                   network,
                                   iam_role,
                                   logging_format,
                                   cloud=cloud,
                                   version=version)
    elif cluster.get("type").lower() == "pks":
        if not os.environ.get("JUMPER_VM"):
            log_error("Please set the JUMPER_VM environment variable before running any PKS commands")
            return 1
        plan = cluster.get("plan")
        workers = cluster.get("workers")

        res = cloud_type.pks.start(cluster_name, region, plan, workers, version, logging_format, cloud=cloud)
    elif cluster.get("type").lower() == "cpks":
        # Input validation for the region on CloudPKS
        assert region in ['us-west-2', 'us-east-1', 'eu-west-1'], 'Invalid VKE region'
        folder = cluster.get("folder")
        project = cluster.get("project")
        org = os.environ.get("YOUR_ORG_ID", cluster.get("org"))
        token = os.environ.get("YOUR_REFRESH_TOKEN", cluster.get("token"))
        # Override the CPKS version using environment variable if present
        version = os.environ.get("CPKS_VERSION", version)
        privileged = cluster.get("privileged")
        res = cloud_type.cpks.start(cluster_name, region, folder,
                                    project, org, token, privileged, version,
                                    cloud=cloud)
    elif cluster.get("type").lower() == "tkg":
        workers = os.environ.get('TKG_WORKERS', cluster.get('workers'))

        k8s_version = os.environ.get('TKG_K8S_VERSION', cluster.get('version'))

        valid_plans = ['dev', 'prod']
        plan = os.environ.get('TKG_PLAN', 'dev')
        if plan not in valid_plans:
            log_error(f'This {plan} is not available, please use {valid_plans}')
            return res

        res = cloud_type.tkg.start(workers, k8s_version, plan, cluster=cluster, logging_format=logging_format)
    elif cluster.get("type").lower() == "tkgs":
        res = cloud_type.tkgs.start(cluster_name, cluster, logging_format)
    elif cluster.get("type").lower() == "tkgi":
        pks_workers = cluster.get('pks_workers')
        pks_plan = cluster.get('pks_plan')
        pks_region = cluster.get('pks_region')
        pks_version = cluster.get('pks_version')

        res = cloud_type.tkgi.start(
            cluster_name,
            pks_workers,
            pks_plan,
            pks_region,
            pks_version,
            region,
            cloud)
    else:
        res = 200

    if res == 0:
        cluster["ready"] = True
        if verbose_flag and not logging_format:
            print(cluster)
        state.add_cluster(cluster)
        if not is_cluster_pool:
            log_result(cluster_name)

    return res

def cleanup_external(cluster_name, cloud=False, external_cluster=None, region=None, skip_iam=False, force=False):
    if not external_cluster:
        raise Exception("Pass an external cluster type when cleaning up foreign clusters")

    if external_cluster.lower() == "kops":
        if not region:
            raise Exception("Pass a region when cleaning up foreign clusters")

        return cloud_type.kops.cleanup(cluster_name, region)

    elif external_cluster.lower() == "eks":
        if not region:
            raise Exception("Pass a region when cleaning up foreign clusters")
        return cloud_type.eks.cleanup(cluster_name, region, skip_iam, force)

    elif external_cluster.lower() == "tmc":
        return cloud_type.tmc.cleanup(cluster_name)

    elif external_cluster.lower() == "cpks":
        org = os.environ.get("YOUR_ORG_ID")
        token = os.environ.get("YOUR_REFRESH_TOKEN")
        return cloud_type.cpks.cleanup(cluster_name, org, token)

    elif external_cluster.lower() == "tkg":
        return cloud_type.tkg.cleanup(cluster_name)

    elif external_cluster.lower() == "tkgi":
        if not os.environ.get("JUMPER_VM"):
            print("Please set the JUMPER_VM environment variable before running any PKS commands")
            return 1

        return cloud_type.tkgi.cleanup(cluster_name)

    raise Exception("Invalid cluster type {}".format(external_cluster))

def cleanup(cluster_name, cloud=False, external_cluster=None, region=None, skip_iam=False, force=False):
    cluster = state.get_cluster_v2(cluster_name=cluster_name)

    if not cluster:
        return cleanup_external(cluster_name,
                                cloud=False,
                                external_cluster=external_cluster,
                                region=region,
                                skip_iam=skip_iam)

    # If the cluster can't be found in our state then try to pick it up from the flag.
    # Do this so that we support cleaning up foreign clusters not tracked by our state.
    region = cluster[state.Clusterkey.region]
    cluster_type = cluster[state.Clusterkey.cluster_type].lower()

    if cluster_type == "kops":
        res = cloud_type.kops.cleanup(cluster_name, region, cloud=cloud)
        if res == 0:
            state.remove_cluster(cluster_name)
        return res

    elif cluster_type == "eks":
        res = cloud_type.eks.cleanup(cluster_name, region, skip_iam, force, cloud=cloud)
        if res == 0:
            state.remove_cluster(cluster_name)
        return res

    elif cluster_type == "tmc":
        if verbose_flag:
            print("cleaning up tmc cluster {}".format(cluster_name))
        res = cloud_type.tmc.cleanup(cluster_name)
        if res == 0:
            state.remove_cluster(cluster_name)

        return res

    elif cluster_type == "cpks":
        org = os.environ.get("YOUR_ORG_ID", cluster[state.Clusterkey.cluster_create_account])
        token = os.environ.get("YOUR_REFRESH_TOKEN", state.get_cluster_token(cluster_name=cluster_name))
        res = cloud_type.cpks.cleanup(cluster_name, org, token, cloud=cloud)
        if res == 0:
            state.remove_cluster(cluster_name)

    elif cluster_type == "pks":
        if not os.environ.get("JUMPER_VM"):
            print("Please set the JUMPER_VM environment variable before running any PKS commands")
            return 1
        res = cloud_type.pks.cleanup(cluster_name, cloud=cloud)
        if res == 0:
            state.remove_cluster(cluster_name)

        return res

    elif cluster_type == 'tkg':
        print(f'Removing TKG cluster: {cluster_name}')
        res = cloud_type.tkg.cleanup(cluster_name)
        if res == 0:
            state.remove_cluster(cluster_name)

        return res

    elif cluster_type == "tkgi":
        if not os.environ.get("JUMPER_VM"):
            print("Please set the JUMPER_VM environment variable before running any PKS commands")
            return 1
        res = cloud_type.tkgi.cleanup(cluster_name)
        if res == 0:
            state.remove_cluster(cluster_name)

        return res


def status(cluster_name, cloud=False):
    clusters = state.get_clusters_v2()
    for clusterKey in clusters:
        if cluster_name is None or cluster_name == clusterKey:
            cluster = clusters[clusterKey]
            cluster_type = cluster[state.Clusterkey.cluster_type].lower()
            print(json.dumps(cluster, indent=4))
            print()
            if cluster_type == "kops":
                return cloud_type.kops.status(clusterKey, cloud=cloud)
            elif cluster_type == "eks":
                return cloud_type.eks.status(clusterKey, cluster.get("region"), cloud=cloud)
            elif cluster_type == "cpks":
                org = os.environ.get("YOUR_ORG_ID", cluster[state.Clusterkey.cluster_create_account])
                token = os.environ.get("YOUR_REFRESH_TOKEN", state.get_cluster_token(cluster_name=cluster_name))
                return cloud_type.cpks.status(clusterKey, org, token, cloud=cloud)
            elif cluster_type == "pks":
                if not os.environ.get("JUMPER_VM"):
                    print("Please set the JUMPER_VM environment variable before running any PKS commands")
                    return 1
                return cloud_type.pks.status(clusterKey, cloud=cloud)
            elif cluster_type == "tmc":
                return cloud_type.tmc.status(cluster_name)

def envsetup(cluster_name, region='us-west-2', cloud=False, external_cluster=None, logging_format=False):
    cluster = state.get_cluster_v2(cluster_name=cluster_name)
    # If the cluster can't be found in our state then try to pick it up from the flag.
    # Do this so that we support authenticating against foreign clusters not tracked by our state.
    if not cluster:
        if not external_cluster:
            raise Exception("Pass an external cluster type when authenticating against foreign clusters")

        if external_cluster.lower() == "kops":
            return cloud_type.kops.envsetup(cluster_name)

        if external_cluster.lower() == "eks":
            return cloud_type.eks.envsetup(cluster_name, region, logging_format)
        if external_cluster.lower() == "tmc":
            return cloud_type.tmc.envsetup(cluster_name)
        if external_cluster.lower() == "cpks":
            org = os.environ.get("YOUR_ORG_ID", '')
            token = os.environ.get("YOUR_REFRESH_TOKEN", '')
            return cloud_type.cpks.envsetup(cluster_name, org, token)

        pks_cls = ["pks", "tkgi"]
        if external_cluster.lower() in pks_cls:
            if not os.environ.get("JUMPER_VM"):
                print("Please set the JUMPER_VM environment variable before running any PKS commands")
                return 1
            return cloud_type.pks.envsetup(cluster_name)

        raise Exception("Invalid cluster type {}".format(external_cluster))
    cluster_type = cluster[state.Clusterkey.cluster_type].lower()
    if cluster_type == "kops":
        return cloud_type.kops.envsetup(cluster_name)
    elif cluster_type == "eks":
        return cloud_type.eks.envsetup(cluster_name, cluster[state.Clusterkey.region])
    elif cluster_type == "tmc":
        return cloud_type.tmc.envsetup(cluster_name)
    elif cluster_type == "cpks":
        org = os.environ.get("YOUR_ORG_ID", cluster[state.Clusterkey.cluster_create_account])
        token = os.environ.get("YOUR_REFRESH_TOKEN", state.get_cluster_token(cluster_name=cluster_name))
        return cloud_type.cpks.envsetup(cluster_name, org, token)
    elif cluster_type == "pks":
        if not os.environ.get("JUMPER_VM"):
            print("Please set the JUMPER_VM environment variable before running any PKS commands")
            return 1
        return cloud_type.pks.envsetup(cluster_name)


def list_clusters(cloud=False):
    clusters = state.get_clusters_v2()
    # clusters = state.get_clusters(all=True)
    if clusters:
        t = PrettyTable(['Name', 'Type', 'Flavor', 'Version', 'Region'])
        for key in clusters:
            c = clusters[key]
            t.add_row([key, c[state.Clusterkey.cluster_type], c[state.Clusterkey.flavor],
                       c[state.Clusterkey.tools], c[state.Clusterkey.region]])
        print(t)
        print()
    if os.environ.get("JUMPER_VM"):
        return cloud_type.pks.list()

def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['--verbose']:
        global verbose_flag
        verbose_flag = True
    flavor_name = args.get("<flavor_name>")
    cluster_name = args.get("<cluster_name>")
    external_cluster = args.get("--external_cluster")
    region = args.get("--region")
    zones = args.get("--zones")
    cloud = args.get("--cloud")
    skip_iam = args.get("--no-iam")
    multi_master = args.get("--multi-master")
    do_cleanup = args.get("--assume-yes")
    force = args.get("--force")
    configpath = args.get("--save-config")
    logging_format = args.get("--logging-format")
    username = args.get("--username")

    if args.get("create"):
        return create(flavor_name, cluster_name, region=region,
                      zones=zones, cloud=cloud, multi_master=multi_master,
                      iam_role=True, skip_iam=skip_iam, configpath=configpath,
                      logging_format=logging_format, username=username)
    elif args.get("cleanup"):
        if restricted_cluster_check(cluster_name, args) == 0:
            return 1
        if not do_cleanup:
            answer = input("Do you wish to delete the cluster {}? Please enter y(es) to continue: ".format(cluster_name))
            if answer.lower() in ("y", "yes"):
                do_cleanup = True
        if do_cleanup:
            return cleanup(cluster_name, cloud=cloud, external_cluster=external_cluster, region=region, skip_iam=skip_iam, force=force)
        else:
            print("Cancelled cleanup of cluster {}".format(cluster_name))
            return 0
    elif args.get("status"):
        return status(cluster_name, cloud=cloud)
    elif args.get("envsetup"):
        if not region:
            region = "us-west-2"
        return envsetup(cluster_name, region, cloud=cloud, external_cluster=external_cluster)
    elif args.get("list"):
        return list_clusters(cloud=cloud)
