from flashpkg import nsxsmOps
from tsm.platform import api
from flashpkg.utils import VELERO
from flashpkg.state import state
from flashpkg.infra import cluster
from prettytable import PrettyTable

def logbundle(args):
    cluster_name = args['<saas_cluster_name>']
    namespace = args['<namespace>']
    is_eks = args['--eks']

    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    return nsxsmOps.collect_logbundle(cluster_name, context, name_space=namespace)

def list_tenants(args):
    cluster_name = args['<saas_cluster_name>']
    is_eks = args['--eks']
    saas_cluster = state.get_cluster(cluster_name=cluster_name)

    if not saas_cluster:
        if is_eks:
            cluster.envsetup(cluster_name, external_cluster='eks')
        else:
            cluster.envsetup(cluster_name, external_cluster='kops')
    try:
        api_session = api.setup(cluster_name)
        assert api_session is not None, 'Failed to setup API session'
        tenants = api_session.list_tenants()
        if tenants and len(tenants.json()) > 0:
            table = PrettyTable()
            table.field_names = ["TenantID", "ContactEmail", "TenantName"]
            for tenant in tenants.json():
                table.add_row([tenant['tenantID'], tenant['contactEmail'], tenant['tenantName']])
            print(table)
        return 0
    except Exception as e:
        print("Unable to list tenants: ", str(e))

    return None

def list_backups_or_restores(args):
    if nsxsmOps.is_tool(VELERO):
        cluster_name = args['<saas_cluster_name>']
        is_eks = args['--eks']
        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)

        if args['backups']:
            return list_backups(cluster_name, context)
        if args['restores']:
            return list_restores(cluster_name, context)
    else:
        print("Velero executable not found in system path.")
        print("Please install velero before attempting this command.")
        return 1

def list_backups(cluster_name, context):
    return nsxsmOps.list_backup_restore(cluster_name, context)

def list_restores(cluster_name, context):
    return nsxsmOps.list_backup_restore(cluster_name, context, operation='restore')

def uninstall(args):
    raise NotImplementedError(
        'Not implemented yet, please use \'flash nsxsm install <nsxsm_version> <cluster_name> <ingress_dns> <api_dns> [--production --eks] [--node-isolation]\' instead')

def install(args):
    raise NotImplementedError('Not implemented yet, please use \'flash nsxsm uninstall <cluster_name> [–eks]\' instead')
