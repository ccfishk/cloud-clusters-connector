"""
Usage:
    flash cluster-pool list [--verbose]
    flash cluster-pool upsert <pool_name> <free_threshold>
    flash cluster-pool delete <pool_name>
    flash cluster-pool clean <pool_name> [--more-then=<period> --assume-yes --all]
    flash cluster-pool create cluster <pool_name> using flavor <flavor_name> [--cloud --multi-master --region=<region> \
            --zones=<zones> --no-iam --save-config=<configpath> --verbose --logging-format=<logging-format> --dry-run]
    flash cluster-pool release cluster <pool_name> <cluster_name> [--eks]

Description:
  flash cluster-pool : commands to manage cluster pools and clusters of different types/flavors in cluster pools.
  Builtin flavors are kops_small, kops_medium, kops_large, cpks_privileged, and cpks_unprivileged.

Options:
  --cloud                              Run the command remotely in the cloud. WARNING: this is not yet implemented.
  --multi-master                       Create a multi-master (3 master nodes) cluster. WARNING: implemented for kops clusters only.
  --region=<region>                    Specifies the region to use.
  --assume-yes                         Assume "yes" for any confirmation prompts.
  --force                              Do not wait for cluster cleanup to complete (valid only for EKS clusters)
  --no-iam                             Do not add IAM roles to cluster/worker nodes
  --external_cluster=<cluster_type>    Specifies the external cluster type to work with. This could be kops, cpks, etc.
  --verbose                            Verbose output
  --more-then=<period>                 Removes clusters those locked more then specified period in days. Default: 2 days
  --dry-run                            Doesn't save cluster
"""

import sys
import traceback
from flashpkg import logging
from docopt import docopt
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel
from flashpkg.aws.dynamodb.services import cluster_pool_service
from flashpkg.aws.dynamodb.services.cluster_pool.cp_service import CPService
from prettytable import PrettyTable
from botocore.exceptions import ClientError

verbose_flag = False

def dispatch():
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)

    if args['--verbose']:
        global verbose_flag
        verbose_flag = True

    if args['upsert']:
        return upsert(args)
    elif args['create'] and args['cluster']:
        return create_in_pool(args)
    elif args['list']:
        return list(args)
    elif args['release']:
        return release(args)
    elif args['delete']:
        return delete(args)
    elif args['clean']:
        return clean(args)


def clean(args):
    pool_name = args['<pool_name>']
    assume_yes = args.get("--assume-yes")
    period = args.get("--more-then")
    all = args.get("--all")

    if period and period.isdigit():
        period = int(period)
    elif period is None:
        period = False
    else:
        print('ERROR: --more-then value isn\'t correct')
        return 1

    service = CPService()
    try:
        service.clean(pool_name, period, assume_yes, all)
    except Exception as e:
        traceback.print_exc()
        print(f'Error during cleaning the pool {pool_name} : {e}')
        return 1
    else:
        return 0

def delete(args):
    pool_name = args['<pool_name>']

    service = cluster_pool_service.ClusterPoolService()
    try:
        service.delete(pool_name)
    except ClientError as e:
        if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
            print(f'Cluster Pool {pool_name} doesn\'t exist!')
            return 0
        else:
            print(f'Error during delete pool {pool_name} : {e}')
            return 1
    except Exception as e:
        print(f'Error during delete pool {pool_name} : {e}')
        return 1
    else:
        print(f'Cluster Pool {pool_name} successfully removed!')
        return 0

def release(args):
    pool_name = args['<pool_name>']
    cluster_name = args['<cluster_name>']

    service = CPService()
    try:
        exit_code = service.release(pool_name, cluster_name)
    except Exception as e:
        print(f'Error during release cluster: {e}')
        traceback.print_exc()
        return 1
    else:
        if exit_code == 0:
            print(f'Cluster {cluster_name} released')
        return exit_code


def upsert(args):
    pool_name = args['<pool_name>']
    free_threshold = args['<free_threshold>']

    if not pool_name.islower():
        print('Cluster Pool name should be in lower case!')
        return 1

    if len(pool_name) > 20:
        print('Cluster Pool name should be less then 20 symbols')
        return 1

    try:
        cluster_pool_model = ClusterPoolModel()
        cluster_pool_model.upsert(
            name=pool_name,
            free_threshold=free_threshold
        )
    except Exception as e:
        print(f'Error during upserting cluster pool: {e}')
        return 1
    else:
        print(f'Cluster Pool {pool_name} successfully upserted')
        return 0

def create_in_pool(args):
    pool_name = args['<pool_name>']
    flavor = args['<flavor_name>']

    cloud = args.get('--cloud', False)
    multi_master = args.get('--multi-master', False)
    no_iam = args.get("--no-iam", False)

    region = args.get("--region")
    zones = args.get("--zones")
    save_config = args.get("--save-config")
    dry_run = args.get("--dry-run")

    logging_format = args.get("--logging-format")

    log = logging.log_result(logging_format)
    log_error = logging.log_error(logging_format)

    service = CPService()
    try:
        exit_code, cluster_name = service.create_in_pool(pool_name,
                                                         flavor,
                                                         region,
                                                         zones,
                                                         logging_format,
                                                         cloud,
                                                         multi_master,
                                                         no_iam,
                                                         save_config,
                                                         dry_run)
    except Exception as e:
        if verbose_flag:
            traceback.print_exc()

        log_error(f'Error during creating/fetching cluster in pool: {e}')
        return 1
    else:
        if exit_code == 0:
            log({"cluster_name": cluster_name})
            if not logging_format:
                print(f'Cluster `{cluster_name}` just created!')

    return exit_code

def list(args):
    detailed = args['--verbose']

    HEADERS = ['Name', 'Number of Clusters Busy', 'Number of Clusters Free']
    DETAILED_HEADERS = ['Pool Name', 'Cluster Name', 'Flavor', 'Region', 'Zones', 'Free/Busy', 'Free/Busy Age', 'Cluster Age']

    headers = DETAILED_HEADERS if detailed else HEADERS
    table = PrettyTable(headers)

    service = cluster_pool_service.ClusterPoolService()

    try:
        items = service.list_full() if detailed else service.list_short()

        for item in items:
            table.add_row(item)

        print(str(table))
    except Exception as e:
        print(f'Error during listing pools: {e}')
        return 1
    else:
        return 0
