"""
Usage:
  flash clustergroup create using <testbed_name> <cluster_group_name> [--region=<region> --zones=<zones>]
  flash clustergroup cleanup <cluster_group_name>
  flash clustergroup list
  flash clustergroup status <cluster_group_name>

Description:
  flash clustergroup : commands to manage groups of clusters.
"""
from docopt import docopt
from flashpkg.state import state
from flashpkg.config import config
from flashpkg.infra import cluster
from prettytable import PrettyTable
import sys


def create(testbed_name, cluster_group_name, region=None, zones=None):
    res = 0
    testbed = config.get_testbed(testbed_name)
    if not testbed:
        raise Exception("No such testbed {}".format(testbed_name))
    # First, create the clustergroup entry in the state file
    clustergroup_dict = {
        'testbed_name': testbed_name,
        'cluster_group_name': cluster_group_name
    }
    state.add_clustergroup(clustergroup_dict)
    # Second, create the clusters and update the state file accordingly
    flavor_idx = 0
    for flavor_name, cluster_count in testbed.items():
        flavor_idx += 1
        for cluster_idx in range(cluster_count):
            # Beware: The restrictions on S3 bucket names propagate to cluster names
            # https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html
            cluster_name = "{}-{}-{}".format(cluster_group_name, flavor_idx, cluster_idx+1)
            print("Creating cluster_name {}".format(cluster_name))
            res += cluster.create(
                flavor_name, cluster_name,
                cloud=False, cluster_group_name=cluster_group_name,
                region=region, zones=zones
            )
    return res


def cleanup(cluster_group_name):
    res = 0
    # First, delete the deployed clusters
    clusters = state.get_clusters(cluster_group_name=cluster_group_name)
    for cluster_d in clusters:
        cluster_name = cluster_d['name']
        print("Deleting cluster_name {}".format(cluster_name))
        res += cluster.cleanup(cluster_name)
    # Second, remove the cluster_group entry in the state file
    clustergroup = state.get_clustergroup(cluster_group_name=cluster_group_name)
    if not clustergroup:
        raise Exception("Cluster_group '{}' doesn't exist".format(cluster_group_name))
    else:
        state.remove_clustergroup(cluster_group_name)
    return res


def list_clustergroups():
    t = PrettyTable(['GroupName', 'Testbed'])
    for clustergroup_d in state.get_clustergroups(all=True):
        t.add_row([
            clustergroup_d['cluster_group_name'],
            clustergroup_d['testbed_name'],
        ])
    print(t)


def status(cluster_group_name):
    clusters = state.get_clusters(cluster_group_name=cluster_group_name)
    t = PrettyTable(['ClusterName', 'Type', 'Flavor', 'Version', 'Workers', 'Region', 'Ready'])
    for cluster_d in clusters:
        t.add_row([
            cluster_d['name'],
            cluster_d['type'],
            cluster_d['flavor'],
            cluster_d['version'],
            cluster_d['workers'],
            cluster_d['region'],
            cluster_d['ready'],
        ])
    print(t)


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    testbed_name = args.get("<testbed_name>")
    cluster_group_name = args.get("<cluster_group_name>")
    region = args.get("--region")
    zones = args.get("--zones")
    if args.get("create"):
        return create(testbed_name, cluster_group_name, region=region, zones=zones)
    elif args.get("cleanup"):
        return cleanup(cluster_group_name)
    elif args.get("list"):
        return list_clustergroups()
    elif args.get("status"):
        return status(cluster_group_name)
