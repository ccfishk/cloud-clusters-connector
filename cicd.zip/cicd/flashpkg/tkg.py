"""
Usage:
  flash tkg add management-cluster <cluster_name> --kubeconfig=<kubeconfig>

Description:
  flash tkg : commands to manage tanzu kubernetes grid.

Options:
  --kubeconfig=<kubeconfig>   Path to kubeconfig with the management cluster, user, context.
"""
import sys
import os
import subprocess
from shutil import which
from docopt import docopt

TKG_CLI_CMD = 'tkg'

class PrerequisitesError(Exception):
    def __init__(self, message, code):
        self.message = message
        self.code = code

def load_args():
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    return docopt(__doc__)

def run_cmd(*args):
    return subprocess.check_output([*args], stderr=subprocess.STDOUT)

def is_tkg_cli_installed():
    link = 'https://confluence.eng.vmware.com/pages/viewpage.action?pageId=558312721'
    error_message = f'Prerequisites error: {TKG_CLI_CMD} tool isn\'t installed \nPlease follow the link to install tkg: {link}'
    if not which(TKG_CLI_CMD):
        raise PrerequisitesError(error_message, 1)

def does_tkg_kubeconfig_exist(kubeconfig):
    error_message = f'Prerequisites error: {kubeconfig} isn\'t a file or doesn\'t exist'
    if not os.path.isfile(os.path.expanduser(kubeconfig)):
        raise PrerequisitesError(error_message, 1)

def tkg_add_management_cluster(kubeconfig):
    try:
        run_cmd(TKG_CLI_CMD, 'add', 'management-cluster', '--kubeconfig', kubeconfig)
    except subprocess.CalledProcessError as e:
        message = e.output.decode('utf-8')
        raise Exception(f'Exception occurred during adding management cluster: {message}') from e

def tkg_set_management_cluster(cluster_name):
    try:
        run_cmd(TKG_CLI_CMD, 'set', 'management-cluster', cluster_name)
    except subprocess.CalledProcessError as e:
        message = e.output.decode('utf-8')
        raise Exception(f'Exception occurred during setting management cluster: {message}') from e

def add_management_cluster(cluster_name, kubeconfig):
    tkg_add_management_cluster(kubeconfig)
    tkg_set_management_cluster(cluster_name)

def process():
    try:
        is_tkg_cli_installed()
    except PrerequisitesError as e:
        print(e.message)
        return e.code

    args = load_args()

    if args['add'] and args['management-cluster']:
        cluster_name = args['<cluster_name>']
        kubeconfig = args['--kubeconfig']

        try:
            does_tkg_kubeconfig_exist(kubeconfig)
        except PrerequisitesError as e:
            print(e.message)
            return e.code

        return add_management_cluster(cluster_name, kubeconfig)
