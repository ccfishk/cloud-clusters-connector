"""
Usage:
  flash docker cleanup images
  flash docker cleanup containers
  flash docker cleanup volumes
  flash docker delete image <image_id>
  flash docker scan image <image_id>
  flash docker build <name> <version> <dockerfile> [--build-arg=<build_arg>... --silent]
  flash docker publish <name> <version>

Description:
  flash docker : commands to interact with Docker.
"""
from docopt import docopt
import docker
import json
import logging
import os
import requests
import sys
from flashpkg import utils, cloud

__client = docker.from_env(timeout=600)


def prune_images():
    try:
        __client.images.prune()
        return 0
    except docker.errors.APIError as e:
        print("Failed to prune images: {}".format(e))
        return -1


def prune_containers():
    try:
        __client.containers.prune()
        return 0
    except docker.errors.APIError as e:
        print("Failed to prune containers: {}".format(e))
        return -1


def prune_volumes():
    try:
        __client.volumes.prune()
        return 0
    except docker.errors.APIError as e:
        print("Failed to prune volumes: {}".format(e))
        return -1


def delete_image(id):
    try:
        __client.images.remove(id, True, False)
        return 0
    except docker.errors.APIError as e:
        print("Failed to delete image {}: {}".format(id, e))
        return -1

def scan_image(id):
    # logging.basicConfig(level=logging.DEBUG)
    username = os.getenv('APPCHECK_USERNAME')
    if username is None:
        print("Environment variable  APPCHECK_USERNAME not set")
        return -1
    logging.info('*** APPCHECK_USERNAME %s', username)
    password = os.getenv('APPCHECK_PASSWORD')
    if password is None:
        print("Environment variable  APPCHECK_PASSWORD not set")
        return -1

    try:
        print('Pulling image if not already present ...')
        image = __client.images.pull(id)
    except docker.errors.APIError as e:
        print("Failed to pull image {}: {}".format(id, e))
        return -1

    try:
        image_cname = image.tags[0]
        image_tar_filename = os.path.basename(image_cname)
        image_tar_filepath = os.path.join('/tmp/appcheck', image_tar_filename)
        image_tar_dirpath = os.path.dirname(image_tar_filepath)
        logging.info('*** image tar filepath %s', image_tar_filepath)
        if not os.path.exists(image_tar_dirpath):
            os.makedirs(image_tar_dirpath)
        if os.path.exists(image_tar_filepath):
            logging.info('*** Deleting previous image file')
            os.remove(image_tar_filepath)

        with open(image_tar_filepath, 'wb') as fwb:
            for chunk in image.save():
                fwb.write(chunk)

        logging.info('*** Uploading image to appcheck service')
        with open(image_tar_filepath, 'rb') as frb:
            url = 'https://appcheck.eng.vmware.com/api/upload/'
            headers = {
                "Group": "4",
            }
            resp = requests.put(
                url + image_tar_filename,
                auth=(username, password),
                data=frb,
                headers=headers,
            )
    except docker.errors.APIError as e:
        print("Failed to scan image {}: {}".format(id, e))
        return -1

    try:
        reply = json.loads(resp.text)
        if reply['meta']['code'] == 200:
            print('Report will be available at {}'.format(reply['results']['report_url']))
            return 0
        else:
            print(resp.text)
            return -1
    except json.JSONDecodeError as e:
        print("Failed to scan image {}: {}".format(id, e))
        return -1

# TODO: this should go away once a logging library is put in place in Flash.
def __print(msg, silent):
    if not silent:
        print(msg)

def build(name, version, dockerfile, build_args, silent=False):
    # Create an image using docker file
    # Make sure the GIT_HEAD and GIT_TAG files are created.
    __print("Current Dir: %s" % utils.current_dir(), silent)
    cmd = "git rev-parse HEAD"
    (status, ciHead) = utils.command(cmd, shell=True)
    ciHead = ciHead.rstrip()
    cmd = "git describe --tags %s" % ciHead
    (status, ciTag) = utils.command(cmd, shell=True)
    ciTag = ciTag.rstrip()
    __print("git head %s, Tag = %s" % (ciHead, ciTag), silent)
    f = open(utils.current_dir() + "/GIT_HEAD", "w")
    f.write(ciHead)
    f.close()
    f = open(utils.current_dir() + "/GIT_TAG", "w")
    f.write(ciTag)
    f.close()
    args = []
    args.append("--build-arg GIT_HEAD={}".format(ciHead))
    args.append("--build-arg GIT_TAG={}".format(ciTag))
    for arg in build_args:
        args.append("--build-arg {}".format(arg))

    all_args = " ".join(args)

    # Running command line so that output is visible on screen.
    cmd = "docker build %s -t \"%s:%s\" . -f %s" % (all_args, name, version, dockerfile)
    __print('Running command %s' % cmd, silent)
    (status, res) = utils.command(cmd, streaming=True)
    __print('status,res => {},{}'.format(status, res), silent)
    return status

def publish(name, version):
    # publish image to internal repo in the cloud
    cloud.repo.create(name)
    reg_url = cloud.repo.url(name)
    local_name = "%s:%s" % (name, version)
    remote_name = "%s:%s" % (reg_url, version)
    cloud.repo.login(name)
    img = __client.images.get(local_name)
    img.tag(remote_name)
    cmd = "docker push %s" % remote_name
    (status, res) = utils.command(cmd, streaming=True)
    if (status == 0):
        delete_image(remote_name)
    return status

def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['cleanup']:
        if args['volumes']:
            return prune_volumes()
        elif args['containers']:
            return prune_containers()
        elif args['images']:
            return prune_images()
    elif args['delete']:
        if args['image']:
            return delete_image(args['<image_id>'])
    elif args['scan']:
        if args['image']:
            return scan_image(args['<image_id>'])
    elif args['build']:
        return build(args['<name>'], args['<version>'], args['<dockerfile>'], args['--build-arg'], silent=args['--silent'])
    elif args['publish']:
        return publish(args['<name>'], args['<version>'])
    raise Exception("Invalid argument")
