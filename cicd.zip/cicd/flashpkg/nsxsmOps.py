import os
import yaml
import ast
import boto3
import time
import datetime
import tempfile
import tarfile
from distutils.spawn import find_executable
from botocore.exceptions import ClientError
from kubernetes import client, config
from kubernetes.client.rest import ApiException
from prettytable import PrettyTable
from flashpkg import nsxsm, utils
from flashpkg.aws import repo
from flashpkg.aws import kops
from flashpkg.config import config as flash_config
from deepdiff import DeepDiff
import pprint

REPO_NAME = 'allspark-templates'
DEFAULT_PERIOD = 10.0  # 10 seconds
ALLSPARK_SAAS = '/bin/templates/apps/allspark-saas/'
ALLSPARK_TENANTS = '/bin/templates/apps/allspark-tenants/'
ALLSPARK_CONFIG_FILE = '/bin/templates/apps/allspark-cloud-config.yaml'
STAGE00 = 'stage-00'
STAGE01 = 'stage-01'
STAGE02 = 'stage-02'
STAGE03 = 'stage-03'


def patch_config_map(namespace, configmap_name, temp_dir_tenants):
    update_stage = STAGE03 if namespace == utils.OPERATOR_NAMESPACE else STAGE02
    print("Started configmap patch for {}".format(configmap_name))
    v1_client = client.CoreV1Api()
    # Ignore the config map associated with stateful sets for now

    configmap_file = configmap_name + ".yaml"

    # The k8s-connector and proxy-server deployments have generic file names but in a live system they include a dynamically-added suffix.
    # This approach won't scale going forward...
    if configmap_name.startswith("k8s-connector"):
        configmap_file = "k8s-connector.yaml"

    elif configmap_name.startswith("proxy-server"):
        configmap_file = "proxy-server.yaml"
    elif configmap_name.startswith("allspark-ui"):
        configmap_file = "allspark-gui.yaml"
    elif configmap_name.startswith("migration-configmap"):
        return 0, None, None, None
    try:
        print("Config file  is {}".format(configmap_file))
        with open(os.path.join(temp_dir_tenants, update_stage, "config", configmap_file)) as f:
            desired_config = yaml.safe_load(f.read())
            str_desired_config = str(desired_config)
        existing_cfgmap_obj = v1_client.read_namespaced_config_map(name=configmap_name, namespace=namespace)
        existing_config = yaml.safe_load(existing_cfgmap_obj.data.get(".allsparkconf"))
    except FileNotFoundError:
        print("ConfigMap file {} not found in path {}.".format(configmap_file, os.path.join(temp_dir_tenants, update_stage, "config")))
        return 1, None, None, None
    except ApiException as err:
        print("Exception when calling CoreV1Api->read_namespaced_config_map: {}".format(err))
        return 1
    # Get changes between configs
    ddiff = DeepDiff(existing_config, desired_config)
    pprint.pprint(ddiff)
    print("Updating ConfigMap for {}".format(configmap_name))
    if "type_changes" in ddiff:
        for _, sub_v in ddiff["type_changes"].items():
            if str(sub_v["new_value"]).startswith("{{."):
                print("A new template variable was introduced in the desired config")
                print("This is not currently supported in the tenant update")
                return 1, None, None, None
    if "values_changed" in ddiff:
        for _, sub_v in ddiff["values_changed"].items():
            if str(sub_v["new_value"]).startswith("{{."):
                str_desired_config = str_desired_config.replace(sub_v["new_value"], sub_v["old_value"])
    updated_config = ast.literal_eval(str_desired_config)
    updated_data_body = {".allsparkconf": yaml.safe_dump(updated_config)}

    # Patch ConfigMap object
    metadata = client.V1ObjectMeta(name=configmap_name, namespace=namespace)
    updated_cfgmap_obj = client.V1ConfigMap(api_version="v1", kind="ConfigMap", data=updated_data_body, metadata=metadata)
    try:
        v1_client.patch_namespaced_config_map(name=configmap_name, namespace=namespace, body=updated_cfgmap_obj)
        print("Successfully patched configMap: {}".format(configmap_name))
        return 0, configmap_name, updated_cfgmap_obj, existing_cfgmap_obj
    except ApiException as err:
        print("Exception when calling CoreV1Api->patch_namespaced_config_map: {}".format(err))
        print("Failed to patch configMap {}".format(configmap_name))
        return 1, None, None, None


def patch_config_map_all(namespace, temp_dir_tenants):
    v1_client = client.CoreV1Api()
    config_name_list = []
    cfgmap_status = []
    config_map_list = v1_client.list_namespaced_config_map(namespace=namespace)
    for cfg_map in config_map_list.items:
        if "timescaledb" not in cfg_map.metadata.name:
            config_name_list.append(cfg_map.metadata.name)
    for configmap_name in config_name_list:
        try:
            status, configmap_name, updated_cfgmap_obj, existing_cfgmap_obj = patch_config_map(namespace, configmap_name, temp_dir_tenants)
            assert status != 1, "Failed to patch ConfigMap {}".format(configmap_name)
            cfgmap_status.append((configmap_name, updated_cfgmap_obj, existing_cfgmap_obj))
        except AssertionError as err:
            print(err)
            print("Rolling back to previous configmap objects for all updated configMaps")
            for configmap_name_rb, updated_cfgmap_obj, existing_cfgmap_obj in cfgmap_status:
                print("Rolling back config for configmap {}".format(configmap_name))
                try:
                    v1_client.patch_namespaced_config_map(name=configmap_name_rb, namespace=namespace, body=existing_cfgmap_obj.data.get(".allsparkconf"))
                except ApiException as err:
                    print("Exception when calling CoreV1Api->patch_namespaced_config_map: {}".format(err))
            return 1, None
    print("Finished updating all configmaps")
    return 0, cfgmap_status


def get_svc_file_name(svc_name):
    # The k8s-connector and proxy-server services have generic file names but in a live system they include a dynamically-added suffix.
    # allspark-ui service is defined in allspark-gui file
    # This approach won't scale going forward...
    if svc_name.startswith("k8s-connector"):
        return "k8s-connector.yaml"
    elif svc_name.startswith("proxy-server"):
        return "proxy-server.yaml"
    elif svc_name.startswith("allspark-ui"):
        return "allspark-gui.yaml"
    else:
        return svc_name + ".yaml"


def patch_namespaced_service(namespace, svc_name, temp_dir_tenants):
    update_stage = STAGE03 if namespace == utils.OPERATOR_NAMESPACE else STAGE02
    print("Started update to service {}".format(svc_name))
    v1_client = client.CoreV1Api()
    # Ignore the service associated with stateful sets for now

    svc_file = get_svc_file_name(svc_name)

    file_path = os.path.join(temp_dir_tenants, update_stage, svc_file)

    str_desired_svc = None
    desired_svc = {}
    try:
        with open(file_path) as yaml_file:
            section = yaml.safe_load_all(yaml_file)
            for contents in section:
                if contents.get("kind") == "Service":
                    desired_svc = contents
                    str_desired_svc = str(contents)
                    break
        existing_svc_obj = v1_client.read_namespaced_service(name=svc_name, namespace=namespace)
    except FileNotFoundError:
        print("Service file {} not found in path {}.".format(svc_file, file_path))
        return 1, None, None, None
    except ApiException as err:
        print("Exception when calling CoreV1Api->read_namespaced_service: {}".format(err))
        return 1, None, None, None
    # Get changes between configs
    print("Fetching deep diff for service {}".format(svc_name))
    ddiff = DeepDiff(yaml.safe_load(str(existing_svc_obj)), desired_svc)
    pprint.pprint(ddiff)
    print("Updating service definition for {}".format(svc_name))
    if "type_changes" in ddiff:
        if "{{." in str(ddiff["type_changes"].values()):
            print("A new template variable was introduced in the desired service")
            print("This is not currently supported in the tenant update")
            return 1, None, None, None
    if "values_changed" in ddiff:
        for _, sub_v in ddiff["values_changed"].items():
            if str(sub_v["new_value"]).startswith("{{."):
                str_desired_svc = str_desired_svc.replace(sub_v["new_value"], sub_v["old_value"])

    updated_svc = ast.literal_eval(str_desired_svc)
    updated_svc_str = yaml.safe_dump(updated_svc)
    updated_svc_obj = yaml.safe_load(updated_svc_str)
    # Patch Service object
    try:
        v1_client.patch_namespaced_service(name=svc_name, namespace=namespace, body=updated_svc_obj)
        print("Successfully patched service: {}".format(svc_name))
        return 0, svc_name, updated_svc_obj, existing_svc_obj
    except ApiException as err:
        print("Exception when calling CoreV1Api->patch_namespaced_service: {}".format(err))
        print("Failed to patch service {}".format(svc_name))
        return 1, None, None, None


def patch_namespaced_service_all(namespace, temp_dir_tenants):
    v1 = client.CoreV1Api()
    svc_name_list = []
    svc_status = []
    svc_list = v1.list_namespaced_service(namespace=namespace)
    ignore_svc = ["timescaledb", "neo4j", "influxdb", "metricsdb", "etcd", "etcd-operator", "etcd-restore-operator", "etcd-client"]
    for svc in svc_list.items:
        if svc.metadata.name not in ignore_svc:
            svc_name_list.append(svc.metadata.name)
    for svc_name in svc_name_list:
        print(svc_name)
        try:
            status, svc_name, updated_svc_obj, existing_svc_obj = patch_namespaced_service(namespace, svc_name, temp_dir_tenants)
            assert status != 1, "Failed to patch service {}".format(svc_name)
            svc_status.append((svc_name, updated_svc_obj, existing_svc_obj))
        except AssertionError as err:
            print(err)
            print("Rolling back to previous service objects for all updated services")
            for svc_name_rb, updated_svc_obj, existing_svc_obj in svc_status:
                print("Rolling back config for service {}".format(svc_name))
                try:
                    v1.patch_namespaced_service(name=svc_name_rb, namespace=namespace, body=existing_svc_obj)
                except ApiException as err:
                    print("Exception when calling CoreV1Api->patch_namespaced_service: {}".format(err))
            return 1, None
    return 0, svc_status

def __get_deployments(namespace, deployment=None):
    v1beta = client.ExtensionsV1beta1Api()
    if deployment:
        return v1beta.list_namespaced_deployment(namespace, field_selector='metadata.name=' + deployment).items
    else:
        return v1beta.list_namespaced_deployment(namespace).items

def wait_for_deployment_deletion(namespace, deploymentName=None, retry=10, retry_interval=30):
    deployments = __get_deployments(namespace, deploymentName)
    while len(deployments) > 0 and retry > 0:
        time.sleep(retry_interval)
        retry -= 1
        deployments = __get_deployments(namespace, deploymentName)
    if retry == 0:
        deploymentNames = [deployment.metadata.name for deployment in deployments]
        print("Timeout deleting deployments {} in namespace {} after {} seconds".format(deploymentNames, namespace, retry * retry_interval))
        return "FAILURE"
    return "SUCCESS"

def update_deployment(cluster_name, namespace, deployment_label, version, temp_dir_tenants, is_eks):  # noqa: C901
    """Update the service deployment version in a given namespace"""

    update_stage = STAGE03 if namespace == utils.OPERATOR_NAMESPACE else STAGE02

    deployment_file = deployment_label+".yaml"

    # The k8s-connector and proxy-server deployments have generic file names but in a live system they include a dynamically-added suffix.
    # This approach won't scale going forward...
    if deployment_label.startswith("k8s-connector"):
        deployment_file = "k8s-connector.yaml"

    if deployment_label.startswith("proxy-server"):
        deployment_file = "proxy-server.yaml"
    if deployment_label.startswith("allspark-ui"):
        deployment_file = "allspark-gui.yaml"

    file_path = os.path.join(temp_dir_tenants, update_stage, deployment_file)
    strDoc = None
    try:
        with open(file_path) as yaml_file:
            section = yaml.safe_load_all(yaml_file)
            for contents in section:
                if contents.get("kind") == "Deployment":  # Only look at deployments for now.
                    strDoc = str(contents)
                    break
    except FileNotFoundError:
        print("Deployment file for {} not found in release {}".format(deployment_label, version))
        return 1, None, None, None, None, None

    if strDoc is None:
        print("No Deployment section found in yaml for {}".format(deployment_label))
        return 1, None, None, None, None, None

    deployment = None
    deployment_name = None
    v1beta = client.ExtensionsV1beta1Api()
    ret = v1beta.list_namespaced_deployment(namespace)
    if ret.items is not None:
        for i in ret.items:
            if deployment_label == i.spec.template.metadata.labels.get("app"):
                deployment = i
                deployment_name = i.metadata.name
                break
    if not deployment:
        print("Unable to find service deployment {} for tenant {}".format(deployment_label, namespace))
        return 1, None, None, None, None, None

    appLbl = deployment.spec.template.metadata.labels.get("app")
    versionLbl = deployment.spec.template.metadata.labels.get("version")
    if versionLbl is None:
        print("Deployment is missing the required version label")
        return 1, None, None, None, None, None

    # Hacky, but this tool lives outside our platform with no knowledge of our lifecycles.
    strDoc = strDoc.replace("{{.ServiceName}}", deployment_label).replace("{{.TenantName}}", namespace).replace("{{.Namespace}}", namespace)

    # This service is a special case as it has a dynamically added suffix in a live system. Hacky and won't scale going forward...
    if deployment_label.startswith("k8s-connector"):
        clusterUUID = None

        # The connector only has a single container so no need to loop through the containers.
        envs = deployment.spec.template.spec.containers[0].env
        for env in envs or []:
            if env.name == "CLUSTER_UUID":
                clusterUUID = env.value
                break

        if clusterUUID is None:
            print("ClusterUUID could not be found for {}".format(deployment_label))
            return 1, None, None, None, None, None

        strDoc = strDoc.replace("{{.ClusterUUID}}", clusterUUID)

    # Another special case.
    if deployment_label.startswith("proxy-server"):
        cname = deployment_label.rsplit("-")[-1]
        strDoc = strDoc.replace("{{.ClusterName}}", cname)

    doc = ast.literal_eval(strDoc)
    old_version = appLbl + "-" + versionLbl
    if old_version == doc.get("metadata").get("name"):
        print("Versions are the same, nothing to do")
        return 1, None, None, None, None, None

    print("Removing old deployment {}".format(deployment_label))
    v1beta.delete_namespaced_deployment(namespace=namespace, name=old_version, body=client.V1DeleteOptions(
        propagation_policy='Foreground',
        grace_period_seconds=5
    ))

    if wait_for_deployment_deletion(namespace, old_version) == "FAILURE":
        return 1

    print("Deleted old deployment {}".format(deployment_label))
    print("Creating new deployment {}".format(deployment_label))
    containers = []
    for container in doc.get("spec").get("template").get("spec").get("containers") or []:
        ports = []
        envs = []
        volume_mounts = []
        for port in container.get("ports") or []:
            ports.append(client.V1ContainerPort(
                name=port.get("name"),
                container_port=port.get("containerPort"),
                host_port=port.get("hostPort"),
                protocol=port.get("protocol"),
            ))

        for env in container.get("env") or []:
            envs.append(client.V1EnvVar(
                name=env.get("name"),
                value=env.get("value"),
                value_from=env.get("valueFrom")
            ))

        for volume_mount in container.get("volumeMounts") or []:
            volume_mounts.append(client.V1VolumeMount(
                name=volume_mount.get("name"),
                mount_path=volume_mount.get("mountPath")
            ))

        containers.append(client.V1Container(
                          name=container.get("name"),
                          image=container.get("image"),
                          ports=ports,
                          env=envs,
                          args=container.get("args"),
                          command=container.get("command"),
                          image_pull_policy=container.get("imagePullPolicy"),
                          volume_mounts=volume_mounts,
                          security_context=container.get("securityContext"),
                          resources=container.get("resources"),
                          readiness_probe=container.get("readinessProbe"),
                          liveness_probe=container.get("livenessProbe")
                          ))

    if len(containers) == 0:
        print("No containers found in deployment {}".format(deployment_label))
        return 1, None, None, None, None, None

    volumes = []
    for volume in doc.get("spec").get("template").get("spec").get("volumes") or []:
        if volume.get("emptyDir") == {}:
            volumes.append(client.V1Volume(
                name=volume.get("name"),
                empty_dir=client.V1EmptyDirVolumeSource()
            ))
        if volume.get("configMap"):
            volumes.append(client.V1Volume(
                name=volume.get("name"),
                config_map=client.V1ConfigMapVolumeSource(
                    name=volume.get("configMap").get("name"),
                )
            ))
        if volume.get("secret"):
            volumes.append(client.V1Volume(
                name=volume.get("name"),
                secret=client.V1SecretVolumeSource(secret_name=volume.get("secret").get("secretName"))
            ))

    # Get pod's node affinity and tolerations if applicable.
    affinity = doc.get("spec").get("template").get("spec").get("affinity") or None
    tolerations = doc.get("spec").get("template").get("spec").get("tolerations") or None

    new_deployment = client.ExtensionsV1beta1Deployment(
        api_version="extensions/v1beta1",
        kind="Deployment",
        metadata=client.V1ObjectMeta(name=doc.get("metadata").get("name")),
        spec=client.ExtensionsV1beta1DeploymentSpec(
            replicas=doc.get("spec").get("replicas"),
            template=client.V1PodTemplateSpec(
                metadata=client.V1ObjectMeta(labels=doc.get("spec").get("template").get("metadata").get("labels")),
                spec=client.V1PodSpec(containers=containers, volumes=volumes, service_account_name=doc.get("spec").get("template").get("spec").get("serviceAccountName"),
                                      affinity=affinity, tolerations=tolerations)
            )
        )
    )
    try:
        v1beta.create_namespaced_deployment(namespace=namespace, body=new_deployment)
    except ApiException as e:
        print("Failed to create new deployment {}: {}".format(deployment_label, str(e)))
        print("Rolling back to original version")
        v1beta.create_namespaced_deployment(namespace=namespace, body=deployment)
        return 1, None, None, None, None, None

    print("Deployment {} created at nsxsm version {}".format(appLbl, version))
    print("Checking if deployment is running")
    newName = doc.get("metadata").get("name")
    ret = nsxsm.wait_for_with_status(cluster_name, namespace, ['Running'], 1, 300, pod_name=newName, is_eks=is_eks)
    if ret != 0:
        print("New version of deployment did not become ready. Removing new version and restoring original version")
        v1beta.delete_namespaced_deployment(namespace=namespace, name=newName, body=client.V1DeleteOptions(
            propagation_policy='Foreground',
        ))

        # Keeping the resource version for the original deployment will cause this to break.
        # We don't want to keep the annotations either.
        deployment.metadata.annotations = {}
        deployment.metadata.resource_version = ""
        v1beta.create_namespaced_deployment(namespace=namespace, body=deployment)
        return 1, None, None, None, None, None

    print("Deployment {} at nsxsm version {} is now ready".format(appLbl, version))
    return 0, deployment_name, deployment_label, deployment, newName, new_deployment


def get_changelist(cluster_name, namespace, desired_versions, is_eks, context_set=False):
    svc_list = nsxsm.list_service_versions(cluster_name, namespace, is_eks=is_eks, return_object=True, context_set=context_set)
    changelist = []
    if svc_list:
        print("Getting svc list")
        print(svc_list)
        table = PrettyTable(['Deployment Name ', 'Service Label', 'Current Version', 'Desired Version'])
        for svc, label, version in svc_list:
            if label is not None and version is not None:
                if label in desired_versions.keys():
                    changelist.append((svc, label, version, desired_versions[label]))
                    table.add_row([svc, label, version, desired_versions[label]])
                elif label.startswith('k8s-connector'):
                    changelist.append((svc, label, version, desired_versions['k8s-connector']))
                    table.add_row([svc, label, version, desired_versions['k8s-connector']])
                elif label.startswith('proxy-server'):
                    changelist.append((svc, label, version, desired_versions['proxy-server']))
                    table.add_row([svc, label, version, desired_versions['proxy-server']])
        print(table)
    return changelist


def check_major_version_upgrade(cluster_name, namespace, force_update, is_eks, temp_dir, context_set=False):
    desired_versions = {}

    if 'allspark-cloud-config.yaml' not in os.listdir(temp_dir):
        print("Unable to find the requested saas release's config file. Aborting !!")
        return 1, None

    with open(os.path.join(temp_dir, 'allspark-cloud-config.yaml')) as f:
        yf = yaml.safe_load(f.read())
        if namespace == utils.OPERATOR_NAMESPACE:
            services = yf['services']['global']
        else:
            services = yf['services']['local']
        for k, v in services.items():
            desired_versions[k] = v['image'].split(':')[-1]
    # Get deployment change list
    changelist = get_changelist(cluster_name, namespace, desired_versions, is_eks, context_set=context_set)
    if changelist:
        # Check for major version upgrades
        for _, label, v1, v2 in changelist:
            if v1.split('.')[0].lower() != v2.split('.')[0].lower() and not force_update:
                print(
                    "The desired deployment for service {} from {} to {} requires a major version change.".format(label, v1,
                                                                                                                  v2))
                print("!! Unable to proceed with update of deployments !!")
                print("Please use '--force' to force an update")
                return 1, None
        return 0, changelist
    else:
        return 1, None


def update_deployment_all(cluster_name, namespace, allspark_version, temp_dir_tenants, changelist, is_eks):
    deployment_state_tracker = []

    # Update deployments
    updated_svc = []
    skipped_svc = []
    v1beta = client.ExtensionsV1beta1Api()
    for _, label, v1, v2 in changelist:
        version1 = v1.split('.')
        version2 = v2.split('.')
        if version1[1] != version2[1] or version1[2] != version2[2]:
            print("Proceeding with the update of deployment {} from version: {} to version: {}".format(label, v1, v2))
            try:
                code, deployment_name, deployment_label, deployment, newName, new_deployment = update_deployment(cluster_name,
                                                                                                                 namespace, label, allspark_version, temp_dir_tenants, is_eks)
                assert code != 1, "Failed to update the deployment {} from version: {} to version: {}".format(label, v1, v2)
                deployment_state_tracker.append((deployment_name, deployment_label, deployment, newName, new_deployment))
            except AssertionError as err:
                print(err)
                print("Rolling back all updated deployments to older versions")
                if deployment_state_tracker:
                    for dep_name, dep_label, dep, new_dep_name, _ in deployment_state_tracker:
                        print("Deleting existing deployment {}".format(dep_label))
                        try:
                            v1beta.delete_namespaced_deployment(namespace=namespace, name=new_dep_name,
                                                                body=client.V1DeleteOptions(
                                                                    propagation_policy='Foreground'
                                                                ))
                        except ApiException as e:
                            print("Failed to delete deployment {}: {}".format(new_dep_name, str(e)))
                            raise e
                        print("Restoring deployment for: {}".format(dep_label))
                        # Keeping the resource version for the original deployment will cause this to break.
                        # We don't want to keep the annotations either.
                        dep.metadata.annotations = {}
                        dep.metadata.resource_version = ""
                        try:
                            v1beta.create_namespaced_deployment(namespace=namespace, body=dep)
                        except ApiException as e:
                            print("Failed to restore deployment {}: {}".format(dep_name, str(e)))
                            raise e
                print("Failed to update deployments for nsxsm version: {}".format(allspark_version))
                return 1
            updated_svc.append((label, v1, v2))
        else:
            skipped_svc.append((label, v1, v2))
    print("\nUpdated Deployments: {}".format(updated_svc))
    print("\nSkipped Deployments: {}".format(skipped_svc))
    return 0


def patch_deployment_with_nsxsmversion(namespace, deployment_label, allspark_version):
    repo_url = repo.url(REPO_NAME)
    allspark_image = repo_url + ':' + allspark_version
    deployment = None
    dep_name = None
    v1beta = client.ExtensionsV1beta1Api()
    ret = v1beta.list_namespaced_deployment(namespace)
    if ret.items is not None:
        for i in ret.items:
            labels = i.spec.template.metadata.labels.get("app")
            if labels is not None:
                if deployment_label in labels:
                    dep_name = i.metadata.name
                    deployment = i
                    break
    deployment.spec.template.spec.containers[0].image = allspark_image
    try:
        v1beta.patch_namespaced_deployment(namespace=namespace, name=dep_name,
                                           body=deployment
                                           )
        print("Updated {} deployment with the allspark-templates image: {}".format(deployment_label, allspark_version))
    except ApiException as e:
        print("Failed to patch deployment {}: {}".format(dep_name, str(e)))
        return 1
    return 0


def handle_service_updates(v1_client, namespace, temp_dir_tenants, cfgmap_patch_obj):
    try:
        svc_patch_status, svc_patch_obj = patch_namespaced_service_all(namespace, temp_dir_tenants)
        assert svc_patch_status != 1, "Function patch_namespaced_service_all returned non-zero status code"
        return svc_patch_status, svc_patch_obj
    except AssertionError as err:
        print("Patching services failed {}".format(err))
        print("Rolling back Configmaps to older configuration")
        try:
            for configmap_name, _, existing_cfgmap_obj in cfgmap_patch_obj:
                print("Rolling back configmap for {}".format(configmap_name))
                v1_client.patch_namespaced_config_map(name=configmap_name, namespace=namespace, body=existing_cfgmap_obj)
        except ApiException as err:
            print("Exception when calling CoreV1Api->patch_namespaced_config_map: {}".format(err))
        return 1, None


def handle_deployment_updates(v1_client, cluster_name, namespace, temp_dir_tenants, nsxsm_version, changelist, cfgmap_patch_obj, svc_patch_obj, is_eks):
    try:
        assert update_deployment_all(cluster_name, namespace, nsxsm_version, temp_dir_tenants, changelist, is_eks) != 1, "patch_deployment_with_nsxsmversion failed"
    except AssertionError as err:
        print("Updating deployments failed {}".format(err))
        print("Rolling back Configmaps to older configuration")
        try:
            for configmap_name, _, existing_cfgmap_obj in cfgmap_patch_obj:
                print("Rolling back configmap for {}".format(configmap_name))
                v1_client.patch_namespaced_config_map(name=configmap_name, namespace=namespace, body=existing_cfgmap_obj)
            print("Rolling back services to older configuration")
            for svc_name, _, existing_svc_obj in svc_patch_obj:
                print("Rolling back service configuration for {}".format(svc_name))
                v1_client.patch_namespaced_service(name=svc_name, namespace=namespace, body=existing_svc_obj)
        except ApiException as err:
            print("Exception when calling CoreV1Api: {}".format(err))
        return 1

    try:
        if namespace == utils.OPERATOR_NAMESPACE:
            print("Updating the global-registration-service deployment with the allspark-templates image")
            assert patch_deployment_with_nsxsmversion(namespace, 'global-registration-service', nsxsm_version) == 0, "patch_deployment_with_nsxsmversion failed."
        else:
            print("Updating the cluster-lifecycle-manager deployment with the allspark-templates image")
            assert patch_deployment_with_nsxsmversion(namespace, 'cluster-lifecycle-manager', nsxsm_version) == 0, "patch_deployment_with_nsxsmversion failed."
    except AssertionError as err:
        print("Failed to patch the allspark templates image in the deployment. {}".format(err))
        return 1
    return 0

def generate_context(cluster_name, is_eks=False):
    c = nsxsm.get_cluster(cluster_name=cluster_name)
    # If cluster is not found in local state, default to KOPS?
    if not c and not is_eks:
        return cluster_name + '.k8s.local'
    elif c and c.get("type") == "kops":
        return cluster_name + '.k8s.local'
    elif is_eks or c.get("type") == "eks":
        sts_client = boto3.client('sts')
        r = sts_client.get_caller_identity()
        account_id = r['Account']
        if not c:
            region_name = flash_config.get_cloud_region()
        else:
            region_name = c.get("region")
        context = 'arn:aws:eks:%s:%s:cluster/%s' % (region_name, account_id, cluster_name)
        return context
    elif c and c.get("type") == "tmc":
        return cluster_name
    elif c and c.get("type") == "tkg":
        context = '%s-admin@%s' % (cluster_name, cluster_name)
        return context
    else:
        raise Exception("Unsupported cluster type {} for Saas".format(c.get("type")))


def validate_cluster_type(name, type, flavor):
    # Skip checks for non-KOPS clusters
    if flavor != 'kops':
        return 0
    cluster_type = kops.type(name)
    if cluster_type != type:
        print("Cluster networking type is {}. Expected cluster networking type is {}".format(cluster_type, type))
        return 1
    return 0


def add_or_remove_instance_tag(name, type, region, tag_key, value, operation):
    if type == utils.EKS:
        tag_name = utils.EKS_CLUSTER_TAG
        tag_value = name
    else:
        # Assume KOPS
        tag_name = utils.KOPS_CLUSTER_TAG
        tag_value = name + '.k8s.local'
    client = boto3.client('ec2', region_name=region)
    custom_filter = [{'Name': tag_name, 'Values': [tag_value]}]
    cluster_resources = []
    try:
        r = client.describe_instances(Filters=custom_filter)
        for res in r['Reservations']:
            for i in res['Instances']:
                cluster_resources.append(i['InstanceId'])
        if len(cluster_resources) < 1:
            print("No cluster instances to be tagged")
            return 0
        if operation == utils.DELETE:
            r = client.delete_tags(Resources=cluster_resources, Tags=[{'Key': tag_key}])
            if r['ResponseMetadata']['HTTPStatusCode'] == 200:
                print("Tag key {} removed from cluster nodes".format(tag_key))
        else:
            # Add tags
            r = client.create_tags(Resources=cluster_resources, Tags=[{'Key': tag_key, 'Value': value}])
            if r['ResponseMetadata']['HTTPStatusCode'] == 200:
                print("Tag key {} with value {} added to cluster nodes".format(tag_key, value))
        return 0
    except ClientError as err:
        print("Unable to tag cluster instances: {}".format(err))
        return 1

def collect_logbundle(cluster_name, context, name_space=None, disable_output=False):
    config.load_kube_config(context=context)
    api_instance = client.CoreV1Api()
    tar = None
    ret_code = 0
    found = False
    try:
        now = datetime.datetime.now().strftime("%s")
        home = os.path.expanduser("~")
        if name_space:
            filename = context.replace('/', '-') + '-' + name_space + '-' + now + '.tgz'
        else:
            filename = context.replace('/', '-') + '-' + now + '.tgz'
        logbundle = os.path.join(home, filename)
        namespaces = api_instance.list_namespace()
        temp_dir = tempfile.mkdtemp()
        for ns in namespaces.items:
            namespace = ns.metadata.name
            if name_space and name_space != namespace:
                continue
            elif namespace in utils.IGNORE_NAMESPACES:
                continue
            else:
                found = True
                pods = api_instance.list_namespaced_pod(namespace)
                for pod in pods.items:
                    if pod.status.phase and (pod.status.phase == 'Running' or pod.status.phase == 'Succeeded'):
                        containers = api_instance.read_namespaced_pod(name=pod.metadata.name, namespace=namespace)
                        for c in containers.spec.containers:
                            filename = temp_dir + '/' + c.name + '--' + pod.metadata.name
                            logs = api_instance.read_namespaced_pod_log(name=pod.metadata.name, namespace=namespace, container=c.name)
                            with open(filename, 'wb') as f:
                                f.write(logs.encode('utf-8'))
                    else:
                        filename = temp_dir + '/failed--' + pod.metadata.name
                        with open(filename, 'wb') as f:
                            f.write(yaml.safe_dump(pod.to_dict()).encode('utf-8'))
        if found:
            tar = tarfile.open(logbundle, 'w:gz')
            tar.add(temp_dir, arcname='.')
            if not disable_output:
                print("Logs bundle collected as ", logbundle)
        else:
            if name_space:
                print("Unable to collect log bundle for {} in namespace {}".format(cluster_name, name_space))
            else:
                print("Unable to collect log bundle for {}".format(cluster_name))
            ret_code = 1
    except ApiException as e:
        print('Exception when reading logs:', e)
        ret_code = 1
    except Exception as e:
        print('Received error:', e)
        ret_code = 1
    finally:
        if tar:
            tar.close()
    return ret_code

def is_tool(name):
    '''Check if command with a given name exists in the path and is an executable'''
    return find_executable(name) is not None

def list_backup_restore(cluster_name, context, operation=None):
    '''List all velero backups for a given cluster/context'''
    if operation == 'restore':
        cmd = "velero --kubecontext=%s get restores" % (context)
    else:
        operation = 'backup'
        cmd = "velero --kubecontext=%s get backups" % (context)
    (status, out) = utils.command(cmd, streaming=True)
    if (status != 0):
        print("Error listing %ss for cluster %s: %s" % (
              operation, cluster_name, out))
    return status

def restore_tenant(cluster_name, tenant_id, backup_name, context):
    '''Restore a tenant using a given velero backup'''
    # Verify if the backup file actually exists
    cmd = ("velero --kubecontext=%s get backup %s") % (context, backup_name)
    (status, out) = utils.command(cmd, streaming=True)
    if (status != 0):
        print("Error location backup %s for cluster %s" % (
              backup_name, cluster_name))
        return status

    if tenant_id in utils.IGNORE_NAMESPACES or tenant_id == utils.ISTIO_NAMESPACE or tenant_id == utils.OPERATOR_NAMESPACE:
        print("Restore not supported for namespace %s" % (tenant_id))
        return 1

    config.load_kube_config(context=context)
    api_instance = client.CoreV1Api()
    try:
        api_instance.delete_namespace(tenant_id, pretty='true', grace_period_seconds=0,
                                      propagation_policy='Foreground')
        print("Deleting namespace {}".format(tenant_id))
    except ApiException as e:
        if e.status == 404:
            print("Namespace %s not found. Proceeding with restore" % (tenant_id))
        else:
            print("Exception occuredn when deleting namespace %s: %s\n" % (tenant_id, e))
            return 1
    base_cmd = ("velero --kubecontext=%s restore create --from-backup %s --include-namespaces %s") % (
        context, backup_name, tenant_id)
    (status, out) = utils.command(base_cmd + " --exclude-resources serviceaccounts", streaming=True)
    if (status != 0):
        print("Error restoring tenant %s in cluster %s without serviceaccounts: %s" % (
            tenant_id, cluster_name, out))
        return status
    # Wait between successive restore requests
    time.sleep(10)
    (status, out) = utils.command(base_cmd + " --include-resources serviceaccounts", streaming=True)
    if (status != 0):
        print("Error restoring tenant %s in cluster %s with serviceaccounts: %s" % (
            tenant_id, cluster_name, out))
        return status
    return status

def patch_aws_auth_roles_(cluster_name, context, namespace, sa_name, groups):
    cfgmap_name = "aws-auth"
    cluster = nsxsm.get_cluster(cluster_name=cluster_name)
    eksctl_get_irsa = ["eksctl", "get", "iamserviceaccount", "--output", "yaml",
                       "--region", cluster.get("region"), "--cluster", cluster_name]
    (status, out) = utils.command(eksctl_get_irsa, streaming=False)
    if status != 0:
        print("Error getting irsa for cluster %s", cluster_name)
        return status
    irsa_yaml = yaml.safe_load(out)
    arn = None
    for role in irsa_yaml["iam"]["serviceAccounts"]:
        if role["metadata"]["name"] == sa_name and role["metadata"]["namespace"] == namespace:
            arn = role["status"]["roleARN"]
    if not arn:
        print("Role not found in eks cluster:", irsa_yaml)
        return 1
    config.load_kube_config(context=context)
    api_instance = client.CoreV1Api()
    cfgmap = api_instance.read_namespaced_config_map(name=cfgmap_name, namespace="kube-system")
    map_roles = yaml.safe_load(cfgmap.data["mapRoles"])
    new_role = dict(groups=groups, rolearn=arn, username=sa_name)
    role_idx = [i for i, role in enumerate(map_roles) if role["username"] == sa_name]
    if len(role_idx):
        role = map_roles[role_idx[0]]
        if role["groups"] == groups and role["rolearn"] == arn:
            return 0
        else:
            map_roles[role_idx[0]] = new_role
    else:
        map_roles.append(new_role)
    cfgmap.data["mapRoles"] = yaml.safe_dump(map_roles)
    api_instance.patch_namespaced_config_map(name=cfgmap_name, namespace="kube-system", body=cfgmap)

def patch_aws_auth_roles(cluster_name, context, namespace, sa_name, groups):
    ret = patch_aws_auth_roles_(cluster_name, context, namespace, sa_name, groups)
    if ret != 0:
        time.sleep(10)
        ret = patch_aws_auth_roles_(cluster_name, context, namespace, sa_name, groups)
    return ret
