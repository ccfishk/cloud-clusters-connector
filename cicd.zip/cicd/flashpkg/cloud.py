from flashpkg.config import config

CLOUD = config.get_allspark_cloud()
if CLOUD == 'aws':
    import flashpkg.aws.runner as runner
    import flashpkg.aws.container as container
    import flashpkg.aws.repo as repo
    import flashpkg.aws.kops as kops
    import flashpkg.aws.eks as eks
    import flashpkg.aws.cpks as cpks
    import flashpkg.pks as pks
    import flashpkg.aws.bbl as bbl
    import flashpkg.aws.jn as jn
    import flashpkg.aws.storage as storage
    import flashpkg.aws.build as build
    import flashpkg.aws.tmc as tmc
    import flashpkg.platforms.tkg as tkg
    import flashpkg.platforms.tkgs as tkgs
    import flashpkg.platforms.tkgi as tkgi
    import flashpkg.aws.dynamodb as dynamodb
    __all__ = [
        "runner",
        "container",
        "repo",
        "kops",
        "eks",
        "cpks",
        "pks",
        "bbl",
        "jn",
        "storage",
        "build",
        "tmc",
        "tkg",
        "dynamodb",
        "tkgs",
        "tkgi"
    ]
else:
    raise Exception("Cloud type %s is not supported." % CLOUD)
