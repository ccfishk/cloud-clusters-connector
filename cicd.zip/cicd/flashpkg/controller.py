"""
Usage:
  flash controller install <nsxsm_version> <cluster_name> <ingress_dns> <api_dns> [--production --eks] [--node-isolation]
  flash controller uninstall <cluster_name> [--eks]
  flash controller list backups <saas_cluster_name> [--eks]
  flash controller list restores <saas_cluster_name> [--eks]
  flash controller list tenants <saas_cluster_name> [--eks]
  flash controller logbundle <saas_cluster_name> [<namespace> --eks]

Description:
  flash controller : commands to install and configure allspark services.

Options:
  --production  Specifies large volume (500G) deployment size for production clusters
  --eks         Specifies external cluster type
"""
import sys
from docopt import docopt
from flashpkg.infra.saas import install, uninstall, list_tenants, logbundle, list_backups_or_restores

def list(args):
    if args['tenants']:
        return list_tenants(args)

    if args['backups'] or args['restores']:
        return list_backups_or_restores(args)

def dispatch():
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)

    if args['install']:
        return install(args)
    elif args['uninstall']:
        return uninstall(args)
    elif args['list']:
        return list(args)
    elif args['logbundle']:
        return logbundle(args)
