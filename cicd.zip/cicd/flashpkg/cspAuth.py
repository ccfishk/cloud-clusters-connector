from flashpkg.state import state
from flashpkg import utils


CFG = {
    'Stage': "console-stg.cloud.vmware.com",
    'Prod': "console.cloud.vmware.com"
}


def checkCspOrgID():
    if not state.is_orgid_valid():
        print('Error: CSP Org id is not set.'
              'Please set using "flash csp set orgid <org_id>"')
        return 1
    return 0


def getCspUrl():
    if not state.is_env_valid():
        return CFG['Stage']
    else:
        return CFG[state.get_csp_env()]


def getAccessToken(refreshToken, csp_host_url=None, verbose_flag=False):
    if csp_host_url is None:
        csp_host_url = getCspUrl()
    url = 'https://{}/'\
        'csp/gateway/am/api/auth/api-tokens/'\
        'authorize?refresh_token={}'.format(csp_host_url, refreshToken)
    if verbose_flag is True:
        print("csp_host_url {}".format(csp_host_url))
    resp = utils.tmc_request(url, operation='POST').json()
    return resp['access_token']
