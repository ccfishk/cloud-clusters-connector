"""
Usage:
  flash csp delete tenant <service_url> <tenant_id>
  flash csp get access token <refresh_token>
  flash csp get environment
  flash csp get client <client_name> [--deprecated]
  flash csp get tenant <service_url> <tenant_id>
  flash csp get service <csp_service_name> [--display_name --display_instances]
  flash csp get invite service <csp_service_name> [--cnt=<cnt> --instance_url=<instance_url>]
  flash csp list services [--expand --all --names --name=<service_name>]
  flash csp list tenants <service_url> [--expand --instance_url=<instance_url> --all_instances]
  flash csp patch serviceinstance <csp_service_name> <instance_url> (<orglist_json_file> | --add_orgs=<add_orgs> | --remove_orgs=<remove_orgs>)
  flash csp register service <csp_service_name> <csp_service_display_name> <service_url> <service_description>
  flash csp register service <service_definition_yaml_file>
  flash csp register serviceinstance <csp_service_name> <instance_name> <instance_url>
  flash csp register client <client_name> <csp_service_name> <client_secret> <redirect_url> [--deprecated]
  flash csp register client <client_definition_json_file> [--deprecated]
  flash csp unregister serviceinstance <csp_service_name> <instance_url>
  flash csp unregister service <csp_service_name>
  flash csp unregister client <client_name> [--deprecated]
  flash csp set environment <env_name>
  flash csp set orgid <org_id>

Description:
  flash csp : commands to interact with Common Services Platfrom.

Options:
  --cnt=<cnt>                      Number of invites to generate.
  --display_name                   Show the display name.
  --display_instances              Show the names of the instances associated with the CSP service
  --all_instances                  All instances associated with the multi-instance CSP service
  --add_orgs=<add_orgs>            Comma separated org list to associate with an instance of CSP service
  --remove_orgs=<remove_orgs>      Comma separated org list to disassociate from an instance of CSP service
  --expand                         Expand services.
  --all                            Show all services.
  --names                          Show names.
  --name=<service_name>            Show name where name is equal to <service_name>.
  --deprecated                     Use deprecated client apis
"""
from docopt import docopt
from flashpkg import cspAuth, cspClient, cspService
from flashpkg.state import state
from flashpkg.utils import validate_url
import json
import sys
import yaml


def processServiceList(arg):
    respData = cspService.getServices(
        True if arg['--expand'] or arg['--names'] or arg['--name'] else False,
        True if arg['--all'] else False)
    service_name = arg['--name']
    if arg['--names'] or service_name:
        if respData['results']:
            for itm in respData['results']:
                if not service_name or itm['name'] == service_name:
                    st = itm['documentSelfLink'] + '    ' + itm['name']
                    if 'serviceUrls' in itm and itm['serviceUrls'] and itm['serviceUrls']['serviceHome']:
                        st += '   ' + itm['serviceUrls']['serviceHome']
                    print(st)
    else:
        for itm in respData['serviceDefinitionLinks']:
            print(itm)
        if respData['results']:
            for itm in respData['results']:
                print('---')
                print(itm)
    return 0


def processServiceGet(arg):
    svcName = arg['<csp_service_name>']
    itm = cspService.getServiceByName(svcName)
    if itm:
        if arg['invite']:
            cnt = 1
            if arg.get('--cnt'):
                cnt = arg['--cnt']
            inv = cspService.getServiceInvite(svcName, cnt, arg.get('--instance_url'))
            if inv is None:
                return 1
            for itm in inv:
                print('Invitation Link: ' + itm)
        elif arg['--display_instances']:
            serviceId = itm.get('documentSelfLink').split('/')[-1]
            itm = cspService.getServiceInstances(serviceId)
            print(json.dumps(
                itm, sort_keys=True,
                indent=4, separators=(',', ': ')))
        elif arg['--display_name']:
            print(itm.get('displayName'))
        else:
            st = itm.get('documentSelfLink') + '    ' + itm.get('name')
            if 'serviceUrls' in itm and itm.get('serviceUrls') and itm.get('serviceUrls').get('serviceHome'):
                st += '   ' + itm.get('serviceUrls').get('serviceHome')
            print(st)
            print(json.dumps(
                itm, sort_keys=True,
                indent=4, separators=(',', ': ')))
        return 0


def processServiceTemplateRegister(arg):
    svcName = arg['<csp_service_name>']
    svcDisplayName = arg['<csp_service_display_name>']
    svcUrl = arg['<service_url>']
    svcDesc = arg['<service_description>']
    body = {
        "name": svcName,
        "display-name": svcDisplayName,
        "desc-long": svcName + ": " + svcDesc,
        "desc-short": svcName + ": " + svcDesc,
        "service-nav-bar-icon": None,
        "service-icon": None,
        "service-urls": {
            "service-home": svcUrl
        },
        "service-roles": [{
            "hidden": False,
            "display-name": svcName + " App admin role",
            "default": False,
            "name": svcName + ":admin"},
            {
                "hidden": False,
                "display-name": svcName + " App admin user",
                "default": True,
                "name": svcName + ":user"}
        ],
        "isFundMandatory": False,
        "subscription-status-change-notification-url": svcUrl + "/api/subscription-notifications",
        "health-check-path": "/health",
        "org-id": "/csp/gateway/am/api/orgs/" + state.get_csp_orgid(),
        "internal": False,
        "gated": True}
    body_text = yaml.dump(body, default_flow_style=False)
    link = cspService.createService(body_text)
    print('Service ' + svcName + ' is Registered with link: ' + link)
    return 0

def processService(arg):
    if cspAuth.checkCspOrgID():
        return -1
    if arg['list']:
        return processServiceList(arg)
    elif arg['get']:
        return processServiceGet(arg)
    elif arg['unregister']:
        svcName = arg['<csp_service_name>']
        cspService.deleteService(svcName)
        print('Done Deleting service ' + svcName)
        return 0
    elif arg['register'] and arg['<service_definition_yaml_file>']:
        with open(arg['<service_definition_yaml_file>'], 'rb') as fileData:
            link = cspService.createService(fileData)
        print('Service is Registered with link: ' + link)
        return 0
    elif arg['register']:
        return processServiceTemplateRegister(arg)


def processClient(arg):
    useDeprecated = arg['--deprecated']
    if arg['register'] and arg['<client_definition_json_file>']:
        with open(arg['<client_definition_json_file>'], 'rb') as fileData:
            cspClient.createClient(fileData, useDeprecated)
        print('Created client.')
    elif arg['register']:
        print('registering client with new api')
        svcName = arg['<csp_service_name>']
        clientName = arg['<client_name>']
        clientSecret = arg['<client_secret>']
        redirectUrl = arg['<redirect_url>']
        svc = cspService.getServiceByName(svcName)
        svcLink = svc['documentSelfLink']
        if useDeprecated:
            body = {
                "id": clientName,
                "secret": clientSecret,
                "redirectUris": [redirectUrl],
                "grantTypes": [
                    "client_credentials",
                    "authorization_code"
                ],
                "accessTokenTTL": 1800,
                "refreshTokenTTL": 86400,
                "resourceLink": svcLink
            }
            cspClient.createClient(json.dumps(body))
            print('Created client: ', clientName, True)
        else:
            # new client api
            splitSvcLink = svcLink.split('/')
            svcId = splitSvcLink[len(splitSvcLink) - 1]
            body = {
                "accessTokenTTL": 1800,
                "allowedScopes": {
                    "generalScopes": [],
                    "organizationScopes": {
                        "allRoles": True
                    },
                    "servicesScopes": [{
                        "allRoles": True,
                        "roleNames": [],
                        "serviceDefinitionId": svcId
                    }]
                },
                "description": "allspark web client {} with id '{}'".format(svcName, svcId),
                "displayName": "{} allspark web client {}".format(clientName, svcName),
                "grantTypes": [
                    "authorization_code",
                    "refresh_token"
                ],
                "id": clientName,
                "maxGroupsInIdToken": 10,
                "redirectUris": [
                    # ex "https://sm-csp.servicemesh.biz/v0/cspauth/callback"
                    redirectUrl
                ],
                "refreshTokenTTL": 86400,
                "secret": clientSecret
            }
            print(body)
            cspClient.createClient(json.dumps(body))
            print('Created client: ', clientName)

    elif arg['unregister']:
        clientName = arg['<client_name>']
        cspClient.deleteClient(clientName, useDeprecated)
        print('Deleted Client: ' + clientName)
    elif arg['get']:
        clientName = arg['<client_name>']
        jdt = cspClient.getClient(clientName, useDeprecated)
        print(json.dumps(
            jdt, sort_keys=True,
            indent=4, separators=(',', ': ')))
    return 0


def processEnvironment(args):
    if args['set']:
        if args['<env_name>'] not in ['Stage', 'Prod']:
            raise Exception('Unknown environment {}. Must be either "Prod" or "Stage"'.format(args['<env_name>']))
        print('Set environment to ' + args['<env_name>'])
        state.set_csp_env(args['<env_name>'])
        return 0
    elif args['get']:
        if not state.is_env_valid():
            print("CSP Environment not set. Will default to Stage")
        else:
            print(state.get_csp_env())
        return 0


def processCspTenants(args):
    service_url = args['<service_url>']
    service_url_hostname = validate_url(service_url).netloc
    tenant_id = args.get('<tenant_id>')
    if args['get']:
        return cspService.listTenants(service_url_hostname, True, tenant_id)
    if args['list']:
        if args['--instance_url']:
            instance_url = args['--instance_url']
            validate_url(instance_url)
            service_id = cspService.getServiceByUrl(service_url).get('documentSelfLink').split('/')[-1]
            instance_id = cspService.getInstanceByUrl(service_id, instance_url).get('id')
            cspService.listTenantsByInstanceId(service_id, instance_id)
        elif args['--all_instances']:
            service_id = cspService.getServiceByUrl(service_url).get('documentSelfLink').split('/')[-1]
            cspService.listTenantsAllInstances(service_id)
        else:
            cspService.listTenants(service_url_hostname, args['--expand'], tenant_id)
        return 0
    if args['delete']:
        cspService.deleteTenant(service_url_hostname, tenant_id)
        return 0
    print("Unknown CSP Tenant operation")
    return 1


def processCspServiceInstance(args):
    instance_url = args['<instance_url>']
    validate_url(instance_url)
    service_id = cspService.getServiceByName(args.get('<csp_service_name>')).get('documentSelfLink').split('/')[-1]
    if args['register']:
        display_name = instance_url
        body = {
            "url": instance_url,
            "displayName": display_name
        }
        instance_def = json.dumps(body)
        instance_id = cspService.createServiceInstance(service_id, instance_def)
        print("Instance with ID {} added to service {}".format(instance_id, service_id))
        return 0
    elif args['patch']:
        instance_id = cspService.getInstanceByUrl(service_id, instance_url).get('id')
        if args['<orglist_json_file>']:
            with open(args['<orglist_json_file>'], 'rb') as orglist:
                cspService.patchTenantsOnInstance(service_id, instance_id, orglist)
        else:
            body = {}
            if args['--add_orgs']:
                body["orgIdsToAdd"] = args['--add_orgs'].split(',')
            elif args['--remove_orgs']:
                body["orgIdsToRemove"] = args['--remove_orgs'].split(',')
            orglist = json.dumps(body)
            cspService.patchTenantsOnInstance(service_id, instance_id, orglist)
        return 0
    elif args['unregister']:
        instance_id = cspService.getInstanceByUrl(service_id, instance_url).get('id')
        cspService.deleteServiceInstance(service_id, instance_id)
        return 0


def process():
    try:
        # If no matching sub commands are specified then make sure we show the full help output.
        if len(sys.argv) == 2:
            sys.argv.append('-h')

        args = docopt(__doc__)
        if args['set'] and args['orgid']:
            print('set orgid ' + args['<org_id>'])
            state.set_csp_orgid(args['<org_id>'])
            print('Updated to orgid:' + args['<org_id>'])
            return 0
        if args['get'] and args['access'] and args['token']:
            token = cspAuth.getAccessToken(args['<refresh_token>'])
            state.set_csp_access_token(token)
            print('Update access token in state file to ' + token)
            return 0
        if args['tenant'] or args['tenants']:
            return processCspTenants(args)
        if args['service'] or args['services']:
            return processService(args)
        if args['serviceinstance']:
            return processCspServiceInstance(args)
        if args['client']:
            return processClient(args)
        if args['environment']:
            return processEnvironment(args)
    except Exception as err:
        print(err)
        return 1
