from configobj import ConfigObj
import flashpkg
import json
import os

VERSION = "version"
FLASH = "flash"
CLOUD_BUILD = "cloud_build"
INFRA = "infrastructure"
FLAVORS = "flavors"
TESTBEDS = "testbeds"
CLOUD_ZONE = "cloud_zone"
CLOUD_REGION = "cloud_region"
CI_BUILD = "ci_build"
ALLSPARK_CLOUD = "allspark_cloud"
ARN = "arn"
IMAGE_TYPE = "image_type"
CLUSTER = "cluster"
REPO = "repo"
CONTAINER = "container"
MEMORY = "memory"
NETWORK = "network"
STARTUP_WAIT_TIME = "startup_wait_time"
CI_BASE_PATH = "ci_base_path"
VM_USER_ID = "vm_userid"
SSH_PEM_PATH = "ssh_pem_path"
TMC_URL = 'tmc_url'

class Config(object):

    def __init__(self):
        cfg_file = self.get_file()
        cfg = ConfigObj(cfg_file, encoding='UTF8', file_error=True)
        cfg_version = cfg.get("version")
        supported_version = self.get_default_file_version()
        if not cfg_version:
            print("WARNING::Configuration is missing version information, Please update it to match:", cfg_file)
        if cfg_version != supported_version:
            print("WARNING::Configuration version {}:{} does not match {}:{}".format(
                cfg_version, cfg_file,
                supported_version, Config.get_default_file()
            ))

        self.config = cfg

    def __get_flash_section(self):
        return self.config[FLASH]

    def __get_cloudbuild_section(self):
        return self.__get_flash_section().get(CLOUD_BUILD)

    def __get_container_section(self):
        return self.__get_flash_section().get(CONTAINER)

    def __get_infrastructure_section(self):
        return self.__get_flash_section().get(INFRA)

    def __get_flavors_section(self):
        return self.__get_infrastructure_section().get(FLAVORS)

    def __get_testbeds_section(self):
        return self.__get_infrastructure_section().get(TESTBEDS)

    def get_cloud_zone(self):
        return self.__get_flash_section().get(CLOUD_ZONE)

    def get_cloud_region(self):
        return self.__get_flash_section().get(CLOUD_REGION)

    def get_ci_build(self):
        return self.__get_flash_section().get(CI_BUILD)

    def get_allspark_cloud(self):
        return self.__get_flash_section().get(ALLSPARK_CLOUD)

    def get_arn(self):
        return self.__get_cloudbuild_section().get(ARN)

    def get_image_type(self):
        return self.__get_cloudbuild_section().get(IMAGE_TYPE)

    def get_cluster(self):
        return self.__get_flash_section().get(CLUSTER)

    def get_repo(self):
        return self.__get_flash_section().get(REPO)

    def get_memory(self):
        return self.__get_container_section().get(MEMORY)

    def get_network(self):
        return self.__get_container_section().get(NETWORK)

    def get_startup_wait_time(self):
        return self.__get_container_section().get(STARTUP_WAIT_TIME)

    def get_ci_base_path(self):
        return self.__get_flash_section().get(CI_BASE_PATH)

    def get_vm_user_id(self):
        return self.__get_container_section().get(VM_USER_ID)

    def get_ssh_pem_path(self):
        return self.__get_flash_section().get(SSH_PEM_PATH)

    def get_version(self):
        return self.config[VERSION]

    def get_tmc_url(self):
        return self.__get_flash_section().get(TMC_URL)

    @staticmethod
    def get_default_file():
        return os.path.dirname(flashpkg.__file__) + "/.flash.conf"

    def get_file(self):
        cfg_file = ''
        try:
            # First priority is to pick up the config file pointed by the
            # env variable.
            cfg_file = os.environ['ALLSPARK_FLASH_CONFIG']
        except Exception:
            pass
        if cfg_file is None or cfg_file == '':
            # Check if there is a .flash in home directory before using the one
            # that is packaged with release
            cfile = "/.flash.conf"
            home_cfg_file = os.environ['HOME'] + cfile
            if os.path.exists(home_cfg_file):
                cfg_file = home_cfg_file
            else:
                cfg_file = Config.get_default_file()
        return cfg_file

    def get_default_file_version(self):
        def_parsed = ConfigObj(Config.get_default_file())
        return def_parsed.get("version")

    def get_flavor(self, flavor_name):
        flavors = self.__get_flavors_section()
        for f in flavors:
            if f == flavor_name:
                return json.loads(flavors[f])

        return None

    def get_testbed(self, testbed_name):
        testbeds = self.__get_testbeds_section()
        for t in testbeds:
            if t == testbed_name:
                return json.loads(testbeds[t])

        return None

    def get_flavors(self):
        flavors = self.__get_flavors_section()
        for flavor in flavors:
            yield flavor

    def get_testbeds(self):
        testbeds = self.__get_testbeds_section()
        for testbed in testbeds:
            yield testbed


config = Config()
