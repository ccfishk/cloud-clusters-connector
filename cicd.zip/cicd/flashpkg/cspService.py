from flashpkg import cspAuth
from flashpkg.state import state
import http.client
import json
import urllib.parse
from flashpkg.utils import validate_url


def getServices(expand=False, all=False):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    p = {}
    if expand:
        p['expand'] = 'true'
    if not all:
        p['orgLink'] = state.get_csp_orgid()
    params = urllib.parse.urlencode(p)
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json"
    }
    conn.request(
        "GET", '/csp/gateway/slc/api/definitions?' + params,
        headers=headers)
    resp = conn.getresponse()

    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception(resp.status)
    dt = resp.read().decode('utf-8')
    return json.loads(dt)

def getServiceInstances(serviceId):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json"
    }
    conn.request(
        "GET", '/csp/gateway/slc/api/definitions/external/'+serviceId+'/service-instances',
        headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception(resp.status)
    dt = resp.read().decode('utf-8')
    return json.loads(dt)

def getInstanceByUrl(serviceId, instanceUrl):
    validate_url(instanceUrl)
    instances = getServiceInstances(serviceId).get('results')
    instance_obj = None
    for instance in instances:
        if instance.get('url') == instanceUrl:
            instance_obj = instance
    if not instance_obj:
        raise Exception('Instance with url {} not found in service {}.'.format(instanceUrl, serviceId))
    return instance_obj

def listTenantsByInstanceId(serviceId, instanceId):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json"
    }
    conn.request(
        "GET", '/csp/gateway/slc/api/definitions/external/' + serviceId + '/service-instances/' + instanceId + '/orgs',
        headers=headers)
    resp = conn.getresponse()

    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception(resp.status)
    dt = resp.read().decode('utf-8')
    tenants = json.loads(dt)
    print(json.dumps(
        tenants, sort_keys=True,
        indent=4, separators=(',', ': ')))

def listTenantsAllInstances(serviceId):
    instances = getServiceInstances(serviceId).get('results')
    if not instances:
        raise Exception('No instance found for service {}. Try command without --all_instances '.format(serviceId))
    for instance in instances:
        instanceUrl = instance.get('url')
        instanceId = instance.get('id')
        print("Tenants for instance {} in service {}".format(instanceUrl, serviceId))
        listTenantsByInstanceId(serviceId, instanceId)

def getServiceByUrl(serviceUrl):
    respData = getServices(True)
    service = None
    for itm in respData.get('results'):
        if itm.get('serviceUrls').get('serviceHome') == serviceUrl:
            service = itm
    if not service:
        raise Exception('Service with url {} not found.'.format(serviceUrl))
    return service


def getServiceByName(svcName):
    respData = getServices(True)
    service = None
    for itm in respData.get('results'):
        if itm.get('name') == svcName:
            service = itm
    if not service:
        raise Exception('Service ' + svcName + 'not found.')
    return service


def deleteService(svcName):
    svc = getServiceByName(svcName)
    if svc.get('documentSelfLink'):
        svcId = svc['documentSelfLink'].split('/')[-1]
        conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
        headers = {
            "Accept": "application/json",
            "csp-auth-token": state.get_csp_access_token()
        }
        conn.request(
            'DELETE', '/csp/gateway/slc/api/definitions/external/' + svcId,
            headers=headers)
        resp = conn.getresponse()
        if resp.status != 200:
            print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
            print("RESP DATA : " + str(resp.read()))
            raise Exception('Could not Delete Service ' + svcName + '.')


def getServiceInvite(svcName, cnt, instanceUrl=None):
    svc = getServiceByName(svcName)
    svcLink = svc.get('documentSelfLink')
    if svcLink:
        serviceId = svcLink.split('/')[-1]
        instances = getServiceInstances(serviceId)
        if instances.get('totalResults') != 0 and instanceUrl is None:
            print("Service - {} is a multi-instance service, specify an instance url from the below list to generate invite".format(svcName))
            print([result['url'] for result in instances.get('results')])
            raise Exception("Instance url is required to generate invite for a multi-instance service.")
        conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
        headers = {
            "Accept": "application/json",
            "csp-auth-token": state.get_csp_access_token(),
            "Content-type": "application/json"
        }
        body = {
            "serviceDefinitionLink": svcLink,
            "numberOfInvitationsToGenerate": cnt,
            "isFundMandatory": False
        }
        if instanceUrl:
            serviceId = svcLink.split('/')[-1]
            instance = getInstanceByUrl(serviceId, instanceUrl)
            if instance is not None:
                body["targetInstanceUrl"] = instanceUrl
        conn.request(
            'POST', '/csp/gateway/slc/api/service-invitations',
            body=json.dumps(body),
            headers=headers)
        resp = conn.getresponse()
        if resp.status != 200:
            print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
            print("RESP DATA : " + str(resp.read()))
            raise Exception('Could not Create Invite for Service ' + svcName + '.')
        dt = resp.read().decode('utf-8')
        jdt = json.loads(dt)
        return jdt['refLinks']


def grantServiceAccess(svcName, orgId):
    svc = getServiceByName(svcName)
    if svc.get('documentSelfLink'):
        svcId = svc['documentSelfLink'].split('/')[-1]
        conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
        headers = {
            "Accept": "application/json",
            "csp-auth-token": state.get_csp_access_token(),
            "Content-type": "application/json"
        }
        body = {
            "serviceDefinitionId": svcId,
            "isTosPreSigned": True,
            "orgId": orgId,
        }
        conn.request(
            'POST', '/csp/gateway/slc/api/service-access',
            body=json.dumps(body),
            headers=headers)
        resp = conn.getresponse()
        if resp.status != 200:
            print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
            print("RESP DATA : " + str(resp.read()))
            raise Exception('Could not grant ' + orgId + ' access to service ' + svcName + '.')


def createService(svcDef):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "text/plain"
    }
    conn.request(
        'POST', '/csp/gateway/slc/api/definitions',
        body=svcDef,
        headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not Create Service with data:' + svcDef)
    dt = resp.read().decode('utf-8')
    jdt = json.loads(dt)
    return jdt['refLink']


def createServiceInstance(serviceId, instanceDef):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "application/json"
    }
    conn.request(
        'POST', '/csp/gateway/slc/api/definitions/external/' + serviceId + '/service-instances',
        body=instanceDef,
        headers=headers)
    resp = conn.getresponse()
    if resp.status <= 200 or resp.status >= 299:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not create service instance with data:' + instanceDef)
    dt = resp.read().decode('utf-8')
    jdt = json.loads(dt)
    return jdt.get('id')


def deleteServiceInstance(serviceId, instanceId):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "application/json"
    }
    conn.request(
        'DELETE', '/csp/gateway/slc/api/definitions/external/' + serviceId + '/service-instances/' + instanceId,
        headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not delete instance {} in service {}'.format(instanceId, serviceId))
    print("Instance {} deleted from service {}".format(instanceId, serviceId))


def patchTenantsOnInstance(serviceId, instanceId, orglist_json):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "application/json"
    }
    conn.request(
        'POST', '/csp/gateway/slc/api/definitions/external/' + serviceId + '/service-instances/' + instanceId + '/orgs',
        body=orglist_json,
        headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not patch orgs to instance:' + instanceId)
    print("Orgs successfully patched in instance {} of service {}".format(instanceId, serviceId))


def listTenants(service_url_hostname, expand, tenant_id):
    conn = http.client.HTTPSConnection(service_url_hostname)
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    if tenant_id:
        conn.request("GET", "/v0/csp-tenants/{}".format(tenant_id), headers=headers)
    else:
        conn.request("GET", "/v0/csp-tenants", headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception(resp.status)
    dt = json.loads(resp.read().decode('utf-8'))
    if tenant_id or expand:
        print(dt)
    else:
        for item in dt:
            print(item['tenantID'])


def deleteTenant(service_url_hostname, tenant_id):
    conn = http.client.HTTPSConnection(service_url_hostname)
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    conn.request("DELETE", "/v0/csp-tenants/{}".format(tenant_id), headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception(resp.status)
    print(json.loads(resp.read().decode('utf-8')))
