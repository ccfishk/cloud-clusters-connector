from os import path, getcwd, walk, makedirs, environ
from flashpkg.config import config
from datetime import date, datetime, timedelta
from jinja2 import Template, TemplateError, TemplateSyntaxError
from botocore.config import Config as aws_config
import json
import subprocess
import sys
import shlex
import flashpkg
import tarfile
import io
import paramiko
import hashlib
import base64
from base64 import b64encode
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from urllib.parse import urlparse
import requests
from requests.exceptions import HTTPError
from requests.exceptions import ReadTimeout
import re
import time
from flashpkg import cspAuth
from flashpkg.state import state


KOPS = "kops"
EKS = "eks"
CID = "cid"
ADD = "add"
DELETE = "delete"
EKS_CLUSTER_TAG = "tag:alpha.eksctl.io/cluster-name"
KOPS_CLUSTER_TAG = "tag:KubernetesCluster"
OPERATOR_NAMESPACE = 'allspark'
ISTIO_NAMESPACE = 'istio-system'
TIMEOUT_3_MINUTES = 3 * 60
VELERO = 'velero'
IGNORE_NAMESPACES = ['default', 'kube-system',
                     'kube-public', 'velero',
                     'wavefront-collector']
AWS_CONFIG = aws_config(retries={'max_attempts': 10})
AGENT_NAMESPACE = 'vmware-system-tsm'


def script_dir():
    return path.dirname(path.realpath(__file__))


def current_dir():
    return getcwd()


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError("Type %s not serializable" % type(obj))


def json_dumps(j):
    return json.dumps(j, default=json_serial)


def command(cmd, supress_error=False, streaming=False, shell=False, lex=True, env=False, no_output=False):
    envs = {**environ, **env} if env else {**environ}

    if not streaming:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE,
                                   shell=shell, bufsize=-1,
                                   universal_newlines=True, env=envs)
        out, error = process.communicate()
        (status, out) = process.returncode, out
        if not supress_error:
            if (status != 0):
                raise Exception(
                    ("Got error code [%s] and response [%s]\n while trying "
                     "to run command %s") % (status, out, cmd))
        return (status, out)
    else:
        if lex:
            cmd = shlex.split(cmd)

        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=shell,
            bufsize=-1, universal_newlines=True, env=envs)

        if not no_output:
            stdout = io.TextIOWrapper(process.stdout.buffer, encoding='utf-8', errors='backslashreplace')
            for line in stdout:
                sys.stdout.write(line.encode('utf-8', 'ignore').decode('utf-8'))
                sys.stdout.flush()
            stdout.close()

        rc = process.wait()
        err = ''
        return rc, err


def ci_key():
    return path.dirname(flashpkg.__file__) + config.get_ssh_pem_path()


def archive_dir(source_dir, output_name):
    with tarfile.open(output_name, "w:gz") as tar:
        tar.add(source_dir, arcname=path.basename(source_dir))


def extract_archive(file):
    with tarfile.open(file) as tar:
        tar.extractall()


def replace_config_parameter(template_dir, source, update):
    print("Parsing template directory: {}".format(template_dir))
    for root, directories, filenames in walk(path.expanduser(template_dir)):
        for filename in filenames:
            try:
                file_path = path.join(root, filename)
                with open(file_path) as f:
                    new = f.read().replace(source, update)
                with open(file_path, 'w') as f:
                    f.write(new)
            except (FileNotFoundError, PermissionError) as err:
                print("Failed to update config parameter. \n {}".format(err))
                return 1
    return 0


def apply_template(runtime_conf, template_dir=None, template_file=None,
                   output_dir=None, start_delim='{{.', end_delim='}}'):
    if template_dir:
        print("Parsing template directory: {}".format(template_dir))
        for root, directories, filenames in walk(path.expanduser(template_dir)):
            for filename in filenames:
                print(filename)
                file_path = path.join(root, filename)
                try:
                    __parse_template(runtime_conf, file_path, output_dir, start_delim, end_delim)
                except (FileNotFoundError, PermissionError, TemplateSyntaxError) as err:
                    print("Write to yaml file failed. \n {}".format(err))
                    return 1
                except TemplateError as e:
                    print("Unable to render yaml file from the template. {}".format(e))
                    return 1
    else:
        try:
            __parse_template(runtime_conf, path.expanduser(template_file), output_dir, start_delim, end_delim)
        except (FileNotFoundError, PermissionError, TemplateSyntaxError) as err:
            print("Write to yaml file failed. \n {}".format(err))
            return 1
        except TemplateError as e:
            print("Unable to render yaml file from the template. {}".format(e))
            return 1
    return 0


def __parse_template(runtime_conf, filename, output_dir, start_delim, end_delim):
    with open(filename, 'r+', encoding="utf-8") as f:
        template = Template(f.read(), variable_start_string=start_delim, variable_end_string=end_delim)
        print("Applying runtime config for file: {}".format(filename))
        updated_conf = template.render(runtime_conf)

        # Save updated configuration to the same file if an output directory wasn't specified.
        selected_out = None
        if not output_dir:
            selected_out = filename
            f.seek(0)
            f.truncate()
            f.write(updated_conf)
        else:
            out_path = path.join(output_dir, path.basename(filename))
            makedirs(output_dir, exist_ok=True)
            selected_out = out_path
            with open(out_path, "w") as out_file:
                out_file.write(updated_conf)

        print("The runtime config has been applied successfully to {}".format(selected_out))

def generate_self_signed_cert(hostname):
    # Generate our key
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )

    name = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, hostname)
    ])
    # path_len=0 means this cert can only sign itself, not other certs.
    basic_contraints = x509.BasicConstraints(ca=True, path_length=0)
    now = datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=365))
        .add_extension(basic_contraints, False)
        .sign(key, hashes.SHA256(), default_backend())
    )
    cert_pem = cert.public_bytes(encoding=serialization.Encoding.PEM)
    key_pem = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return b64encode(key_pem), b64encode(cert_pem)

def ssh_setup(host, username, password):
    '''Setup SSH connection to the host'''
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=username, password=password, timeout=30)
    return client

def get_cluster_hash(cluster_name):
    m = hashlib.sha256(cluster_name.encode('utf-8'))
    b32 = base64.b32encode(m.digest())
    as_hash = b32.lower()[:8]
    return as_hash.decode('utf-8')


def validate_url(url):
    url_result = urlparse(url)
    if not all([url_result.scheme, url_result.netloc]):
        print("Input instance_url: {} is invalid.".format(url))
        raise ValueError("Invalid URL. Please provide a valid url. e.g: https://foobar.com")
    return url_result


def tmc_request(url, data=None, operation='', csp_url=None,
                headers=None,
                status_code=[200], is_json=True,
                status_code_exception=True, timeout=300,
                ignore_error=False, verbose_flag=False):
    if len(operation) == 0:
        raise Exception('Operation could not be empty.')
    if verbose_flag:
        print('URL: %s' % url)
    if not headers:
        headers = {}
    if is_json and data:
        if verbose_flag:
            print('JSON post')
        data = json.dumps(data)
        if 'Content-Type' not in headers:
            headers['Content-Type'] = 'application/json'
    if verbose_flag:
        print('Data: %s' % str(data))
        print('Headers: %s' % str(headers))
    i = 0
    while True:
        try:
            if operation == 'POST':
                if not data:
                    req = requests.post(url, verify=True,
                                        headers=headers,
                                        timeout=timeout)
                else:
                    req = requests.post(url, data=data, verify=True,
                                        headers=headers,
                                        timeout=timeout)
            elif operation == 'GET':
                req = requests.get(url, verify=True, headers=headers,
                                   timeout=timeout)
            elif operation == 'DELETE':
                if not data:
                    req = requests.delete(url, verify=True,
                                          headers=headers,
                                          timeout=timeout)
                else:
                    req = requests.delete(url, data=data, verify=True,
                                          headers=headers,
                                          timeout=timeout)
            else:
                raise Exception('unsupported {}'.format(operation))
            if verbose_flag:
                print('{} {}'.format(req.text, req.status_code))
            if req.status_code == 401:
                refresh_token = state.get_tmc_refresh_token()
                access_token = cspAuth.getAccessToken(refresh_token,
                                                      csp_host_url=csp_url,
                                                      verbose_flag=verbose_flag)
                state.set_tmc_access_token(access_token)
                if 'authorization' in headers:
                    token = 'Bearer {}'.format(access_token)
                    headers['authorization'] = token
                if 'csp-auth-token' in headers:
                    headers['csp-auth-token'] = '{}'.format(access_token)
                continue
            if status_code_exception and req.status_code not in status_code:
                if status_code_exception and (500 <= req.status_code < 600):
                    req.raise_for_status()
            break
        except requests.exceptions.SSLError:
            raise
        except (requests.ConnectionError, ReadTimeout,
                requests.TooManyRedirects, requests.Timeout,
                HTTPError) as ex:
            if ignore_error:
                return
            i += 1
            if i >= 4:
                raise
            print(ex)
            pass
    else:
        raise AssertionError('{} request failed'.format(operation))
    if verbose_flag:
        print('Reason: %s' % req.reason)
        print('Status code: %s' % req.status_code)
    if status_code_exception and req.status_code not in status_code:
        if verbose_flag:
            print('Text: %s' % req.text)
        raise AssertionError('Reason %s Text: %s' % (req.reason, req.text))
    return req


def split_url(url, verbose_flag=False):
    if verbose_flag:
        print(url)
    url_match = re.search("^(https?|ftps?|file?)://(.+?)(/.*)$", url)
    protocol = url_match.group(1)
    host_port = url_match.group(2)
    req_str = url_match.group(3)
    if verbose_flag:
        print('%s - %s - %s' % (protocol, host_port, req_str))
    return protocol, host_port, req_str


def is_host_reachable(host, timeout=60, ping_count=4,
                      ping_timeout=100,
                      verbose_flag=False):
    if not host or host == 'None':
        return False
    elapsed_time = 0
    start_time = time.time()
    while elapsed_time < timeout:
        if ping_device(host, ping_count, ping_timeout, verbose_flag=verbose_flag):
            print("Host %s is reachable." % host)
            return True
        elapsed_time = time.time() - start_time
        msg = "Host %s is unreachable in %s seconds, sleep additional"
        msg += " 10 seconds"
        print(msg % (host, int(elapsed_time)))
        time.sleep(10)
    return False


def ping_device(self, host, ping_count=4, timeout=100, verbose_flag=False):
    if verbose_flag:
        print('Hostname: %s' % host)
    if not host or host == 'None':
        return False
    ping_response = subprocess.Popen(
        ["/bin/ping", "-c%d" % ping_count, "-w%d" % timeout, host],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.read()
    ping_response = ping_response.decode('utf-8')
    if verbose_flag:
        print("Ping response is %s" % ping_response)
    if ping_response.find(' 0% packet loss') > 0:
        if verbose_flag:
            print("Host %s is reachable" % host)
        return True
    else:
        if verbose_flag:
            print("Host %s is not reachable" % host)
        return False
