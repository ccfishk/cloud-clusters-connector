import json

def log(output_format):
    def echo(text):
        if not output_format:
            print(text)
    return echo

def log_error(output_format):
    def echo(message):
        if output_format == 'json':
            response = json.dumps({"error": {"message": message}})
            print(response)
        else:
            print(message)

    return echo

def log_result(logging_format):
    def echo(data):
        if logging_format == 'json':
            response = json.dumps({"data": data})
            print(response)
    return echo
