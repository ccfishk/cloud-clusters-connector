import os
import json
import time
import boto3
import tempfile
import re
from flashpkg import utils, logging
from flashpkg.config import config
from flashpkg.aws import container


ADDITIONAL_POLICIES = "additionalPolicies.yaml"
S3_BUCKET_NAME_PATTERN = re.compile(r"(?=^.{3,63}$)(?!^(\d+\.)+\d+$)(^(([a-z0-9]|[a-z0-9][a-z0-9\-]*[a-z0-9])\.)*([a-z0-9]|[a-z0-9][a-z0-9\-]*[a-z0-9])$)")

def start(*args, **kwargs):
    cloud = kwargs.get("cloud")
    k8s_version = kwargs.get("version")
    logging_format = kwargs.get("logging_format")

    if not k8s_version:
        k8s_version = version()

    if cloud:
        return __cloud_start(*args, version=k8s_version)

    return __local_start(*args, version=k8s_version, logging_format=logging_format)


def cleanup(*args, **kwargs):
    cloud = kwargs.get("cloud")
    if cloud:
        return __cloud_cleanup(*args)

    return __local_cleanup(*args)


def status(*args, **kwargs):
    cloud = kwargs.get("cloud")

    if cloud:
        return __cloud_status(*args)

    return __local_status(*args)

def __local_status(name, logging_format):
    env = {'KOPS_STATE_STORE': f's3://{name}-kops-state-store'}
    cmd = "kops validate cluster --name=%s" % (name + ".k8s.local")
    (r, error) = utils.command(cmd, streaming=True, env=env, no_output=bool(logging_format))
    return r

def type(name):
    os.environ["KOPS_STATE_STORE"] = "s3://%s-kops-state-store" % name
    cluster_name = name + ".k8s.local"
    cmd = ["kops", "get", cluster_name, "-o", "json"]
    (status, out) = utils.command(cmd)
    if status != 0:
        raise Exception("Unable to get cluster {}".format(name))
    for item in json.loads(out):
        if item["kind"] == "Cluster":
            if "kubenet" in item["spec"]["networking"]:
                return "kubenet"
            elif "calico" in item["spec"]["networking"]:
                return "calico"
            break
    raise Exception("Unknown networking type for kops cluster {}".format(name))


def envsetup(*args, **kwargs):
    cloud = kwargs.get("cloud")
    if cloud:
        return __cloud_envsetup(*args)

    return __local_envsetup(*args)


def version():
    (status, out) = utils.command(["kops", "version"])
    parts = out.split()
    return parts[1]


def __local_upsert_s3_bucket(s3bucket, region):
    s3 = boto3.resource('s3', region_name=region)
    if not s3.Bucket(s3bucket) in s3.buckets.all():
        bucket = s3.Bucket(s3bucket)
        # LocationContraint specifies the region where the bucket will be created.
        # If you are creating a bucket on the US East (N. Virginia) region (us-east-1),
        # you do not need to specify the location constraint.
        # @ https://docs.aws.amazon.com/AmazonS3/latest/API/RESTBucketPUT.html
        if region == 'us-east-1':
            # LocationContraint is not supported in us-east-1
            bucket.create()
        else:
            bucket.create(CreateBucketConfiguration={'LocationConstraint': region})

def __local_start(name, region, zones, instance_type, worker_cnt, auth_mode, networking,
                  multi_master, iam_role, version=version(), logging_format=False):

    log = logging.log(logging_format)
    log_error = logging.log_error(logging_format)

    log("----------------------------------------------------------------------------------------")
    log("Starting cluster in {}, {} with name {}, instance {}, workers {}, auth {}, networking {}, version {}, multi-master {}, iam_roles {}".format(
        region,
        zones,
        name,
        instance_type,
        worker_cnt,
        auth_mode,
        networking,
        version,
        multi_master,
        iam_role
    ))
    log("This can take up to 10 minutes to complete")
    log("----------------------------------------------------------------------------------------")

    kopsuser = '%s-kops' % name
    s3bucket = '%s-kops-state-store' % name
    if S3_BUCKET_NAME_PATTERN.search(s3bucket) is None:
        raise ValueError("Bucket {} does not follow naming requirements: https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html".format(s3bucket))

    clustername = '%s.k8s.local' % name
    override = "spec.kubelet.authorizationMode=Webhook,spec.kubelet.authenticationTokenWebhook=true"
    iam = boto3.resource('iam')
    if not iam.User(kopsuser) in iam.users.all():
        client = boto3.client('iam', region_name=region)
        user = iam.User(kopsuser)
        user.create()
        client.add_user_to_group(GroupName='kops', UserName=kopsuser)
        # the kops-credential is not used so will skip it for now
    # Although not required, we also move the kops_state_store based on the region
    __local_upsert_s3_bucket(s3bucket, region)
    sts_client = boto3.client('sts')
    launch_user = sts_client.get_caller_identity()['Arn'].split('/')[1]
    os.environ["KOPS_STATE_STORE"] = "s3://%s" % s3bucket
    os.environ["KOPS_FEATURE_FLAGS"] = "SpecOverrideFlag"
    cmd = ("kops create cluster --node-count=%s --node-size=%s "
           "--master-size=%s --zones %s %s --authorization=%s --yes "
           "--kubernetes-version %s --networking=%s --override=%s "
           "--cloud-labels=\"FlashUser=%s\"") % (
        worker_cnt, instance_type, instance_type, zones, clustername, auth_mode,
        version, networking, override, launch_user)
    if multi_master:
        ec2_client = boto3.client('ec2', region_name=region)
        azs = ec2_client.describe_availability_zones()
        if len(azs['AvailabilityZones']) >= 3:
            master_zones = None
            for az in azs['AvailabilityZones'][:3]:
                if not master_zones:
                    master_zones = az['ZoneName']
                else:
                    master_zones = master_zones + ',' + az['ZoneName']
            cmd = cmd + " --master-zones {}".format(master_zones)
        else:
            # For Regions with less than 2 AZs all masters have to be deployed in a single AZ
            master_zones = azs['AvailabilityZones'][0]['ZoneName']
            cmd = cmd + " --master-count=3"

    (r, out) = utils.command(cmd, streaming=True, no_output=bool(logging_format))

    if (r != 0):
        log_error("Error when deploying KOPS")
        return r
    cnt = 0

    while(True):
        r = status(name, logging_format)
        if (r == 0):
            break
        if (cnt > 60):
            return 1
        time.sleep(10)
        cnt += 1
    # kops_label_nodes ${NODE_COUNT}
    for id in range(0, int(worker_cnt)):
        if (id == 0):
            label = 'tester'
        else:
            label = 'app'
        cmd = ("kubectl --context %s label nodes "
               "`kubectl --context %s get nodes -l "
               "kubernetes.io/role=node -o "
               "jsonpath={.items[%s].metadata.name}` "
               "servicemesh=%s --overwrite") % (
            clustername, clustername, id, label)
        log('RUNNING:%s' % cmd)
        r = os.system(cmd)
        if (r != 0):
            log_error(f"Error when adding label to node {id} : {cmd}")
            return r

    return addons(clustername, iam_role, logging_format)


def __local_cleanup(name, region):
    kopsuser = '%s-kops' % name
    s3bucket = '%s-kops-state-store' % name
    clustername = '%s.k8s.local' % name
    client = boto3.client('iam')
    resp = client.list_users()
    iam = boto3.resource('iam')
    os.environ["KOPS_STATE_STORE"] = "s3://%s" % s3bucket
    (status, out) = utils.command(["kops", "delete", "cluster", "--name",
                                   clustername, "--region", region, "--yes"],
                                  streaming=True, lex=False)
    if status != 0:
        print("Failed to delete cluster {} in region {}".format(clustername, region))
        return status

    if iam.User(kopsuser) in iam.users.all():
        print("Deleting User %s" % kopsuser)
        user = iam.User(kopsuser)
        resp = client.remove_user_from_group(
            UserName=kopsuser, GroupName='kops')
        resp = client.list_access_keys(UserName=kopsuser)
        for md in resp['AccessKeyMetadata']:
            client.delete_access_key(
                UserName=kopsuser, AccessKeyId=md['AccessKeyId'])
        user.delete()
    s3 = boto3.resource('s3', region_name=region)
    if s3.Bucket(s3bucket) in s3.buckets.all():
        print("Deleting s3bucket %s" % s3bucket)
        bucket = s3.Bucket(s3bucket)
        bucket.objects.all().delete()
        bucket.delete()

    ec2 = boto3.resource('ec2', region_name=region)
    volumes = ec2.volumes.filter(Filters=[{
        'Name': 'status',
        'Values': ['available']
    }])
    for volume in volumes or []:
        for tag in volume.tags or []:
            if tag["Key"] == "KubernetesCluster":
                volume_cluster = tag["Value"]
                if clustername == volume_cluster:
                    print("Cleaning up EC2 volume {}".format(volume_cluster))
                    volume.delete()

    return 0


def __cloud_envsetup(name):
    raise Exception("Not implemented")


def __local_envsetup(name):
    s3bucket = "%s-kops-state-store" % name
    clustername = "%s.k8s.local" % name
    os.environ['KOPS_STATE_STORE'] = "s3://%s" % s3bucket
    return os.system("kops export kubecfg --name %s" % clustername)


def __cloud_status(name):
    try:
        flash_config = os.environ['ALLSPARK_FLASH_CONFIG']
        dst = "/tmp/%s.cicd.cfg" % name
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG=%s flash "
                                    "kops status %s") % (dst, name))
    except Exception:
        return container.run(name, "flash kops status %s" % name)

def __cloud_start(name, instance_type, worker_cnt, auth_mode,
                  networking, version=version()):
    try:
        flash_config = os.environ['ALLSPARK_FLASH_CONFIG']
        dst = "/tmp/%s.cicd.cfg" % name
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG=%s flash "
                                    "kops start %s --instance=%s "
                                    "--worker=%s --authorization=%s "
                                    "--kubernetes-version %s "
                                    "--networking %s") % (
                                        dst,
                                        name,
                                        instance_type,
                                        worker_cnt,
                                        auth_mode,
                                        version,
                                        networking), False)
    except Exception:
        return container.run(name, ("flash kops start %s --instance=%s "
                                    "--worker=%s --authorization=%s "
                                    "--kubernetes-version %s "
                                    "--networking %s") % (
                                        name,
                                        instance_type,
                                        worker_cnt,
                                        auth_mode,
                                        version,
                                        networking), False)


def __cloud_cleanup(name):
    try:
        flash_config = os.environ['ALLSPARK_FLASH_CONFIG']
        dst = "/tmp/%s.cicd.cfg" % name
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG=%s flash "
                                    "kops cleanup %s") % (dst, name))
    except Exception:
        return container.run(name, "flash kops cleanup %s" % name)


def addons(ctx, iam_role, logging_format=False):
    log_error = logging.log_error(logging_format)
    log = logging.log(logging_format)

    if iam_role:
        (r, out) = utils.command(["kops", "get", "clusters", ctx, "-oyaml"])
        if r != 0:
            log_error("Unable to get KOPS clusters for editing", ctx)
            return r
        full_path = os.path.realpath(__file__)
        path, filename = os.path.split(full_path)
        file_path = os.path.join(path, ADDITIONAL_POLICIES)
        with open(file_path, 'r') as f:
            additional_policies = f.read()
        cluster_file = out + additional_policies
        fd, cluster_yaml = tempfile.mkstemp()
        with open(cluster_yaml, "w") as f:
            f.write(cluster_file)
        (r, out) = utils.command(["kops", "replace", "-f", cluster_yaml])
        if (r != 0):
            log_error("Unable to insert additional IAM policies", ctx)
            return r
        (r, out) = utils.command(["kops", "update", "cluster", ctx, "--yes"])
        if (r != 0):
            log_error("Unable to update cluster with additional IAM policies", ctx)
            return r
        else:
            log("Inserted additional IAM roles to KOPS cluster nodes successfully")

    addon_path = config.get_ci_build()
    if not addon_path:
        return 0

    if os.path.exists(addon_path) and os.listdir(addon_path):
        cmd = "kubectl --context %s create -f %s" % (ctx, addon_path)
        log('RUNNING:%s' % cmd)
        r = utils.command(cmd, streaming=True, no_output=bool(logging_format))
        if (r != 0):
            log_error("Error when installing addons: ", cmd)
        return r
    return 0


def process(arg):
    cloud = arg.get('--cloud')
    if arg['start']:
        return start(
            arg['<name>'], arg['--instance'], arg['--worker'],
            arg['--authorization'], arg['--networking'], cloud=cloud)
    elif arg['cleanup']:
        return cleanup(arg['<name>'], cloud=cloud)
    elif arg['status']:
        return status(arg['<name>'], cloud=cloud)
    elif arg['envsetup']:
        return envsetup(arg['<name>'], cloud=cloud)
