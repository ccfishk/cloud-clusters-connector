import http.client
import json
import time
import base64
import jwt
from flashpkg import logging
from flashpkg.state import state
from flashpkg.config import config

def start(*args, **kwargs):
    return __local_start(*args, **kwargs)

def cleanup(*args, **kwargs):
    return __local_cleanup(*args, **kwargs)

def status(*args, **kwargs):
    return __local_status(*args, **kwargs)

def envsetup(*args, **kwargs):
    return __local_envsetup(*args, **kwargs)

def get_cluster_details(cluster_name):
    conn = http.client.HTTPSConnection(config.get_tmc_url())
    auth = 'Bearer {}'.format(state.get_tmc_access_token())
    headers = {'accept': 'application/json', 'authorization': auth,
               'content-type': 'application/json'}
    conn.request('GET',
                 '/v1alpha/clusters/{}?full_name.location=global'.format(cluster_name),
                 headers=headers)
    res = conn.getresponse()
    if res.status != 200:
        if res.status == 404:
            print('checking status for {}: not found'.format(cluster_name))
        else:
            print('ERROR cluster details. status: {} reason: {}'.format(res.status, res.reason))
        raise Exception('could not get cluster {} details'.format(cluster_name), res.status)
    return json.loads(res.read())

def wait_for_cluster(cluster_name, timeout_in_seconds=1200):
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        try:
            cldetails = get_cluster_details(cluster_name)
            print(cldetails)
            status = cldetails.get('cluster').get('status').get('status').get('state').get('state')
            print('status: {}'.format(status))
            if status == 'READY':
                print('cluster ready, checking health')
                health = cldetails.get('cluster').get('status').get('health')
                if health is not None:
                    health_status = health.get('status')
                    if health_status is not None:
                        health_status_map = health_status.get('health')
                        if health_status_map is not None:
                            health_status_val = \
                                health_status_map.get('health')
                            print('health value: {}'.format(health_status_val))
                            if health_status_val == 'HEALTHY':
                                return 0
        except Exception:
            print('ERROR in waiting for cluster trying again')
        time.sleep(25)
    return 1

def get_cluster_kube_config(cluster_name):
    conn = http.client.HTTPSConnection(config.get_tmc_url())
    auth = 'Bearer {}'.format(state.get_tmc_access_token())
    headers = {'accept': 'application/json', 'authorization': auth,
               'content-type': 'application/json'}
    conn.request(
        'GET',
        '/v1alpha/clusters/somename/provisionedclusters/{}/kubeconfig?full_name.location=global'.format(cluster_name),
        headers=headers
    )
    resp = conn.getresponse()
    if resp.status != 200:
        print('ERROR: Resp status {} reason: {}'.format(resp.status, resp.reason))
        print('RESP DATA: {}'.format(str(resp.read())))
        raise Exception('could not get kubeconfig for {}'.format(cluster_name))
    json_response = json.loads(resp.read())
    encoded = json_response.get('kubeconfig')
    yaml = base64.b64decode(encoded)
    return yaml

def get_cluster_kube_config_retries(cluster_name, timeout_s=600):
    timeout_in_seconds = timeout_s
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        try:
            yaml = get_cluster_kube_config(cluster_name)
            print('yaml successfully obtained for {}'.format(cluster_name))
            return yaml
        except Exception:
            print('cluster {} does not have kubeconfig ready yet, retrying'.format(cluster_name))
            time.sleep(25)
    raise Exception('could not retrieve kubeconfig for {}, timedout retrying {}s'.format(cluster_name, timeout_in_seconds))

def __local_start(cluster_name, region, zones, instance, workers, group="default", kube_version=None, account_name=None, ssh_key_name=None, configpath=None, verbose_flag=False, logging_format=False):
    log = logging.log(logging_format)
    log_error = logging.log_error(logging_format)

    if verbose_flag:
        log('starting tmc cluster in region {}, zones {} with name {}, instance {}, workers {}'.format(
            region, zones, cluster_name, instance, workers))
        log("group: {}, kube_version: {}, account_name: {}, ssh_key_name:{}, configpath: {}".format(
            group, kube_version, account_name, ssh_key_name, configpath))

    conn = http.client.HTTPSConnection(config.get_tmc_url())
    auth = 'Bearer {}'.format(state.get_tmc_access_token())
    headers = {'accept': 'application/json', 'authorization': auth,
               'content-type': 'application/json'}
    flashUser = jwt.decode(state.get_tmc_access_token(), verify=False).get("acct")
    if flashUser is None:
        raise Exception('the token to create cluster did not have a user to add to FlashUser tag')

    conn.request('GET', '/v1alpha/clusters:options?account_name.name={}'.format(account_name), headers=headers)

    optionsRes = conn.getresponse()
    clusterAvailableOptions = json.loads(optionsRes.read().decode('utf-8'))

    pod_cidr = clusterAvailableOptions.get('networkOptions').get('defaultPodCidr')
    service_cidr = clusterAvailableOptions.get('networkOptions').get('defaultServiceCidr')
    cidr_block = clusterAvailableOptions.get('awsOptions').get('defaultVpcCidr')

    regionalOptions = clusterAvailableOptions.get('awsOptions').get('regionalOptions')

    regionOptionsList = [option for option in regionalOptions if option.get('regionName') == region]

    if len(regionOptionsList) == 0:
        log_error('region {} not found in options'.format(region))
        return 1

    regionOptions = regionOptionsList[0]
    matchingKubeVersions = [version for version in regionOptions.get('versionList') if version.get('upstreamVersion') == kube_version]

    if len(matchingKubeVersions) == 0:
        log_error('kube version not found for region {}'.format(region))
        return 1

    matchingKubeVersion = matchingKubeVersions[0]
    kubeVersionName = matchingKubeVersion.get('name')
    req_body = {
        'cluster': {
            'full_name': {
                'name': cluster_name,
                'location': 'global'
            },
            'object_meta': {
                'group': group,
                'description': '',
                'labels': {
                    'FlashUser': flashUser
                }
            },
            'spec': {
                'provisionedcluster': {
                    'high_availability': False,
                    'network_config': {
                        'pod_cidr': pod_cidr,
                        'service_cidr': service_cidr
                    },
                    'cloud_provider_config': {
                        'aws_config': {
                            'control_plane_vm_flavor': instance,
                            'ssh_key_name': ssh_key_name,
                            'region': region,
                            'az_list': zones,
                            'network_spec': {
                                'vpc': {
                                    'cidr_block': cidr_block
                                }
                            },
                        }
                    },
                    'version': kubeVersionName,
                    'node_pool': [
                        {
                            'full_name': {
                                'name': 'default-node-pool',
                                'location': 'global',
                                'cluster_name': cluster_name,
                                'provisionedcluster_name': cluster_name,
                            },
                            'object_meta': {
                                'description': ''
                            },
                            'spec': {
                                'cloud_provider_config': {
                                    'aws_config': {
                                        'instance_type': instance,
                                        'zone': zones
                                    }
                                },
                                'worker_node_count': str(workers),
                                'node_label_map': {},
                                'cloud_label_map': {
                                    'FlashUser': flashUser
                                },
                                'version': kubeVersionName,
                            },
                            'edit_mode': False,
                        }
                    ],
                    'account_name': account_name,
                }
            }
        }
    }

    if verbose_flag:
        log('making request to tmc')
        log(req_body)

    conn.request('POST', '/v1alpha/clusters',
                 body=json.dumps(req_body), headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        log_error('ERROR: Resp status {} reason: {}'.format(resp.status, resp.reason))
        log_error('RESP DATA: {}'.format(str(resp.read())))
        raise Exception('could not create tmc cluster')

    assert wait_for_cluster(cluster_name) == 0, 'failed cluster onboard'
    if configpath is None:
        configpath = 'kubeconfig-{}.yaml'.format(cluster_name)
    save_kube_config(cluster_name, configpath, 600)
    print_setup_message(cluster_name, configpath)
    return 0

def __local_cleanup(cluster_name):
    print('local cleanup cleaning up tmc cluster: {}'.format(cluster_name))
    conn = http.client.HTTPSConnection(config.get_tmc_url())
    auth = 'Bearer {}'.format(state.get_tmc_access_token())
    headers = {'accept': 'application/json', 'authorization': auth,
               'content-type': 'application/json'}
    conn.request(
        'DELETE',
        '/v1alpha/clusters/{}?full_name.location=global&force=false'.format(cluster_name),
        headers=headers
    )
    resp = conn.getresponse()
    if resp.status == 404:
        print('cluster {} not found. Success deleting'.format(cluster_name))
        return 0
    elif resp.status != 200:
        print('ERROR: Resp status {} reason: {}'.format(resp.status, resp.reason))
        print('RESP DATA: {}'.format(str(resp.read())))
        raise Exception('could not delete tmc cluster')

    timeout_in_seconds = 1200
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        try:
            get_cluster_details(cluster_name)
        except Exception as ex:
            (msg, code) = ex.args
            if code == 404:
                print('cluster {} deleted. cleanup success.'.format(cluster_name))
                return 0
    print('could not verify that the cluster {} was deleted from tmc'.format(cluster_name))
    return 1

def save_kube_config(cluster_name, configpath, timeout=600):
    cluster_kube_config_yaml = get_cluster_kube_config_retries(cluster_name, timeout)
    f = open(configpath, "wb")
    f.write(cluster_kube_config_yaml)
    f.close()

def print_setup_message(cluster_name, configpath):
    print('saved kubeconfig for {} to {}'.format(cluster_name, configpath))
    print('to use this with kubernetes, install tmc cli and add {} to KUBECONFIG (export KUBECONFIG={})'.format(
        configpath,
        configpath
    ))
    print('tmc cli: https://tsmproduptime.tmc.cloud.vmware.com/clidownload')

def __local_status(cluster_name):
    wait_for_cluster(cluster_name, 1)
    return 0

def __local_envsetup(cluster_name):
    assert wait_for_cluster(cluster_name, 10) == 0, 'failed cluster onboard'
    configpath = 'kubeconfig-{}.yaml'.format(cluster_name)
    save_kube_config(cluster_name, configpath, 10)
    print_setup_message(cluster_name, configpath)
