from flashpkg import utils


def start(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    # return __cloud_start(*args)

    return __local_start(*args)


def cleanup(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    # return __cloud_cleanup(*args)

    return __local_cleanup(*args)


def status(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    #    return __cloud_status(*args)

    return __local_status(*args)


def envsetup(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    #   return __cloud_envsetup(*args, prefix=prefix)

    return __local_envsetup(*args)


def __local_start(name, region, folder, project, org, token, privileged, version):
    print("Starting cluster on region {} with name {}, folder {}, project {}, org {}, "
          "version {}".format(
              region, name, folder, project, org, version
          ))
    print()
    print("Logging into org {} with token {}".format(org, token))
    (status, out) = utils.command(["vke", "account", "login", "--organization", org, "--refresh-token", token])
    if status != 0:
        print(out)
        return status

    print("Setting folder to {}".format(folder))
    (status, out) = utils.command(["vke", "folder", "set", folder])
    if status != 0:
        print(out)
        return status

    print("Setting project to {}".format(project))
    (status, out) = utils.command(["vke", "project", "set", project])
    if status != 0:
        print(out)
        return status

    cmd = ["vke", "cluster", "create", "--version", version,
           "--name", name, "--region", region, "--force"]
    if privileged:
        cmd.append("--privilegedMode")

    (status, out) = utils.command(cmd, streaming=True, lex=False)
    if status != 0:
        print(out)

    cmd = ["vke", "cluster", "auth", "setup", "--folder", "SharedFolder",
           "--project", "SharedProject", name]
    (status, out) = utils.command(cmd, streaming=True, lex=False)
    if status != 0:
        print(out)

    return status


def __local_cleanup(name, org, token):
    print("Logging into org {} with token {}".format(org, token))
    (status, out) = utils.command(["vke", "account", "login", "--organization", org, "--refresh-token", token])
    if status != 0:
        print(out)
        return status

    print("Cleaning up cluster {}".format(name))
    (status, out) = utils.command(["vke", "cluster", "delete", name], streaming=True, lex=False)
    if status != 0:
        print(out)
    (status, out) = utils.command(["vke", "cluster", "auth", "delete",
                                   "--folder", "SharedFolder",
                                   "--project", "SharedProject", name])
    if status != 0:
        print(out)

    return status


def __local_envsetup(name, org, token):
    print("Logging into org {} with token {}".format(org, token))
    (status, out) = utils.command(["vke", "account", "login", "--organization", org, "--refresh-token", token])
    if status != 0:
        print(out)
        return status

    print("Authenticating with cluster {}".format(name))
    (status, out) = utils.command(["vke", "cluster", "auth", "setup", name])
    print(out)
    return status


def __local_status(name, org, token):
    print("Logging into org {} with token {}".format(org, token))
    (status, out) = utils.command(["vke", "account", "login", "--organization", org, "--refresh-token", token])
    if status != 0:
        print(out)
        return status

    (status, out) = utils.command(["vke", "cluster", "show-health", name])
    print(out)
    return status


def process(arg):
    cloud = arg.get('--cloud')
    if arg['start']:
        return start(
            arg['<name>'], arg['--instance'], arg['--worker'],
            arg['--authorization'], cloud=cloud)
    elif arg['cleanup']:
        return cleanup(arg['<name>'], cloud=cloud)
    elif arg['status']:
        return status(arg['<name>'], cloud=cloud)
    elif arg['envsetup']:
        return envsetup(arg['<name>'], cloud=cloud)
