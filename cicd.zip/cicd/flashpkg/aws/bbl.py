"""
Usage:
  flash bbl start bosh <name> [--cloud]
  flash bbl start cf <name> [--cloud]
  flash bbl cleanup <name> [--cloud]

Description:
  flash bbl : commands to interact with "bbl".

Options:
  --cloud   Run the command remotely in the cloud.
"""
from docopt import docopt
from flashpkg import utils
from flashpkg.config import config
from flashpkg.aws import container, storage
import os
import sys
import yaml

DOMAIN = os.environ.get("DOMAIN", "servicemesh.biz")
CLOUD = config.get_allspark_cloud()
REGION = config.get_cloud_region()
ACCESS_KEY = os.environ.get("AWS_ACCESS_KEY_ID")
SECRET_ACCESS_KEY = os.environ.get("AWS_SECRET_ACCESS_KEY")
ACCESS_FLAGS = ["--aws-access-key-id", ACCESS_KEY, "--aws-secret-access-key",
                SECRET_ACCESS_KEY]
IAAS_FLAGS = ["--aws-region", REGION, "--iaas", CLOUD]
STORE_NAME = "cf-state-store"


def __check_env():
    if (ACCESS_KEY is None or SECRET_ACCESS_KEY is None):
        print("Please set the following environment variables:")
        print("\tAWS_ACCESS_KEY_ID")
        print("\tAWS_SECRET_ACCESS_KEY")
        return False

    return True


def __run_command(cmd, shell=False, lex=False):
    try:
        (code, err) = utils.command(cmd, streaming=True, shell=shell, lex=lex)
        return code, err
    except OSError as e:
        print("It doesn't look like {} is installed: {}".format(cmd[0], e))
        return 127, None
    except ValueError as e:
        print("Arguments are incorrect: {}".format(e))
        return 1, None


def __save_state(state_dir, name, tar_file):
    utils.archive_dir(state_dir, tar_file)
    storage.create(STORE_NAME)
    storage.upload(STORE_NAME, tar_file, tar_file)


def __fetch_state(name, tar_file):
    if storage.download(STORE_NAME, tar_file, tar_file) == 0:
        utils.extract_archive(tar_file)
        os.remove(tar_file)


def __switch_dir(name):
    state_dir = "/tmp/{}-cf".format(name)
    if not os.path.exists(state_dir):
        os.makedirs(state_dir)

    os.chdir(state_dir)


def deploy_bosh(*args, **kwargs):
    if kwargs.get("cloud"):
        return __deploy_cloud_bosh(*args)

    return __deploy_local_bosh(*args)


def deploy_cf(*args, **kwargs):
    if kwargs.get("cloud"):
        return __deploy_cloud_cf(*args)

    return __deploy_local_cf(*args)


def cleanup(*args, **kwargs):
    if kwargs.get("cloud"):
        return __cloud_cleanup(*args)

    return __local_cleanup(*args)


def __deploy_local_bosh(name):
    if not __check_env():
        return 1

    __switch_dir(name)
    tar_file = "{}-cf.tar.gz".format(name)
    __fetch_state(name, tar_file)

    print("Deploying BOSH")
    cmd = ["bbl", "up", "--name", name] + ACCESS_FLAGS + IAAS_FLAGS
    deploy_cf = __run_command(cmd)
    if deploy_cf[0] != 0:
        print("Failed to deploy BOSH: {}".format(deploy_cf[1]))
        return deploy_cf

    print("Generating certificate for load balancer")
    cmd = ["openssl", "req", "-x509", "-sha256", "-nodes", "-newkey",
           "rsa:4096", "-keyout", "key.pem", "-out", "cert.pem", "-days",
           "365", "-subj", "/CN={}".format(DOMAIN)]
    generate_cert = __run_command(cmd)
    if generate_cert[0] != 0:
        print("Failed to generate certificate: {}".format(generate_cert[1]))
        return generate_cert

    print("Planning load balancer")
    cmd = ["bbl", "plan", "--lb-type", "cf",
           "--lb-cert", "cert.pem", "--lb-key", "key.pem"] + ACCESS_FLAGS
    plan_lb = __run_command(cmd)
    if plan_lb[0] != 0:
        print("Failed to plan load balancer: {}".format(plan_lb[1]))
        return plan_lb

    print("Deploying load balancer")
    cmd = ["bbl", "up"] + ACCESS_FLAGS
    deploy_lb = __run_command(cmd)
    if deploy_lb[0] != 0:
        print("Failed to deploy load balancer: {}".format(deploy_lb[1]))
        return deploy_lb

    __save_state(".", name, tar_file)

    return 0


def __deploy_local_cf(name):
    if not __check_env():
        return 1

    version = os.environ.get("STEMCELL_VERSION", "3541.5")
    __switch_dir(name)
    tar_file = "{}-cf.tar.gz".format(name)
    __fetch_state(name, tar_file)

    print("Uploading stemcell")
    cmd = ("eval \"$(bbl print-env)\" && bosh upload-stemcell "
           "https://bosh.io/d/stemcells/"
           "bosh-aws-xen-hvm-ubuntu-trusty-go_agent?v={}").format(version)
    upload = __run_command(cmd, shell=True, lex=False)
    if upload[0] != 0:
        print("Failed to upload stemcell: {}".format(upload[1]))
        return upload

    print("\nDeploying CF")
    base_dir = os.path.dirname(os.path.realpath(
        os.path.join(
            os.getcwd(), os.path.dirname(__file__)
        )
    )) + "/config"
    manifest = base_dir + "/cf-deployment.yml"
    iaas_op = base_dir + "/aws.yml"
    compiled = base_dir + "/use-compiled-releases.yml"
    cmd = ("eval \"$(bbl print-env)\" && bosh -n -d {} deploy {} "
           "-v system_domain={} --vars-store deployment-vars.yml "
           "-o {} -o {}").format(name, manifest, DOMAIN, iaas_op, compiled)

    with open(manifest) as f:
        doc = yaml.load(f)

    doc["name"] = name
    with open(manifest, "w") as f:
        yaml.dump(doc, f)

    deploy_cf = __run_command(cmd, shell=True, lex=False)
    if deploy_cf[0] != 0:
        print("Failed to deploy CF cluster: {}".format(deploy_cf[1]))
        return deploy_cf

    __save_state(".", name, tar_file)

    return 0


def __deploy_cloud_bosh(name):
    try:
        flash_config = os.environ.get("ALLSPARK_FLASH_CONFIG")
        dst = "/tmp/{}.cicd.cfg".format(name)
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG={} flash "
                                    "bbl start bosh {}").format(dst, name),
                             False)
    except Exception:
        return container.run(name, "flash bbl start cf {}".format(name),
                             False)


def __deploy_cloud_cf(name):
    try:
        flash_config = os.environ.get("ALLSPARK_FLASH_CONFIG")
        dst = "/tmp/{}.cicd.cfg".format(name)
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG={} flash "
                                    "bbl start cf {}").format(dst, name),
                             False)
    except Exception:
        return container.run(name, "flash bbl start cf {}".format(name),
                             False)


def __cloud_cleanup(name):
    try:
        flash_config = os.environ['ALLSPARK_FLASH_CONFIG']
        dst = "/tmp/{}.cicd.cfg".format(name)
        container.cp_to_container(name, flash_config, dst)
        return container.run(name, ("ALLSPARK_FLASH_CONFIG={} flash "
                                    "bbl cleanup {}").format(dst, name))
    except Exception:
        return container.run(name, "flash bbl cleanup {}".format(name))


def __local_cleanup(name):
    if not __check_env():
        return 1

    __switch_dir(name)
    tar_file = "{}-cf.tar.gz".format(name)
    __fetch_state(name, tar_file)

    print("Deleting CF cluster")
    cmd = ("eval \"$(bbl print-env)\" && bosh -d {} "
           "delete-deployment -n").format(name)
    delete_cf = __run_command(cmd, shell=True, lex=False)
    if delete_cf[0] != 0:
        print("Failed to delete the CF cluster: {}".format(delete_cf[1]))
        return delete_cf

    print("Deleting BOSH")
    cmd = ["bbl", "destroy", "-n"] + ACCESS_FLAGS + IAAS_FLAGS
    delete_bosh = __run_command(cmd)
    if delete_bosh[0] != 0:
        print("Failed to delete BOSH: {}".format(delete_bosh[1]))
        return delete_bosh

    storage.delete(STORE_NAME)

    return 0


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    cloud = args['--cloud']
    if args['start']:
        if args['bosh']:
            return deploy_bosh(args['<name>'], cloud=cloud)
        elif args['cf']:
            return deploy_cf(args['<name>'], cloud=cloud)
    elif args['cleanup']:
        return cleanup(args['<name>'], cloud=cloud)
