"""
Usage:
  flash runner get vmname <name>
  flash runner get ip <name>
  flash runner get id <name>
  flash runner get key

Description:
  flash runner : commands to interact with the VM hosting the CI containers on the cloud.
"""
from docopt import docopt
from flashpkg import utils
from flashpkg.config import config
import boto3
import sys


def get_ssh_info(name, cluster):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import container

    key = get_key()
    user = config.get_vm_user_id()
    fqdn = get_vmname(name)
    label = "com.amazonaws.ecs.task-arn=" + \
        container.get_task_arn(name, cluster)
    return (key, user, fqdn, label)


def get_vmname(name):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import container

    cluster = config.get_cluster()
    instId = container.get_task_container_instance_id(name, cluster)
    ec2 = boto3.resource('ec2')
    instance = ec2.Instance(instId)
    return instance.public_dns_name


def get_key():
    return utils.ci_key()


def get_container_id(name, verbose=False):
    cluster = config.get_cluster()
    (key, user, fqdn, label) = get_ssh_info(name, cluster)
    cmd = ("ssh -i %s -q -o 'StrictHostKeyChecking no' %s@%s docker ps "
           "-f Label=%s | awk 'NR==2{print $1}'") % (
        key, user, fqdn, label)
    (s, r) = utils.command(cmd, shell=True)
    if verbose:
        print('cmd', cmd)
        print(s, r)
    return (s, r.rstrip())


def get_container_ip(name):
    cluster = config.get_cluster()
    (s, container) = get_container_id(name)
    if (s != 0):
        print("Error: unable to get container ID for name %s" % name)
        return (s, None)
    (key, user, fqdn, label) = get_ssh_info(name, cluster)
    cmd = ["ssh", "-i", "{}".format(key), "-o",
           "'StrictHostKeyChecking no'", "{}@{}".format(user, fqdn), "docker",
           "inspect", "{}".format(container),
           "-f", "\\\"{{ .NetworkSettings.IPAddress }}\\\""]

    (s, r) = utils.command(cmd)
    return (s, r)


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['get']:
        if args['ip']:
            (s, r) = get_container_ip(args['<name>'])
            print(r)
            return s
        elif args['id']:
            (s, r) = get_container_id(args['<name>'])
            print(r)
            return s
        elif args['vmname']:
            print(get_vmname(args['<name>']))
            return 0
        elif args['key']:
            print(get_key())
            return 0
