"""
Usage:
  flash storage create <store_name>
  flash storage delete <store_name> [<destination_file>]
  flash storage upload <store_name> <source_file> <destination_file> [--public]
 [--force]
  flash storage download <store_name> <source_file> <destination_file>

Description:
  flash storage : commands to interact with cloud storage.

Options:
  --public  object is publicly accessible
"""
from docopt import docopt
import boto3
import os
import botocore
import sys
from flashpkg.config import config

s3 = boto3.resource('s3')
AWS_DEFAULT_REGION = config.get_cloud_region()


def create(store_name):
    if not s3.Bucket(store_name) in s3.buckets.all():
        bucket = s3.Bucket(store_name)
        bucket.create(CreateBucketConfiguration={
            'LocationConstraint': AWS_DEFAULT_REGION})
    return 0


def delete(store_name, destination_file):
    if s3.Bucket(store_name) in s3.buckets.all():
        if destination_file is None:
            print("Deleting cloud storage %s" % store_name)
            bucket = s3.Bucket(store_name)
            bucket.objects.all().delete()
            bucket.delete()
        else:
            print("Deleting object %s from cloud storage %s"
                  % (destination_file, store_name))
            s3.Object(store_name, destination_file).delete()
    return 0


def upload(store_name, src_file, dest_file, public=False, force=False):
    if os.path.isfile(src_file) is False:
        print('file %s does not exist. skip' % (src_file))
        return 1
    try:
        s3.Object(store_name, dest_file).load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == '404':
            pass
        else:
            print(e)
            return 1
    else:
        if not force:
            print('file %s already in target bucket. Skip' % (dest_file))
            return 1
    try:
        s3.Bucket(store_name)
        if public:
            print("file %s is set to public access." % dest_file)
            s3.Bucket(store_name).upload_file(src_file, dest_file,
                                              ExtraArgs={'ACL': 'public-read'})
        else:
            s3.Bucket(store_name).upload_file(src_file, dest_file)
        return 0
    except Exception as e:
        return e.response['Error']['Code']


def download(store_name, src_file, dest_file):
    try:
        s3.Bucket(store_name).download_file(src_file, dest_file)
        return 0
    except botocore.exceptions.ClientError as e:
        return e.response['Error']['Code']


def process():
    if len(sys.argv) == 2:
        sys.argv.append('-h')
    args = docopt(__doc__)
    if args['create']:
        return create(args['<store_name>'])
    if args['delete']:
        return delete(args['<store_name>'], args['<destination_file>'])
    elif args['upload']:
        return upload(args['<store_name>'], args['<source_file>'],
                      args['<destination_file>'], args.get('--public'),
                      args.get('--force'))
    elif args['download']:
        return download(args['<store_name>'], args['<source_file>'],
                        args['<destination_file>'])
