import boto3
# import json
import time

# from botocore.exceptions import ClientError
CICDTableNameDefaultName = 'allspark-cicd-clusters'
DefaultTimeOut = 60 * 5  # 5 minutes

class Dynamo:
    def __init__(self, tableName=CICDTableNameDefaultName, tmout=DefaultTimeOut, bsize=100):
        self.client = boto3.client('dynamodb')
        self.timeout = tmout
        self.tableName = tableName
        self.batchSize = bsize
        self.initDone = False

    def isInitDone(self):
        return self.initDone

    def init(self):
        if self.getTable() is None:
            self.createCICDTable()
        self.initDone = True

    def getTable(self):
        try:
            response = self.client.describe_table(TableName=self.tableName)
    #        print(json.dumps(response['Table'], indent=4, sort_keys=True, default=str))
            return response['Table']
        except self.client.exceptions.ResourceNotFoundException:
            return None

    def deleteTable(self):
        try:
            response = self.client.delete_table(TableName=self.tableName)
            if response["ResponseMetadata"]["HTTPStatusCode"] != 200:
                raise Exception('Error when deleting table in db %s' % response["ResponseMetadata"])
            # Wait for delete to be completed
            cnt = 0
            while True:
                dt = self.getTable()
                if dt:
                    print('Creating: status table[%s] State=%s' % (self.tableName, dt['TableStatus']))
                else:
                    break
                time.sleep(1)
                cnt += 1
                if cnt > self.timeout:
                    raise Exception('timeout', 'Waiting for delete table %s to complete' % self.tableName)
        except self.client.exceptions.ResourceNotFoundException:
            return

    def createCICDTable(self):
        tbl = self.getTable()
        if tbl is not None:
            raise Exception('Table Already exists when create table is called')
        response = self.client.create_table(
            AttributeDefinitions=[
                {'AttributeName': 'userName', 'AttributeType': 'S'},
                {'AttributeName': 'clusterName', 'AttributeType': 'S'},
            ],
            TableName=self.tableName,
            KeySchema=[
                {
                    'AttributeName': 'userName',
                    'KeyType': 'HASH',
                },
                {
                    'AttributeName': 'clusterName',
                    'KeyType': 'RANGE',
                }
            ],
            BillingMode='PAY_PER_REQUEST',
            StreamSpecification={
                'StreamEnabled': False,
            },
            SSESpecification={
                'Enabled': False,
            }
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] != 200:
            raise Exception('Error when creating table in db %s' % response["ResponseMetadata"])

        cnt = 0
        while True:
            dt = self.getTable()
            if dt:
                print('Creating: status table[%s] State=%s' % (self.tableName, dt['TableStatus']))
            if dt and dt['TableStatus'] == 'ACTIVE':
                break
            time.sleep(1)
            cnt += 1
            if cnt > self.timeout:
                raise Exception('timeout', 'Waiting for delete table %s to complete' % self.tableName)

    def loadFullTable(self):
        lastKey = None
        pcnt = 0
        ret = {}
        while True:
            scanArg = {
                "TableName": self.tableName,
                "Limit": self.batchSize
            }
            if lastKey:
                scanArg["ExclusiveStartKey"] = lastKey
            response = self.client.scan(**scanArg)
            # print(json.dumps(response, indent=4, sort_keys=True, default=str))
            for itm in response["Items"]:
                if "clusterName" in itm and "userName" in itm:
                    clusterName = itm["clusterName"]["S"]
                    userName = itm["userName"]["S"]
                    if userName not in ret:
                        ret[userName] = {}
                    if clusterName not in ret[userName]:
                        ret[userName][clusterName] = {}
                    dest = ret[userName][clusterName]
                    for key in itm:
                        if key != "clusterName" and key != "userName":
                            dest[key] = itm[key]["S"]
            # print("Iteration %d got %d items lastKey=%s" % (pcnt, response["Count"], lastKey))
            pcnt += 1
            if 'LastEvaluatedKey' in response:
                lastKey = response["LastEvaluatedKey"]
            else:
                break
        return ret

    def loadUserTable(self, userName):
        ret = {}
        lastKey = None
        pcnt = 0
        while True:
            queryArg = {
                "TableName": self.tableName,
                "Limit": self.batchSize,
                "Select": "ALL_ATTRIBUTES",
                "KeyConditionExpression": "userName = :bob0",
                "ExpressionAttributeValues": {
                    ":bob0": {"S": userName}
                }
            }
            if lastKey:
                queryArg["ExclusiveStartKey"] = lastKey
            response = self.client.query(**queryArg)
            # print(json.dumps(response, indent=4, sort_keys=True, default=str))
            for itm in response["Items"]:
                if "clusterName" in itm and "userName" in itm:
                    clusterName = itm["clusterName"]["S"]
                    userName = itm["userName"]["S"]
                    if userName not in ret:
                        ret[userName] = {}
                    if clusterName not in ret[userName]:
                        ret[userName][clusterName] = {}
                    dest = ret[userName][clusterName]
                    for key in itm:
                        if key != "clusterName" and key != "userName":
                            dest[key] = itm[key]["S"]
            # print("Iteration %d got %d items lastKey=%s" % (pcnt, response["Count"], lastKey))
            pcnt += 1
            if 'LastEvaluatedKey' in response:
                lastKey = response["LastEvaluatedKey"]
            else:
                break
        if userName in ret:
            return ret[userName]
        else:
            return {}

    def upsertItem(self, userName, clusterName, dt):
        itmList = {
            'userName': {
                'S': userName
            },
            'clusterName': {
                'S': clusterName
            },
        }
        for key in dt:
            itmList[key] = {
                'S': dt[key]
            }
        r = self.client.put_item(
            TableName=self.tableName,
            Item=itmList)
        if r["ResponseMetadata"]["HTTPStatusCode"] != 200:
            raise Exception('Error when adding item to db %s' % r["ResponseMetadata"])

    def deleteItem(self, userName, clusterName):
        itmList = {
            'userName': {
                'S': userName
            },
            'clusterName': {
                'S': clusterName
            },
        }
        r = self.client.delete_item(
            TableName=self.tableName,
            Key=itmList)
        if r["ResponseMetadata"]["HTTPStatusCode"] != 200:
            raise Exception('Error when deleting item in db %s' % r["ResponseMetadata"])
