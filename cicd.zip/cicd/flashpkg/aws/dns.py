"""
Usage:
  flash dns add cname <zone_id> <cname> <value> [--upsert]
  flash dns remove cname <zone_id> <cname> [<value>]
  flash dns list zones
  flash dns list record_sets <zone_id> [--record_type=<record_type>]
  flash dns test answer <zone_id> <record_name> <record_type>

Description:
  flash dns : commands to add delete cname DNS records in AWS route53

Options:
  --record_type=<record_type>   DNS record type (for e.g. NS, SOA, CNAME etc.). Returns all record types by default.
  --upsert                      Replace the value associated with the existing Route53 recordset.

"""
from docopt import docopt
import boto3
import time
import sys
from prettytable import PrettyTable
client = boto3.client('route53')

def get_cname_info(zoneId, cname):
    try:
        resource_list = list_resource_record_sets(zoneId, record_type=None, output=False)
    except Exception as e:
        print("Failed to list record sets: {}".format(e))
        return None

    for resource in resource_list:

        # AWS treats wildcards as \052 when listing resources.
        # Because of this convert the encoded value to the real value so that we can match it correctly.
        resource["Name"] = resource["Name"].replace("\\052", "*")
        if resource['Type'] == 'CNAME' and resource['Name'] == (cname + '.'):
            return resource
    return None

def create_cname_record_set(zoneId, cname, value, upsert):
    action = 'CREATE'
    try:
        if upsert:
            rl = get_cname_info(zoneId, cname)
            if rl:  # Record aleady exists
                lb = rl['ResourceRecords'][0]
                print('Found an existing record for %s pointing to %s' % (cname, lb))
                if lb == value:
                    print("Record for %s already points to the right LB for the cluster, no need to delete and recreate it" % (
                        cname
                    ))
                    return 0
                delete_cname_record_set(zoneId, cname, rl['ResourceRecords'][0], wait=False)
        response = client.change_resource_record_sets(
            HostedZoneId=zoneId,
            ChangeBatch={
                'Changes': [{
                    'Action': action,
                    'ResourceRecordSet': {
                        'Name': cname,
                        'Type': 'CNAME',
                        'TTL': 300,
                        'ResourceRecords': [{'Value': value}]
                    }
                },
                ]
            }
        )
    except Exception as e:
        print(e)
        return
    timeout = time.time() + 60*5
    while time.time() < timeout:
        resp = client.get_change(Id=response['ChangeInfo']['Id'])
        if (resp['ChangeInfo']['Status'] == 'PENDING'):
            print("Waiting for recordset {} to be in sync action is {}".format(cname, action))
            time.sleep(5)
        else:
            break
    print(resp)
    return 0

def delete_cname_record_set(zoneId, cname, value, wait=True):
    action = 'DELETE'
    try:
        if not value:
            rl = get_cname_info(zoneId, cname)
            if (rl):
                value = rl['ResourceRecords'][0]
                print('extracted entry fron the cname=%s value=%s' % (cname, value))
            else:
                # no value exists in the system so we can just exit
                return 0
        response = client.change_resource_record_sets(
            HostedZoneId=zoneId,
            ChangeBatch={
                'Changes': [{
                    'Action': action,
                    'ResourceRecordSet': {
                        'Name': cname,
                        'Type': 'CNAME',
                        'TTL': 300,
                        'ResourceRecords': [{'Value': value}]
                    }
                },
                ]
            }
        )
    except Exception as e:
        print(e)
        return
    timeout = time.time() + 60*5
    if wait:
        while time.time() < timeout:
            resp = client.get_change(Id=response['ChangeInfo']['Id'])
            if (resp['ChangeInfo']['Status'] == 'PENDING'):
                print("Waiting for recordset {} to be in sync action is {}".format(cname, action))
                time.sleep(5)
            else:
                break
        print(resp)
    return 0

def list_hosted_zones(output=True):
    paginator = client.get_paginator('list_hosted_zones')
    hosted_zones = []
    if output:
        z = PrettyTable(['Id', 'Name', 'PrivateZone'])
    try:
        page_iterator = paginator.paginate()
        for page in page_iterator:
            zones = page['HostedZones']
            for zone in zones:
                hosted_zones.append({"Id": zone['Id'].split('/hostedzone/')[1],
                                     "Name": zone['Name'],
                                     "PrivateZone": zone['Config']['PrivateZone']})
                if output:
                    z.add_row([zone['Id'].split('/hostedzone/')[1], zone['Name'], zone['Config']['PrivateZone']])
    except Exception as e:
        print(e)
        return
    if output:
        print(z)
        return 0
    else:
        return hosted_zones

def list_resource_record_sets(zone_id, record_type=None, output=True):
    paginator = client.get_paginator('list_resource_record_sets')
    record_sets = []
    rr = PrettyTable(['Name', 'Type', 'TTL', 'ResourceRecords'])
    page_iterator = paginator.paginate(HostedZoneId=zone_id)
    for page in page_iterator:
        for rrs in page.get('ResourceRecordSets') or []:
            rrs["Name"] = rrs.get("Name").replace("\\052", "*")  # FIXME: duplicated again.
            resource_records = []
            for item in rrs.get('ResourceRecords') or []:
                resource_records.append(item['Value'])
            if not record_type:
                record_sets.append({"Name": rrs.get('Name'), "Type": rrs.get('Type'),
                                    "TTL": rrs.get('TTL'), "ResourceRecords": resource_records})
                rr.add_row([rrs.get('Name'), rrs.get('Type'), rrs.get('TTL'),
                            resource_records])
            elif rrs.get('Type') == record_type:
                record_sets.append({"Name": rrs.get('Name'), "Type": rrs.get('Type'),
                                    "TTL": rrs.get('TTL'), "ResourceRecords": resource_records})
                rr.add_row([rrs.get('Name'), rrs.get('Type'), rrs.get('TTL'),
                            resource_records])
    if output:
        print(rr)

    return record_sets

def test_dns_answer(zone_id, record_name, record_type, output=True):
    try:
        response = client.test_dns_answer(HostedZoneId=zone_id,
                                          RecordName=record_name,
                                          RecordType=record_type)
    except Exception as e:
        print(e)
        return
    del response['ResponseMetadata']
    if output:
        print(response)
        return 0
    else:
        return response

def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['list']:
        if args['zones']:
            return list_hosted_zones()
        elif args['record_sets']:
            try:
                return list_resource_record_sets(args['<zone_id>'], args['--record_type'])
            except Exception as e:
                print("Failed to list record sets: {}".format(e))
                return 1  # TODO: create and use a well-defined set of exit codes across flash.

    elif args['test']:
        return test_dns_answer(args['<zone_id>'], args['<record_name>'], args['<record_type>'])
    elif args['dns']:
        if args['add']:
            return create_cname_record_set(args['<zone_id>'], args['<cname>'], args['<value>'], args['--upsert'])
        else:
            return delete_cname_record_set(args['<zone_id>'], args['<cname>'], args['<value>'])
