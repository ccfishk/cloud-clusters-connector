"""
Usage:
  flash container status <name>
  flash container stop <name>
  flash container start <name> <commit_id>
  flash container run <name> <cmd>
  flash container shell <name>
  flash container cp <name> <from> <to>
  flash container cpto <name> <from> <to>

Description:
  flash container : commands to interact with a CI container on the cloud.
"""
from docopt import docopt
from flashpkg import utils
from flashpkg.aws import repo
from flashpkg.config import config
import os
import time
import boto3
import sys


client = boto3.client('ecs', region_name=config.get_cloud_region())


def get_task_arn(task, cluster):
    res = client.list_tasks(family=task, cluster=cluster)
    for arn in res["taskArns"]:
        return arn


def get_task_container_instance_id(task, cluster):
    arn = None
    task_arn = get_task_arn(task, cluster=cluster)
    if not task_arn:
        raise Exception("task %s not found" % (task))
    tasks = client.describe_tasks(tasks=[task_arn],
                                  cluster=cluster)
    for task in tasks["tasks"]:
        arn = task["containerInstanceArn"]
        break
    res = client.describe_container_instances(cluster=cluster,
                                              containerInstances=[arn])
    for inst in res["containerInstances"]:
        return inst["ec2InstanceId"]
    raise Exception("task %s could not find instance id" % (task))


def is_task_ready(task, cluster, verbose=False):
    arn = get_task_arn(task, cluster)
    if arn is not None:
        tasks = client.describe_tasks(tasks=[arn],
                                      cluster=cluster)
        for t in tasks["tasks"]:
            sts = t["lastStatus"]
            if verbose:
                print("Container: " + task + " Status: " + sts)
            if sts == "RUNNING":
                return True
        return False


def get_task_info(task, cluster):
    arn = None
    task_arn = get_task_arn(task, cluster)
    if not task_arn:
        raise Exception("task %s not found" % (task))
    tasks = client.describe_tasks(tasks=[task_arn],
                                  cluster=cluster)
    for task in tasks["tasks"]:
        arn = task["containerInstanceArn"]
        break
    return client.describe_container_instances(cluster=cluster,
                                               containerInstances=[arn])


def start(name, commit_id):
    # image is of format
    # 284299419820.dkr.ecr.us-west-2.amazonaws.com/ci:327db1ad0b809d36b8ceb5058c8e2da9e7416e3f
    cluster = config.get_cluster()
    repo_url = repo.url(config.get_repo())
    image_id = repo_url + ':' + commit_id.rstrip()
    mem = ''
    try:
        # First priority is to pick up the config file pointed by the
        # env variable.
        mem = os.environ['ALLSPARK_FLASH_CONTAINER_MEMORY']
    except Exception:
        pass
    if mem is None or mem == '':
        mem = config.get_memory()
    cont = {"memory": int(mem),
            "name": name, "image": image_id}
    client.register_task_definition(family=name,
                                    networkMode=config.get_network(),
                                    containerDefinitions=[cont])
    client.run_task(cluster=cluster, taskDefinition=name)
    timeout = time.time() + int(config.get_startup_wait_time())
    while True:
        if is_task_ready(name, cluster, True):
            return 0
        if time.time() > timeout:
            print("Container not ready: " + name)
            raise Exception("Container not ready")
        time.sleep(3)  # Poll time
    return 0


def stop(name):
    cluster = config.get_cluster()
    arn = get_task_arn(name, cluster)
    if arn is not None:
        client.stop_task(task=arn, cluster=cluster)
    defs = client.list_task_definitions(familyPrefix=name)
    for df in defs['taskDefinitionArns']:
        client.deregister_task_definition(taskDefinition=df)
    return 0


def status(name):
    cluster = config.get_cluster()
    arn = get_task_arn(name, cluster)
    if arn is None:
        print("No task %s found" % name)
        return 1
    res = get_task_info(name, cluster)
    for c in res['containerInstances']:
        print("task: %s  Status: %s conainer: %s" %
              (name, c['status'], c['containerInstanceArn']))
    if len(res['failures']):
        print(utils.json_dumps(res))
    return 0


def run(name, cmd_in, verbose=False):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import runner

    cluster = config.get_cluster()
    (key, user, fqdn, label) = runner.get_ssh_info(name, cluster)
    (s, container_id) = runner.get_container_id(name, verbose)
    if (s != 0) or (container_id == ''):
        print("Error: Unable to get container Id for %s" % name)
        return s
    cmd = ("ALLSPARK_CLOUD=%s AWS_ACCESS_KEY_ID=%s AWS_DEFAULT_REGION=%s "
           "AWS_SECRET_ACCESS_KEY=%s ") % (
        config.get_allspark_cloud(),
        os.environ['AWS_ACCESS_KEY_ID'],
        config.get_cloud_region(),
        os.environ['AWS_SECRET_ACCESS_KEY'])\
        + cmd_in
    cmd_out = ("ssh -i %s -q -o 'StrictHostKeyChecking no' %s@%s "
               "docker exec -t %s /bin/bash -c \"'%s'\"") % (
        key, user, fqdn, container_id, cmd)
    if verbose:
        print("Container RUN:")
        print("s, containerid", s, container_id)
        print(cmd)
        print(cmd_out)
    (s, r) = utils.command(cmd_out, streaming=True)
    print(r)
    return s


def cp(name, fr, to):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import runner

    cluster = config.get_cluster()
    (key, user, fqdn, label) = runner.get_ssh_info(name, cluster)
    (s, container_id) = runner.get_container_id(name)
    if (s != 0):
        print("Error: Unable to get container Id for %s" % name)
        return s
    cmd = ["ssh", "-q", "-i", "{}".format(key),
           "-o", "StrictHostKeyChecking=no", "{}@{}".format(user, fqdn),
           "docker", "cp", "{}:{}".format(container_id, fr),
           "/tmp/{}".format(name)]
    (s, r) = utils.command(cmd)
    if (s != 0):
        print("Error while copying file from Docker")
        return s
    s = os.system("scp -i %s -o 'StrictHostKeyChecking no' %s@%s:/tmp/%s %s" %
                  (key, user, fqdn, name, to))
    return s


def cp_to_container(name, fr, to):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import runner

    cluster = config.get_cluster()
    (key, user, fqdn, label) = runner.get_ssh_info(name, cluster)
    (s, container_id) = runner.get_container_id(name)
    if (s != 0):
        print("Error: Unable to get container Id for %s" % name)
        return s
    # copy file to vm
    s = os.system("scp -i %s -o 'StrictHostKeyChecking no' %s %s@%s:/tmp/%s" %
                  (key, fr, user, fqdn, name))
    if (s != 0):
        print("Error while copying file to runner vm")
        return s
    cmd = ["ssh", "-q", "-i", "{}".format(key),
           "-o", "StrictHostKeyChecking=no",
           "{}@{}".format(user, fqdn), "docker", "cp",
           "/tmp/{} {}:{}".format(name, container_id, to)]
    (s, r) = utils.command(cmd)
    return s


def shell(name):

    # Defer this import to break the circular dependency.
    # Without this the tool won't work across different versions of Python.
    from flashpkg.aws import runner

    cluster = config.get_cluster()
    (key, user, fqdn, label) = runner.get_ssh_info(name, cluster)
    (s, container_id) = runner.get_container_id(name)
    if (s != 0):
        print("Error: Unable to get container Id for %s" % name)
        return s
    os.system(("ssh -tt -i %s -o 'StrictHostKeyChecking no' "
               "%s@%s docker exec -ti %s /bin/bash") %
              (key, user, fqdn, container_id))
    return 0


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['start']:
        return start(args['<name>'], args['<commit_id>'])
    elif args['stop']:
        return stop(args['<name>'])
    elif args['status']:
        return status(args['<name>'])
    elif args['run']:
        return run(args['<name>'], args['<cmd>'])
    elif args['shell']:
        return shell(args['<name>'])
    elif args['cp']:
        return cp(args['<name>'], args['<from>'], args['<to>'])
    elif args['cpto']:
        return cp_to_container(args['<name>'], args['<from>'], args['<to>'])
