"""
Usage:
  flash repo login <repo_name>
  flash repo remove <repo_name> <commit_id>
  flash repo url <repo_name>
  flash repo create <repo_name>
  flash repo delete <repo_name>
  flash repo list <repo_name>

Description:
  flash repo : commands to interact with container registry on the cloud.
"""
from docopt import docopt
import os
import base64
import boto3
import sys
from flashpkg.config import config

ALLSPARK_ECR_REGISTRY = '284299419820'

client = boto3.client('ecr', region_name=config.get_cloud_region())


def list_all_commits(repo_name):
    # get the list of
    resp = client.list_images(
        registryId=ALLSPARK_ECR_REGISTRY,
        repositoryName=repo_name,
    )
    tagged = 0
    untagged = 0
    for itm in resp['imageIds']:
        if ('imageTag' in itm):
            print(itm['imageTag'])
            tagged += 1
        else:
            untagged += 1
    print("Total images:%d, Tagged:%d, Untagged:%d" %
          (tagged + untagged, tagged, untagged))


def create(repo_name):
    try:
        resp = client.describe_repositories(
            registryId=ALLSPARK_ECR_REGISTRY,
            repositoryNames=[repo_name]
        )
        for itm in resp['repositories']:
            if (itm['repositoryName'] == repo_name):
                return itm['repositoryArn']
    except Exception:
        pass  # Likely the repo does not exist
    resp = client.create_repository(repositoryName=repo_name,)
    return resp['repository']['repositoryArn']


def delete(repo_name):
    resp = client.delete_repository(
        registryId=ALLSPARK_ECR_REGISTRY,
        repositoryName=repo_name, force=True
    )
    return(resp['repository']['repositoryArn'])


def login(repo_name):
    r = client.get_authorization_token(
        registryIds=[ALLSPARK_ECR_REGISTRY]
    )
    resp = r['authorizationData'][0]
    tkn = base64.b64decode(resp["authorizationToken"]).decode('utf-8')
    username, passwd = tkn.split(":")
    url = resp['proxyEndpoint']
    cmd = "docker login -u %s -p %s %s" % (username, passwd, url)
    return os.system(cmd)


def url(repo_name):
    resp = client.describe_repositories(
        registryId=ALLSPARK_ECR_REGISTRY,
        repositoryNames=[repo_name]
    )
    for itm in resp['repositories']:
        if (itm['repositoryName'] == repo_name):
            return(itm['repositoryUri'])
    raise(Exception("Unable to find Repo %s" % repo_name))


def remove(repo_name, commit_id):
    raise(Exception("Not Implemented"))


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['create']:
        print(create(args['<repo_name>']))
        return 0
    if args['delete']:
        print(delete(args['<repo_name>']))
        return 0
    elif args['login']:
        return login(args['<repo_name>'])
    elif args['url']:
        print(url(args['<repo_name>']))
        return 0
    elif args['list']:
        return list_all_commits(args['<repo_name>'])
    elif args['remove']:
        return remove(args['<repo_name>'], args['<name>'])
