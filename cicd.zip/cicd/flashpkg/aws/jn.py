"""
Usage:
  flash jn start <name> <commit_id>
  flash jn stop <name>
  flash jn tunnel <name> [--local=<local_port> --remote=<remote port>]

Description:
  flash jn : commands to interact with jn on the cloud.

Options:
  --local=<local port>                 local port to forward tunnel traffic [default: 8888].
  --remote=<remote port>               remote port from which to forward tunnel traffic [default: 8888].
"""
from docopt import docopt
from flashpkg import utils
from flashpkg.aws import container, runner, kops
from flashpkg.config import config
import os
import sys


def tunnel(name, lport, rport):
    cname = os.environ["USER"] + "-" + name
    cluster = config.get_repo()
    (s, ip) = runner.get_container_ip(cname)
    if (s != 0):
        print("Unable to find container %s" % cname)
        return 1
    (key, user, fqdn, label) = runner.get_ssh_info(cname, cluster)
    cmd = ("ssh -n -f -i %s -o 'StrictHostKeyChecking no' -L%s:%s:%s %s@%s "
           "'touch /tmp/%s && tail -f /tmp/%s' > /dev/null 2>&1 & disown") % (
        key, lport, ip, rport, user, fqdn, cname, cname)
    os.system(cmd)
#    os.spawnl(os.P_NOWAIT, cmd)


def start(name, commit_id):
    cname = os.environ["USER"] + "-" + name
    container.start(cname, commit_id)
    tunnel(name, 8888, 8888)
    container.run(
        cname, (
            ("cd %s/allspark/tests && KOPS_JOB_NAME=%s jupyter notebook "
             "--ip=0.0.0.0 --allow-root --NotebookApp.token=''")) %
        (config.get_ci_base_path(), cname))


def stop(name):
    cname = os.environ["USER"] + "-" + name
    container.stop(cname)
    # kill any open tunnel
    (_, pid) = utils.command(
        "ps -eaf | grep '/tmp/%s' | grep -v grep | awk '{print $2}'" % cname)
    if pid is not None and pid != "" and pid != 0:
        cmd = "kill %s" % pid
        os.system(cmd)
    # remove any kops deployment name = "cname"
    print("Cleanup Kops if Any")
    kops.cleanup(cname)


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['start']:
        return start(args['<name>'], args['<commit_id>'])
    elif args['stop']:
        return stop(args['<name>'])
    elif args['tunnel']:
        return tunnel(args['<name>'], args['--local'], args['--remote'])
