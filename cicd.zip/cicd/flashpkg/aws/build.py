"""
Usage:
  flash build <name> <commit_id> <build_command> <runner_image> <artifacts_folder> <artifacts_cloud_storage_location>

Description:
  flash build : commands to interact with codebuild in the cloud.
"""
from docopt import docopt
from flashpkg.aws import storage
from flashpkg.config import config
from jinja2 import Template
import os
import sys
import zipfile
import boto3
import git
import time


client = boto3.client('codebuild', region_name=config.get_cloud_region())


def is_git_repo(path):
    try:
        git.Repo(path).git_dir
        return True
    except git.exc.InvalidGitRepositoryError:
        return False


def create_project(build_name, imagename, store_name, file_name):
    location = store_name + "/" + file_name
    artifact_name = build_name + ".zip"
    try:
        arn = config.get_arn()
        ctype = config.get_image_type()
        client.create_project(
            artifacts={
                "location": store_name,
                "name": artifact_name,
                "packaging": "ZIP",
                "path": "artifacts",
                        "type": "S3"
            },
            description=build_name,
            environment={
                "type": "LINUX_CONTAINER",
                        "image": imagename,
                        "computeType": ctype,
                        "privilegedMode": True
            },
            name=build_name,
            serviceRole=arn,
            source={
                "location": location,
                "type": "S3"
            },
            logsConfig={
                "s3Logs": {
                    "status": "ENABLED",
                    "location": store_name + "/" + "buildlog"
                }
            }
        )
        return 0
    except Exception as e:
        print(e.message)
        raise Exception("Error creating project")
        return -1


def delete_project(build_name):
    try:
        client.delete_project(
            name=build_name,
        )
        return 0
    except Exception as e:
        print(e.message)
        pass


def do_build(build_name):
    try:
        response = client.start_build(
            projectName=build_name,
        )
        print('Build started for project {}, AWS build id : {}') \
            .format(build_name, response['build']['id'])
        return response['build']['id']
    except Exception as e:
        print(e.message)
        raise Exception("Error starting build")
    return -1


def createzip(filename):
    zipf = zipfile.ZipFile(filename, 'w', zipfile.ZIP_DEFLATED)
    zipdir('./', zipf)
    zipf.close()
    return 0


def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))
    return 0


def addspectozip(filename):
    zipf = zipfile.ZipFile(filename, 'a')
    zipf.write('/tmp/buildspec.yml', 'buildspec.yml')
    zipf.close()
    return 0


def createbuildspec(command, artifacts):
    base_dir = os.path.dirname(os.path.realpath(
        os.path.join(
            os.getcwd(), os.path.dirname(__file__)
        )
    )) + "/config"

    with open(base_dir + "/buildspec.yml.tmpl") as file_:
        template = Template(file_.read())
        env_kwargs = dict(build_string=command, artifact_files=artifacts)
        with open('/tmp/buildspec.yml', 'w', zipfile.ZIP_DEFLATED) as file_:
            file_.write(template.render(**env_kwargs))
    return 0


def monitor_build(build_id):
    response = client.batch_get_builds(
        ids=[
            build_id,
        ]
    )
    while (response['builds'][0]['buildComplete'] is False):
        time.sleep(5)
        response = client.batch_get_builds(
            ids=[
                build_id,
            ]
        )
        print("Build in progress : Current Status {} Phase {}").format(
            response['builds'][0]['buildStatus'],
            response['builds'][0]['currentPhase'])
    return response['builds'][0]['buildStatus']


def cleanup(store_name, build_name):
    try:
        storage.delete(store_name)
        delete_project(build_name)
        return 0
    except Exception as e:
        print(e.message)
        raise Exception("cleanup failed")
    return -1


def build(name, commit_id, command, imagename, artifacts, store_name):
    if not is_git_repo("./"):
        raise Exception("Not a valid git repository")

    build_name = name + "-" + commit_id
    source_name = build_name + ".zip"
    try:
        storage.create(store_name)
        createzip(source_name)
        createbuildspec(command, artifacts)
        addspectozip(source_name)
        storage.upload(store_name, source_name, source_name)
        create_project(build_name, imagename, store_name, source_name)
        build_id = do_build(build_name)
        build_status = monitor_build(build_id)
        build_log = build_id.split(":")[1] + ".gz"
        if build_status == "SUCCEEDED":
            artifact_name = build_name + ".zip"
            storage.download(store_name, "artifacts/" + artifact_name,
                             artifact_name)
            storage.download(store_name, "buildlog/" + build_log,
                             build_name + "_log.gz")
            print("Artifact and Logs have been successfully downloaded"
                  " {} {}").format(artifact_name, build_name + "_log.gz")
            cleanup(store_name, build_name)
            return 0
        else:
            storage.download(store_name, "buildlog/" + build_log,
                             build_name + "_log.gz")
            cleanup(store_name, build_name)
            print("Build was not successful, please check"
                  "logs {}").format(build_name + "_log.gz")
        return -1
    except Exception as e:
        cleanup(store_name, build_name)
        print("Build was not successful:" + e.message)
        return -1


def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    if args['build']:
        return build(args['<name>'], args['<commit_id>'],
                     args['<build_command>'], args['<runner_image>'],
                     args['<artifacts_folder>'],
                     args['<artifacts_cloud_storage_location>'])
    raise Exception("Invalid argument for build.")
