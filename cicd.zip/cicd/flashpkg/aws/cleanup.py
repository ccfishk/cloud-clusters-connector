"""
Usage:
  flash cleanup infra (<tag_key> <tag_values>)... [--region=<region> [--assume-yes|--list]]

Description:
  flash cleanup : Clean up provisioned resources on cloud infra.

Options:
  --region=<region>     Specifies the region to use.
  --assume-yes          Assume "yes" for any confirmation prompts.
  --list                List the matched resources and exit.
"""
from docopt import docopt
import sys
import boto3
from botocore.exceptions import ClientError

RESOURCE_TYPE_FILTERS = ['sqs', 'sns', 's3', 'kms', 'kinesis']


def resource_cleanup(client, arns, cleanFn):
    for arn in arns:
        cleanFn(client, arn)

def __sqs_cleaner(client, arn):
    sqs_url = client.get_queue_url(
        QueueName=arn.split(':')[-1]
    )
    print("Deleting SQS queue with URL: {}".format(sqs_url['QueueUrl']))
    response = client.delete_queue(
        QueueUrl=sqs_url['QueueUrl']
    )
    print("Successfully deleted SQS queue {}".format(response))

def __sns_cleaner(client, arn):
    sns_paginator = client.get_paginator('list_subscriptions_by_topic')
    sns_iterator = sns_paginator.paginate(
        TopicArn=arn
    )
    for page in sns_iterator:
        subscriptions = page['Subscriptions']
        for subscription in subscriptions:
            if 'PendingConfirmation' not in subscription['SubscriptionArn']:
                print("Deleting subscription {}".format(subscription['SubscriptionArn']))
                response = client.unsubscribe(SubscriptionArn=subscription['SubscriptionArn'])
                print(response)
    print("Deleting SNS topic: {}".format(arn))
    response = client.delete_topic(
        TopicArn=arn
    )
    print(response)

def __s3_cleaner(client, arn):
    name = arn.split(":::")[1]
    print("Deleting bucket", name)
    bucket = client.Bucket(name)
    bucket.objects.all().delete()
    bucket.delete()
    print("Successfully deleted S3 bucket {}".format(name))

def __kms_cleaner(client, arn):
    name = arn.split("key/")[1]
    print("Scheduling KMS key deletion of", name)
    response = client.schedule_key_deletion(
        KeyId=name,
        PendingWindowInDays=7
    )
    print("Successfully scheduled deletion of KMS key {}".format(response))

def __kinesis_cleaner(client, arn):
    name = arn.split("stream/")[1]
    print("Deleting Kinesis stream", name)
    response = client.delete_stream(
        StreamName=name,
        EnforceConsumerDeletion=True
    )
    print("Successfully deleted Kinesis stream {}".format(response))

def infra_cleanup(resources_list, sqs_client, sns_client, s3_client, kms_client, kinesis_client):
    sqs_list = []
    sns_list = []
    s3_list = []
    kms_list = []
    kinesis_list = []
    cleaners = {}
    for arn in resources_list:
        if ':sqs:' in arn:
            sqs_list.append(arn)
        elif ':sns:' in arn:
            sns_list.append(arn)
        elif ':s3:' in arn:
            s3_list.append(arn)
        elif ':kms:' in arn:
            kms_list.append(arn)
        elif ':kinesis:' in arn:
            kinesis_list.append(arn)

    cleaners[sqs_client] = {__sqs_cleaner: sqs_list}
    cleaners[sns_client] = {__sns_cleaner: sns_list}
    cleaners[s3_client] = {__s3_cleaner: s3_list}
    cleaners[kms_client] = {__kms_cleaner: kms_list}
    cleaners[kinesis_client] = {__kinesis_cleaner: kinesis_list}

    for client, data in cleaners.items():
        for cleaner, arns in data.items():
            try:
                resource_cleanup(client, arns, cleaner)
            except ClientError as err:
                print("Unable to clean up resource using cleaner {}: {}".format(cleaner.__name__, err))
                return 1

    return 0

def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)
    tag_key = args.get("<tag_key>")
    tag_values = args.get("<tag_values>")
    tag_filters = []
    for k, v in zip(tag_key, tag_values):
        tag_filters.append({'Key': k, 'Values': v.split(',')})
    region = args.get("--region") if args.get("--region") else 'us-west-2'
    auto_cleanup = args.get("--assume-yes")
    list_only = args.get("--list")
    print("Received inputs: {}, region={} ".format(tag_filters, region))
    tagging_client = boto3.client('resourcegroupstaggingapi', region_name=region)
    paginator = tagging_client.get_paginator('get_resources')
    page_iterator = paginator.paginate(
        TagFilters=tag_filters,
        ResourceTypeFilters=RESOURCE_TYPE_FILTERS
    )
    resources_list = []
    for page in page_iterator:
        for resource in page['ResourceTagMappingList']:
            resources_list.append(resource['ResourceARN'])
    if not resources_list:
        print("No resources of type {} found with provided tag_key: {} and tag_values: {}".format(RESOURCE_TYPE_FILTERS, tag_key, tag_values))
        return 0
    elif list_only:
        print("{} matched resources: \n{}".format(len(resources_list), "\n".join(resources_list)))
        return 0
    else:
        sqs_client = boto3.client('sqs', region_name=region)
        sns_client = boto3.client('sns', region_name=region)
        s3_resource = boto3.resource('s3', region_name=region)
        kms_client = boto3.client('kms', region_name=region)
        kinesis_client = boto3.client('kinesis', region_name=region)
        if not auto_cleanup:
            user_input = input("{} \n \nPlease enter y(es) to delete the above {} resources.".format("\n".join(resources_list), len(resources_list)))
            if user_input.lower() in ("y", "yes"):
                return infra_cleanup(resources_list, sqs_client, sns_client, s3_resource, kms_client, kinesis_client)
            else:
                print("Cancelled cleanup of {} resources".format(RESOURCE_TYPE_FILTERS))
                return 0
        else:
            return infra_cleanup(resources_list, sqs_client, sns_client, s3_resource, kms_client, kinesis_client)
