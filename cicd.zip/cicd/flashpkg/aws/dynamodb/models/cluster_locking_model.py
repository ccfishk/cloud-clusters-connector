import boto3
import atexit

from datetime import datetime
from python_dynamodb_lock.python_dynamodb_lock import DynamoDBLockClient
from flashpkg.aws.dynamodb.config import config
from flashpkg.aws.dynamodb.models.cluster_model import CLUSTER_NAME_ATTRIBUTE, CLUSTER_POOL_ATTRIBUTE, \
    CLUSTER_LOCKED_ATTRIBUTE, CLUSTER_LOCKED_AT_ATTRIBUTE, CLUSTER_FLAVOR_ATTRIBUTE, \
    CLUSTER_REGION_ATTRIBUTE, CLUSTER_ZONES_ATTRIBUTE
from boto3.dynamodb.conditions import Attr

TABLE_NAME = 'Clusters'

class ClusterModelWithLock():
    def __init__(self):
        dynamodb = boto3.resource('dynamodb', config=config)
        self.client = DynamoDBLockClient(dynamodb)
        self.table = dynamodb.Table(TABLE_NAME)
        self.table_name = TABLE_NAME

        atexit.register(self.close)

    def close(self):
        self.client.close()

    def scan(self, **kwargs):
        result = self.table.scan(TableName=self.table_name, **kwargs)
        return result

    def update_item(self, **kwargs):
        return self.table.update_item(
            **kwargs
        )

    def lock(self, name):
        response = self.update_item(
            TableName=self.table_name,
            Key={
                CLUSTER_NAME_ATTRIBUTE: name
            },
            UpdateExpression=f"set {CLUSTER_LOCKED_AT_ATTRIBUTE}=:t, {CLUSTER_LOCKED_ATTRIBUTE}=:l",
            ExpressionAttributeValues={
                ':t': datetime.utcnow().isoformat(),
                ':l': True,
            },
            ReturnValues="UPDATED_NEW"
        )
        return response

    def get_first_unlocked(self, pool_name, flavor, region, zones):
        lock = self.client.acquire_lock('ClusterPools:Scan:Lock')

        response = self.scan(
            Select='ALL_ATTRIBUTES',
            FilterExpression=Attr(CLUSTER_POOL_ATTRIBUTE).eq(pool_name) &  # noqa: W504
            Attr(CLUSTER_LOCKED_ATTRIBUTE).eq(False) &  # noqa: W504
            Attr(CLUSTER_FLAVOR_ATTRIBUTE).eq(flavor) &  # noqa: W504
            Attr(CLUSTER_REGION_ATTRIBUTE).eq(region) &  # noqa: W504
            Attr(CLUSTER_ZONES_ATTRIBUTE).eq(zones)
        )

        items = response['Items']

        if not items:
            lock.release()
            return False

        cluster = items[0]
        cluster_name = cluster[CLUSTER_NAME_ATTRIBUTE]
        self.lock(cluster_name)

        lock.release()

        return cluster_name
