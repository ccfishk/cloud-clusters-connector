import boto3
import botocore

from flashpkg.aws.dynamodb.config import config

class Model:
    def __init__(self, table_name, attr_definitions, key_schema):
        dynamodb = boto3.resource('dynamodb', config=config)
        self.client = dynamodb.meta.client
        self.table = dynamodb.Table(table_name)
        self.table_name = table_name
        self.init(attr_definitions, key_schema)

    def init(self, attr_definitions, key_schema):
        if not self.table_exists():
            self.create_table(key_schema, attr_definitions)

    def create_table(self, key_schema, attr_definitions):
        return self.client.create_table(
            AttributeDefinitions=attr_definitions,
            KeySchema=key_schema,
            BillingMode='PAY_PER_REQUEST',
            StreamSpecification={
                'StreamEnabled': False,
            },
            SSESpecification={
                'Enabled': False,
            }
        )

    def table_exists(self):
        table = self.get_table()
        return True if table is not None else False

    def get_table(self):
        try:
            response = self.client.describe_table(TableName=self.table_name)
            return response.get('Table')
        except self.client.exceptions.ResourceNotFoundException:
            return None

    def put_item(self, item):
        try:
            response = self.table.put_item(
                Item=item
            )
        except botocore.exceptions.ClientError as e:
            raise Exception(e.response['Error']['Message']) from e
        else:
            return response

    def update_item(self, **kwargs):
        return self.table.update_item(
            **kwargs
        )

    def get_item(self, condition):
        try:
            response = self.table.get_item(Key=condition)
        except botocore.exceptions.ClientError as e:
            raise Exception(e.response['Error']['Message']) from e
        else:
            return response['Item'] if 'Item' in response else None

    def batch_get_item(self, keys):
        try:
            response = self.client.batch_get_item(
                RequestItems={
                    self.table_name: {
                        'Keys': keys,
                        'ConsistentRead': True
                    }
                },
                ReturnConsumedCapacity='TOTAL'
            )

        except botocore.exceptions.ClientError as e:
            raise Exception(e.response['Error']['Message']) from e
        else:
            data = response.get('Responses')

            if data:
                return data.get(self.table_name)
            else:
                raise Exception(f'Response incorrect: {self.table_name} key doesn\'t presented')

    def scan(self, **kwargs):
        return self.table.scan(TableName=self.table_name, **kwargs)

    def delete_item(self, **kwargs):
        return self.table.delete_item(
            **kwargs
        )

class ToClassObject:
    def __init__(self, **entries):
        self.__dict__.update(entries)
