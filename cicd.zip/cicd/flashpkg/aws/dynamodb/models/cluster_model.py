from flashpkg.aws.dynamodb.models.model import Model
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Attr

TABLE_NAME = 'Clusters'

CLUSTER_NAME_ATTRIBUTE = 'name'
CLUSTER_LOCKED_ATTRIBUTE = 'locked'
CLUSTER_CREATED_AT_ATTRIBUTE = 'createdAt'
CLUSTER_LOCKED_AT_ATTRIBUTE = 'lockedAt'
CLUSTER_UNLOCKED_AT_ATTRIBUTE = 'unlockedAt'
CLUSTER_FLAVOR_ATTRIBUTE = 'flavor'
CLUSTER_REGION_ATTRIBUTE = 'region'
CLUSTER_ZONES_ATTRIBUTE = 'zones'
CLUSTER_READY_ATTRIBUTE = 'ready'
CLUSTER_TENANTS_ATTRIBUTE = 'tenants'
CLUSTER_NSXSM_VERSION_ATTRIBUTE = 'nsxsm_version'
CLUSTER_POOL_ATTRIBUTE = 'pool'

ATTRIBUTE_DEFINITIONS = [
    {'AttributeName': CLUSTER_NAME_ATTRIBUTE, 'AttributeType': 'S'}
]

KEY_SCHEMA = [
    {
        'AttributeName': CLUSTER_NAME_ATTRIBUTE,
        'KeyType': 'HASH',
    }
]


class ClusterModel(Model):
    def __init__(self):
        super().__init__(TABLE_NAME, ATTRIBUTE_DEFINITIONS, KEY_SCHEMA)

    def lock(self, name):
        response = self.update_item(
            Key={
                CLUSTER_NAME_ATTRIBUTE: name
            },
            UpdateExpression=f"set {CLUSTER_LOCKED_AT_ATTRIBUTE}=:t, {CLUSTER_LOCKED_ATTRIBUTE}=:l",
            ExpressionAttributeValues={
                ':t': datetime.utcnow().isoformat(),
                ':l': True,
            },
            ReturnValues="UPDATED_NEW"
        )
        return response

    def unlock(self, name):
        response = self.update_item(
            Key={
                CLUSTER_NAME_ATTRIBUTE: name
            },
            UpdateExpression=f"set {CLUSTER_UNLOCKED_AT_ATTRIBUTE}=:t, {CLUSTER_LOCKED_ATTRIBUTE}=:l",
            ExpressionAttributeValues={
                ':t': datetime.utcnow().isoformat(),
                ':l': False,
            },
            ReturnValues="UPDATED_NEW"
        )
        return response

    def get_all(self, clusters):
        keys = [*map(lambda cluster: {CLUSTER_NAME_ATTRIBUTE: cluster}, clusters)]

        return self.batch_get_item(keys)

    def get_all_by_pool(self, pool_name):
        filter_expression = Attr(CLUSTER_POOL_ATTRIBUTE).eq(pool_name)
        response = self.scan(
            Select='ALL_ATTRIBUTES',
            FilterExpression=filter_expression)

        return response.get('Items', [])

    def get_all_unlocked_by_pool(self, pool_name, flavor, region, zones):
        response = self.scan(
            Select='ALL_ATTRIBUTES',
            FilterExpression=Attr(CLUSTER_POOL_ATTRIBUTE).eq(pool_name) &  # noqa: W504
            Attr(CLUSTER_LOCKED_ATTRIBUTE).eq(False) &  # noqa: W504
            Attr(CLUSTER_FLAVOR_ATTRIBUTE).eq(flavor) &  # noqa: W504
            Attr(CLUSTER_REGION_ATTRIBUTE).eq(region) &  # noqa: W504
            Attr(CLUSTER_ZONES_ATTRIBUTE).eq(zones)
        )
        return response['Items']

    def get_all_unlocked(self, clusters, flavor, region, zones):
        response = self.scan(
            Select='ALL_ATTRIBUTES',
            FilterExpression=Attr(CLUSTER_NAME_ATTRIBUTE).is_in(clusters) & Attr(CLUSTER_LOCKED_ATTRIBUTE).eq(False) & Attr(CLUSTER_FLAVOR_ATTRIBUTE).eq(
                flavor) & Attr(CLUSTER_REGION_ATTRIBUTE).eq(region) & Attr(CLUSTER_ZONES_ATTRIBUTE).eq(zones),
        )

        cluster_names = [*map(lambda cluster: cluster[CLUSTER_NAME_ATTRIBUTE], response['Items'])]
        return cluster_names

    def get_all_locked_by_pool(self, pool_name, days):
        now = datetime.now()
        then = now - timedelta(days=days)

        main_exp = Attr(CLUSTER_POOL_ATTRIBUTE).eq(pool_name) & Attr(CLUSTER_LOCKED_ATTRIBUTE).eq(True)
        with_period_exp = Attr(CLUSTER_POOL_ATTRIBUTE).eq(pool_name) & Attr(CLUSTER_LOCKED_ATTRIBUTE).eq(True) & Attr(CLUSTER_LOCKED_AT_ATTRIBUTE).lt(str(then))

        filter_expression = with_period_exp if days else main_exp

        response = self.scan(
            Select='ALL_ATTRIBUTES',
            FilterExpression=filter_expression)

        return response.get('Items', [])

    def get_item_by_name(self, name):
        return self.get_item({CLUSTER_NAME_ATTRIBUTE: name})

    def update(self, name, **kwargs):
        expression = []
        attribute_names = {}
        attribute_values = {}

        for item in kwargs.items():
            key = item[0]
            value = item[1]

            attr_name = f'#{key}'
            attr_value = f':{key}'

            attribute_names[attr_name] = key
            attribute_values[attr_value] = value

            expression.append(f'{attr_name}={attr_value}')

        response = self.update_item(
            Key={
                CLUSTER_NAME_ATTRIBUTE: name
            },
            UpdateExpression='set '+','.join(expression),
            ExpressionAttributeNames=attribute_names,
            ExpressionAttributeValues=attribute_values,
            ReturnValues="UPDATED_NEW"
        )
        return response

    def upsert(self, name, **kwargs):
        item = {
            CLUSTER_NAME_ATTRIBUTE: name
        }

        if 'locked' in kwargs:
            item[CLUSTER_LOCKED_ATTRIBUTE] = kwargs['locked']

        if 'created_at' in kwargs:
            item[CLUSTER_CREATED_AT_ATTRIBUTE] = kwargs['created_at']

        if 'locked_at' in kwargs:
            item[CLUSTER_LOCKED_AT_ATTRIBUTE] = kwargs['locked_at']

        if 'unlocked_at' in kwargs:
            item[CLUSTER_UNLOCKED_AT_ATTRIBUTE] = kwargs['unlocked_at']

        if 'flavor' in kwargs:
            item[CLUSTER_FLAVOR_ATTRIBUTE] = kwargs['flavor']

        if 'region' in kwargs:
            item[CLUSTER_REGION_ATTRIBUTE] = kwargs['region']

        if 'zones' in kwargs:
            item[CLUSTER_ZONES_ATTRIBUTE] = kwargs['zones']

        if 'ready' in kwargs:
            item[CLUSTER_READY_ATTRIBUTE] = kwargs['ready']

        if 'tenants' in kwargs:
            item[CLUSTER_TENANTS_ATTRIBUTE] = kwargs['tenants']

        if 'nsxsm_version' in kwargs:
            item[CLUSTER_NSXSM_VERSION_ATTRIBUTE] = kwargs['nsxsm_version']

        if 'pool' in kwargs:
            item[CLUSTER_POOL_ATTRIBUTE] = kwargs['pool']

        return self.put_item(item)

    def delete(self, name):
        return self.delete_item(Key={CLUSTER_NAME_ATTRIBUTE: name})
