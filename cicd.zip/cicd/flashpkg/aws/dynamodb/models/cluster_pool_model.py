from flashpkg.aws.dynamodb.models.model import Model
TABLE_NAME = 'ClusterPools'

POOL_NAME_ATTRIBUTE = 'name'
POOL_THRESHOLD_ATTRIBUTE = 'freeThreshold'
POOL_RECYCLE_TIME_ATTRIBUTE = 'recycleTime'
POOL_CLUSTER_NAMES_ATTRIBUTE = 'clusterNames'

DEFAULT_FREE_THRESHOLD = '5'
DEFAULT_RECYCLE_TIME_HOURS = '10'

ATTRIBUTE_DEFINITIONS = [
    {'AttributeName': 'name', 'AttributeType': 'S'}
]

KEY_SCHEMA = [
    {
        'AttributeName': 'name',
        'KeyType': 'HASH',
    }
]

class ClusterPoolModel(Model):
    def __init__(self):
        self.__pool = None
        super().__init__(TABLE_NAME, ATTRIBUTE_DEFINITIONS, KEY_SCHEMA)

    def get_cluster_names(self, name):
        pool = self.get(name)
        return pool and pool.get(POOL_CLUSTER_NAMES_ATTRIBUTE)

    def remove_cluster(self, pool_name, cluster_name):
        cluster_names = self.get_cluster_names(pool_name)

        updated_cluster_names = list(filter(lambda item: item != cluster_name, cluster_names))

        return self.update_item(
            Key={
                POOL_NAME_ATTRIBUTE: pool_name
            },
            UpdateExpression=f"set {POOL_CLUSTER_NAMES_ATTRIBUTE}=:t",
            ExpressionAttributeValues={
                ':t': updated_cluster_names,
            },
            ReturnValues="UPDATED_NEW"
        )

    def get(self, name):
        return self.get_item({POOL_NAME_ATTRIBUTE: name})

    def update_cluster_names(self, name, cluster_names):
        response = self.update_item(
            Key={
                POOL_NAME_ATTRIBUTE: name
            },
            UpdateExpression=f"set {POOL_CLUSTER_NAMES_ATTRIBUTE}=:cn",
            ExpressionAttributeValues={
                ':cn': cluster_names,
            },
            ReturnValues="UPDATED_NEW"
        )
        return response

    def upsert(self, name, **kwargs):
        item = {
            POOL_NAME_ATTRIBUTE: name
        }

        if 'free_threshold' in kwargs:
            item[POOL_THRESHOLD_ATTRIBUTE] = kwargs['free_threshold']

        if 'recycle_time' in kwargs:
            item[POOL_RECYCLE_TIME_ATTRIBUTE] = kwargs['recycle_time']

        if 'cluster_names' in kwargs:
            item[POOL_CLUSTER_NAMES_ATTRIBUTE] = kwargs['cluster_names']

        return self.put_item(item)

    def list(self):
        response = self.scan()
        return response['Items'] if 'Items' in response else None

    def find_pool_by_cluster(self, cluster_name):
        response = self.scan(FilterExpression="contains (#items, :itemVal)",
                             ExpressionAttributeNames={"#items": "clusterNames"},
                             ExpressionAttributeValues={":itemVal": cluster_name})

        if 'Items' in response:
            if response['Items'] and len(response['Items']):
                return response['Items'][0]
        return None

    def delete(self, name):
        return self.delete_item(
            Key={POOL_NAME_ATTRIBUTE: name},
            ConditionExpression=f"attribute_exists(#{POOL_NAME_ATTRIBUTE})",
            ExpressionAttributeNames={f'#{POOL_NAME_ATTRIBUTE}': f'{POOL_NAME_ATTRIBUTE}'}
        )
