from botocore.config import Config

MODE = 'legacy'
MAX_ATTEMPTS = 3

config = Config(
    retries={
        'max_attempts': MAX_ATTEMPTS,
        'mode': MODE
    }
)
