from flashpkg.state import state
from flashpkg.config import config
from flashpkg.infra import cluster as cluster_core
from flashpkg import nsxsm
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel, POOL_CLUSTER_NAMES_ATTRIBUTE
from flashpkg.aws.dynamodb.models.cluster_model import ClusterModel, CLUSTER_NSXSM_VERSION_ATTRIBUTE
from flashpkg.aws.dynamodb.models.model import ToClassObject

class CPClusterReleaseMixin:
    def __init__(self, **options):
        self.cluster_pool_model = ClusterPoolModel()
        self.cluster_model = ClusterModel()

        super().__init__(**options)

    def __clean_off_and_unlock(self, cluster):
        res = 0

        if CLUSTER_NSXSM_VERSION_ATTRIBUTE in cluster.__dict__ and cluster.nsxsm_version:
            res = nsxsm.uninstall_allspark(cluster.name, True)

        if res != 0:
            return 1
        else:
            self.cluster_model.update(cluster.name, **{CLUSTER_NSXSM_VERSION_ATTRIBUTE: ''})
            self.cluster_model.unlock(cluster.name)

        return res

    def __get_unlocked_clusters(self, pool_name, flavor, region, zones):
        return self.cluster_model.get_all_unlocked_by_pool(pool_name, flavor, region, zones)

    def __get_pool(self, cluster_pool_name):
        cluster_pool = self.cluster_pool_model.get(cluster_pool_name)
        if not cluster_pool:
            raise Exception(f"Cluster Pool `{cluster_pool_name}` doesn't exist ")
        return ToClassObject(**cluster_pool)

    def __get_cluster(self, pool_name, cluster_name):
        cluster = self.cluster_model.get_item_by_name(cluster_name)
        if not cluster:
            raise Exception(f"Cluster `{cluster_name}` doesn't exist in pool `{pool_name}` ")
        return ToClassObject(**cluster)

    def __get_cluster_type(self, flavor_name):
        flavor = config.get_flavor(flavor_name)
        if not flavor:
            raise Exception(f"No such flavor {flavor_name}")

        return flavor.get("type").lower()

    def __remove_cluster_from_pool(self, pool_name, cluster_name):
        pool = self.cluster_pool_model.get(pool_name)
        pool_cluster_names = pool[POOL_CLUSTER_NAMES_ATTRIBUTE]

        filtered_cluster_names = list(filter(lambda name: name != cluster_name, pool_cluster_names))

        self.cluster_pool_model.update_cluster_names(
            pool_name,
            filtered_cluster_names
        )

    def __remove_cluster(self, cluster_name):
        return self.cluster_model.delete(cluster_name)

    def __vanish_cluster(self, pool_name, cluster_name):
        self.__remove_cluster_from_pool(pool_name, cluster_name)
        self.__remove_cluster(cluster_name)

    def __delete_cluster(self, pool_name, cluster_name, flavor, cloud, region, skip_iam):
        cluster_type = self.__get_cluster_type(flavor)
        res = cluster_core.cleanup(cluster_name, cloud, cluster_type, region, skip_iam)

        if res == 0:
            state.remove_cluster(cluster_name)
            self.__vanish_cluster(pool_name, cluster_name)
        return res

    def release(self,
                pool_name,
                cluster_name,
                region=None,
                skip_iam=False,
                force=False,
                cloud=False):

        cluster = self.__get_cluster(pool_name, cluster_name)

        if not cluster.locked:
            print("Cluster already unlocked!")
            return 1

        if not region:
            region = cluster.region

        cluster_pool = self.__get_pool(pool_name)

        free_threshold = int(cluster_pool.freeThreshold)
        unlocked_clusters = self.__get_unlocked_clusters(pool_name, cluster.flavor, region, cluster.zones)

        if len(unlocked_clusters) < free_threshold:
            return self.__clean_off_and_unlock(cluster)
        else:
            return self.__delete_cluster(pool_name, cluster_name, cluster.flavor, cloud, region, skip_iam)
