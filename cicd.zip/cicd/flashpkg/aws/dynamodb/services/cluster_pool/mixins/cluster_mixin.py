import string
import random

from flashpkg.aws.dynamodb.models.model import ToClassObject
from flashpkg.infra import cluster as cluster_core
from flashpkg.aws.dynamodb.models.cluster_model import ClusterModel
from flashpkg.aws.dynamodb.models.cluster_locking_model import ClusterModelWithLock
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel
from flashpkg.config import config
from datetime import datetime

class CPClusterCreateMixin():
    def __init__(self):
        self.cluster_model = ClusterModel()
        self.cluster_model_locking = ClusterModelWithLock()
        self.cluster_pool_model = ClusterPoolModel()

    def __get_pool(self, pool_name):
        pool = self.cluster_pool_model.get(pool_name)
        if not pool:
            raise Exception(f"Cluster Pool `{pool_name}` doesn't exist ")
        return ToClassObject(**pool)

    def __get_unlocked_clusters(self, pool_name, flavor, region, zones):
        return self.cluster_model.get_all_unlocked_by_pool(pool_name, flavor, region, zones)

    def __save_new_cluster(self, name, flavor, region, zones, pool_name):
        self.cluster_model.upsert(name,
                                  locked=True,
                                  created_at=datetime.utcnow().isoformat(),
                                  locked_at=datetime.utcnow().isoformat(),
                                  flavor=flavor,
                                  region=region,
                                  zones=zones,
                                  ready=True,
                                  tenants=[],
                                  pool=pool_name
                                  )

    def __add_cluster(self, pool_name, logging_format=False, *args):
        new_cluster_name, flavor, region, zones, exit_code = self.__create_new_cluster(args, pool_name, logging_format)

        if exit_code == 0:
            self.__save_new_cluster(new_cluster_name, flavor, region, zones, pool_name)
            self.__update_pool_clusters(pool_name, new_cluster_name)
            return exit_code, new_cluster_name
        else:
            return exit_code, None

    def __update_pool_clusters(self, pool_name, new_cluster_name):
        pool_cluster_names = self.cluster_pool_model.get_cluster_names(pool_name)

        linked_clusters = [
            *pool_cluster_names,
            new_cluster_name
        ] if pool_cluster_names else [new_cluster_name]

        self.cluster_pool_model.update_cluster_names(
            pool_name,
            linked_clusters
        )

    def __generate_name(self, pool_name):
        prefix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        return f'{prefix}-{pool_name}-pool'

    def __create_new_cluster(self, args, pool_name, logging_format=False):
        (
            flavor_name,
            region,
            zones,
            cloud,
            multi_master,
            no_iam,
            save_config,
            dry_run
        ) = list(args)

        cluster_name = self.__generate_name(pool_name)

        try:
            exit_code = cluster_core.create(
                cluster_name=cluster_name,
                flavor_name=flavor_name,
                cloud=cloud,
                multi_master=multi_master,
                region=region,
                zones=zones,
                logging_format=logging_format,
                is_cluster_pool=True
            ) if not dry_run else 0

        except Exception as e:
            raise Exception('Exception occurred during creating') from e
        else:
            return cluster_name, flavor_name, region, zones, exit_code

    def __cluster_env_setup(self, cluster_name, region, external_cluster, logging_format):
        cluster_core.envsetup(
            cluster_name=cluster_name,
            region=region,
            external_cluster=external_cluster,
            logging_format=logging_format)

    def create_in_pool(self, pool_name, flavor, region=None, zones=None, logging_format=False, *args):
        flavor_config = config.get_flavor(flavor)
        if not flavor_config:
            raise Exception(f"No such flavor {flavor}")

        cluster_type = flavor_config.get('type')

        if not region:
            region = flavor_config.get('region')

        if not zones:
            zones = flavor_config.get('zone') or flavor_config.get('zones')

        unlocked_cluster = self.cluster_model_locking.get_first_unlocked(pool_name, flavor, region, zones)

        if not unlocked_cluster:
            return self.__add_cluster(pool_name, logging_format, flavor, region, zones, *args)
        else:
            self.__cluster_env_setup(
                cluster_name=unlocked_cluster,
                region=region,
                external_cluster=cluster_type,
                logging_format=logging_format
            )

            return 0, unlocked_cluster
