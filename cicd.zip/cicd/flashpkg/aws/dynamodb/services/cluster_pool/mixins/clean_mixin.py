from flashpkg.aws.dynamodb.models.cluster_model import ClusterModel, CLUSTER_NAME_ATTRIBUTE, CLUSTER_REGION_ATTRIBUTE, CLUSTER_FLAVOR_ATTRIBUTE
from flashpkg.config import config
from flashpkg.infra import cluster as cluster_core
from bullet import YesNo
from multiprocessing import Process

class CPCleanMixin():
    def __init__(self):
        self.cluster_model = ClusterModel()

    def __fetch_cluster_names(self, pool_name, period, all):
        clusters_to_remove = self.cluster_model.get_all_locked_by_pool(pool_name, period) if not all else self.cluster_model.get_all_by_pool(pool_name)

        if not clusters_to_remove:
            raise Exception('Nothing to remove!')

        return clusters_to_remove, list(map(lambda cls: cls[CLUSTER_NAME_ATTRIBUTE], clusters_to_remove))

    def __setup_and_remove(self, cluster):
        cluster_name = cluster.get(CLUSTER_NAME_ATTRIBUTE)
        cluster_region = cluster.get(CLUSTER_REGION_ATTRIBUTE)
        cluster_flavor = cluster.get(CLUSTER_FLAVOR_ATTRIBUTE)
        cluster_region = cluster.get(CLUSTER_REGION_ATTRIBUTE)

        flavor = config.get_flavor(cluster_flavor)
        if flavor:
            cluster_type = flavor.get("type").lower()

            cluster_core.envsetup(cluster_name, cluster_region, False, cluster_type)
            cluster_core.cleanup(cluster_name, region=cluster_region, external_cluster=cluster_type)
            self.cluster_model.delete(cluster_name)

    def __run_async(self, clusters):
        proc = []

        for cluster in clusters:
            p = Process(target=self.__setup_and_remove, args=(cluster,))
            p.start()
            proc.append(p)

        for p in proc:
            p.join()

    def __run(self, clusters):
        for cluster in clusters:
            self.__setup_and_remove(cluster)

    def __print_list(self, names):
        print('Clusters to remove:')
        indent = ' '
        for name in names:
            print(5*indent + name)

    def clean(self, pool_name, period, assume_yes=False, all=False):
        (clusters, names) = self.__fetch_cluster_names(pool_name, period, all)
        self.__print_list(names)

        status = assume_yes

        if not status:
            cli = YesNo("Do you wish to delete these clusters?")
            status = cli.launch()

        if status:
            self.__run_async(clusters)
            print(f'Cluster Pool {pool_name} successfully cleaned!')
        else:
            print("Nothing removed!")
