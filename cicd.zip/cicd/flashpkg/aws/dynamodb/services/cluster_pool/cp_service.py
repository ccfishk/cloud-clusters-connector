from flashpkg.aws.dynamodb.services.cluster_pool.mixins.release_mixin import CPClusterReleaseMixin
from flashpkg.aws.dynamodb.services.cluster_pool.mixins.cluster_mixin import CPClusterCreateMixin
from flashpkg.aws.dynamodb.services.cluster_pool.mixins.clean_mixin import CPCleanMixin

mixins = [
    CPClusterReleaseMixin,
    CPClusterCreateMixin,
    CPCleanMixin
]

class CPProxy:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

class CPService(CPProxy, *mixins):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
