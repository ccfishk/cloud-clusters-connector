import random
import string
from flashpkg.aws.dynamodb.models.cluster_pool_model import ClusterPoolModel, POOL_CLUSTER_NAMES_ATTRIBUTE, POOL_NAME_ATTRIBUTE
from flashpkg.aws.dynamodb.models.cluster_model import ClusterModel
from flashpkg.aws.dynamodb.models.cluster_model import CLUSTER_LOCKED_ATTRIBUTE, CLUSTER_LOCKED_AT_ATTRIBUTE, \
    CLUSTER_UNLOCKED_AT_ATTRIBUTE, CLUSTER_CREATED_AT_ATTRIBUTE, CLUSTER_NAME_ATTRIBUTE, CLUSTER_FLAVOR_ATTRIBUTE, \
    CLUSTER_REGION_ATTRIBUTE, CLUSTER_ZONES_ATTRIBUTE
from flashpkg.infra import cluster as cluster_core
from datetime import datetime
from dateutil.parser import parse
from flashpkg import nsxsm
from flashpkg.config import config

class ClusterPoolService():
    def update_cluster(self, cluster_name, **kwargs):
        cluster_model = ClusterModel()
        return cluster_model.update(cluster_name, **kwargs)

    def delete(self, pool_name):
        pool_model = ClusterPoolModel()
        clusters = pool_model.get_cluster_names(pool_name)

        if clusters:
            for cluster_name in clusters:
                cluster_model = ClusterModel()
                cluster = cluster_model.get_item_by_name(cluster_name)

                if cluster:
                    cluster_flavor = cluster.get('flavor')
                    flavor = config.get_flavor(cluster_flavor)
                    if flavor:
                        cluster_type = flavor.get("type").lower()

                        cluster_core.cleanup(cluster_name, region=cluster['region'], external_cluster=cluster_type)
                        cluster_model.delete(cluster_name)

                        pool_model.remove_cluster(pool_name, cluster_name)

        pool_model.delete(pool_name)

    def release(self, pool_name, cluster_name, is_eks):
        nsxsm.uninstall_allspark(cluster_name, is_eks)
        model = ClusterModel()
        model.unlock(cluster_name)

    def __calculate_duration(self, then):
        now = datetime.now()
        duration = now - then
        duration_seconds = duration.total_seconds()

        hours, seconds_left = divmod(duration_seconds, 3600)
        minutes = seconds_left / 60
        return int(hours), int(minutes)

    def __calculate_usage_age(self, locked, cluster_item):
        locked_at = cluster_item.get(CLUSTER_LOCKED_AT_ATTRIBUTE)

        if locked and not locked_at:
            return (0, 0)

        unlocked_at = cluster_item.get(CLUSTER_UNLOCKED_AT_ATTRIBUTE)
        if not locked and not unlocked_at:
            return (0, 0)

        then = parse(locked_at) if locked else parse(unlocked_at)
        return self.__calculate_duration(then)

    def __calculate_age(self, cluster_item):
        created_at = cluster_item.get(CLUSTER_CREATED_AT_ATTRIBUTE)
        if not created_at:
            return (0, 0)

        return self.__calculate_duration(parse(created_at))

    def list_full(self):
        result = []
        cluster_pool_model = ClusterPoolModel()
        items = cluster_pool_model.list()

        for item in items:
            if POOL_CLUSTER_NAMES_ATTRIBUTE in item:
                cluster_model = ClusterModel()
                clusters = cluster_model.get_all(item[POOL_CLUSTER_NAMES_ATTRIBUTE])

                for cluster_item in clusters:
                    tmp = [item[POOL_NAME_ATTRIBUTE], None, None, None, None, 0, 0, 0]
                    tmp[1] = cluster_item[CLUSTER_NAME_ATTRIBUTE]
                    tmp[2] = cluster_item[CLUSTER_FLAVOR_ATTRIBUTE]
                    tmp[3] = cluster_item[CLUSTER_REGION_ATTRIBUTE]
                    tmp[4] = cluster_item[CLUSTER_ZONES_ATTRIBUTE]

                    locked = cluster_item[CLUSTER_LOCKED_ATTRIBUTE]
                    tmp[5] = '-Busy' if locked else '+Free'

                    usage_hours, usage_minutes = self.__calculate_usage_age(locked, cluster_item)
                    tmp[6] = f'{usage_hours}h, {usage_minutes}m '

                    age_hours, age_minutes = self.__calculate_age(cluster_item)
                    tmp[7] = f'{age_hours}h, {age_minutes}m '

                    result.append(tmp)

        return result

    def list_short(self):
        result = []
        cluster_pool_model = ClusterPoolModel()
        items = cluster_pool_model.list()

        for item in items:
            tmp = [item[POOL_NAME_ATTRIBUTE], 0, 0]
            if POOL_CLUSTER_NAMES_ATTRIBUTE in item:
                cluster_model = ClusterModel()
                clusters = cluster_model.get_all(item[POOL_CLUSTER_NAMES_ATTRIBUTE])

                for cluster_item in clusters:
                    locked = cluster_item[CLUSTER_LOCKED_ATTRIBUTE]

                    if locked:
                        count = tmp[1] + 1
                        tmp[1] = count
                    else:
                        count = tmp[2] + 1
                        tmp[2] = count

            result.append(tmp)
        return result

    def cluster_env_setup(self, cluster_name, region, external_cluster):
        cluster_core.envsetup(cluster_name=cluster_name, region=region, external_cluster=external_cluster)

    def create_in_pool(self, pool_name, flavor, region=None, zones=None, *args):
        clusterPoolModel = ClusterPoolModel()
        pool = clusterPoolModel.get(pool_name)

        if pool is None:
            raise Exception(f"Pool with the name {pool_name} doesn't exist")

        flavor_config = config.get_flavor(flavor)
        if not flavor_config:
            raise Exception(f"No such flavor {flavor}")

        cluster_type = flavor_config.get('type')

        if not region:
            region = flavor_config.get('region')

        if not zones:
            zones = flavor_config.get('zone') or flavor_config.get('zones')

        unlocked_clusters = self.get_unlocked_clusters(pool_name, flavor, region, zones)
        if not unlocked_clusters:
            return self.__add_cluster(pool_name, flavor, region, zones, *args)
        else:
            unlocked_cluster = unlocked_clusters[0]
            cluster_name = unlocked_cluster[CLUSTER_NAME_ATTRIBUTE]

            self.cluster_env_setup(
                cluster_name=cluster_name,
                region=region,
                external_cluster=cluster_type
            )

            cluster = ClusterModel()
            cluster.lock(cluster_name)

            return 0, cluster_name

    def get_unlocked_clusters(self, pool_name, flavor, region, zones):
        model = ClusterModel()
        return model.get_all_unlocked_by_pool(pool_name, flavor, region, zones)

    def get_cluster_by_name(self, cluster_name):
        cluster_model = ClusterModel()
        return cluster_model.get_item_by_name(cluster_name)

    def __add_cluster(self, pool_name, *args):
        new_cluster_name, flavor, region, zones, exit_code = self.__create_new_cluster(args, pool_name)

        if exit_code == 0:
            self.__save_new_cluster(new_cluster_name, flavor, region, zones, pool_name)
            self.__update_pool_clusters(pool_name, new_cluster_name)
            return exit_code, new_cluster_name
        else:
            return exit_code, None

    def __generate_name(self, pool_name):
        prefix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
        return f'{prefix}-{pool_name}-pool'

    def __create_new_cluster(self, args, pool_name):
        (
            flavor_name,
            region,
            zones,
            cloud,
            multi_master,
            no_iam,
            save_config,
            logging_format
        ) = list(args)

        cluster_name = self.__generate_name(pool_name)

        try:
            exit_code = cluster_core.create(
                cluster_name=cluster_name,
                flavor_name=flavor_name,
                cloud=cloud,
                multi_master=multi_master,
                region=region,
                zones=zones,
                logging_format=logging_format,
                is_cluster_pool=True
            )
        except Exception as e:
            raise Exception('Exception occurred during creating') from e
        else:
            return cluster_name, flavor_name, region, zones, exit_code

    def __update_pool_clusters(self, pool_name, new_cluster_name):
        pool_model = ClusterPoolModel()
        pool_cluster_names = pool_model.get_cluster_names(pool_name)

        linked_clusters = [
            *pool_cluster_names,
            new_cluster_name
        ] if pool_cluster_names else [new_cluster_name]

        pool_model.update_cluster_names(
            pool_name,
            linked_clusters
        )

    def __save_new_cluster(self, name, flavor, region, zones, pool_name):
        cluster_model = ClusterModel()
        cluster_model.upsert(name,
                             locked=True,
                             created_at=datetime.utcnow().isoformat(),
                             locked_at=datetime.utcnow().isoformat(),
                             flavor=flavor,
                             region=region,
                             zones=zones,
                             ready=True,
                             tenants=[],
                             pool=pool_name
                             )
