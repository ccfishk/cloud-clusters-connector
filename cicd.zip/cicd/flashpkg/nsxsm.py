"""
Usage:
  flash nsxsm config apply <config_file_path> [--template_dir=<template_dir> --template_file=<template_file> --output_dir=<output_dir>] [--verbose]
  flash nsxsm install tenant <tenant_name> <saas_cluster_name> --username=<username> --password=<password> [--no-failure-rollback] [--eks] [--verbose | --logging-format=<logging-format>]
  flash nsxsm install tenants <num_tenants> <tenant_name_prefix> <saas_cluster_name> [--password=<password>] [--no-failure-rollback] [--verbose] [--eks]
  flash nsxsm install <nsxsm_version> <cluster_name> <ingress_dns> <api_dns> [--production --eks] [--node-isolation] [--verbose] [--restricted_cluster=<restricted_action_ack>]
  flash nsxsm install tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password> --eks] [--use-v1-api] [--verbose] [--use-board-api]
  flash nsxsm list backups <saas_cluster_name> [--eks] [--verbose]
  flash nsxsm list restores <saas_cluster_name> [--eks] [--verbose]
  flash nsxsm list tenants <saas_cluster_name> [--eks] [--verbose]
  flash nsxsm list tenant clusters <saas_cluster_name> <tenant_id> [--eks] [--verbose]
  flash nsxsm list tenant versions <saas_cluster_name> <tenant_id> [--eks] [--verbose]
  flash nsxsm restore tenant <saas_cluster_name> <tenant_id> <backup_name> [--eks] [--verbose]
  flash nsxsm logbundle <saas_cluster_name> [<namespace> --eks] [--verbose]
  flash nsxsm logbundle tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <log_type> [--namespace=<namespace>] <username> [--password=<password>] [--verbose]
  flash nsxsm init tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password> --eks] [--use-v1-api]
                                                                                                     [--tsm-version=<tsm_version>] [--verbose]
  flash nsxsm deinit tenant cluster <tenant_name> <saas_cluster_name> <client_cluster_name> <username> [--password=<password> --eks] [--use-v1-api] [--verbose]
  flash nsxsm uninstall tenant cluster <saas_cluster_name> <client_cluster_name> <username> [--password=<password> --eks] [--use-v1-api] [--verbose] [--use-board-api]
  flash nsxsm uninstall tenant <tenant_name> <saas_cluster_name> [--verbose]
  flash nsxsm uninstall <cluster_name> [--eks] [--verbose] [--restricted_cluster=<restricted_action_ack>]
  flash nsxsm upgrade saas <saas_cluster_name> <nsxsm_version> <config_file_path> [--force --eks --production] [--verbose] [--restricted_cluster=<restricted_action_ack>]
  flash nsxsm upgrade tenant <saas_cluster_name> <nsxsm_version> (<tenant_id> | --inventory_file=<inventory_file>) [--force --eks --batch=<batch> --logs_dir=<logs_dir>] [--verbose]

Description:
  flash nsxsm : commands to install and configure allspark services.

Options:
  --username=<username>                  User that is created under the tenant. This is used to login in non-CSP environments.
  --password=<password>                  Password to use for the user(s). Defaults to the username as displayed during provisioning.
  --template_dir=<template_dir>          Specifies the directory that holds templates to be modified.
  --template_file=<template_file>        Specifies the template file to be modified.
  --production                           Specifies large volume (500G) deployment size for production clusters
  --output_dir=<output_dir>              Specifies the output directory to use.
  --saas-domain-name=<saas_domain_name>  Specifies the domain name to use for secure communication with the Saas Cluster.
                                         If not specified, defaults to <cluster_name>-internal.servicemesh.biz
  --no-failure-rollback                  Overrides the de-registration of failed tenant, helpful in debugging.
  --node-isolation                       Enables tenant nodegroup isolation
  --use-v1-api                           Enables the usage of v1 APIs for operations
  --verbose                              Verbose output
  --use-board-api                        Use board API if SAAS upgraded
  --tsm-version=<tsm_version>            Specifies the version of TSM to install
"""
from docopt import docopt
import os
import shutil
import time
import docker
import tarfile
import socket
import requests
import tempfile
import urllib.parse
import yaml
import sys
import re
import pathlib
import traceback
from deprecation import deprecated
from concurrent.futures import ThreadPoolExecutor
from kubernetes import client, config
from kubernetes.client.rest import ApiException
from prettytable import PrettyTable
from flashpkg.aws import repo, dns
from flashpkg.infra import cluster, saas
from flashpkg.state import state
from flashpkg import utils, pks, logging, nsxsmOps
from tsm.platform import api, infra
from multiprocessing import Process, Manager
from distutils import dir_util
from contextlib import redirect_stdout, redirect_stderr
from flashpkg.aws.dynamodb.services import cluster_pool_service
from flashpkg.config import config as flavor_config
from flashpkg.platforms import tkgs


REPO_NAME = 'allspark-templates'
DEFAULT_PERIOD = 3.0  # 3 seconds
ALLSPARK_SAAS = '/bin/templates/apps/allspark-saas/'
ALLSPARK_TENANTS = '/bin/templates/apps/allspark-tenants/'
ALLSPARK_CONFIG_FILE = '/bin/templates/apps/allspark-cloud-config.yaml'
STAGE00 = 'stage-00'
STAGE01 = 'stage-01'
STAGE02 = 'stage-02'
STAGE03 = 'stage-03'
KOPS_CLIENT_NETWORKING = 'calico'
INGRESS_GATEWAY = 'istio-ingressgateway'
DEFAULT_BATCH_SIZE = 10
verbose_flag = False

def get_container_files(cont, file_path, temp_dir):
    """Get files from container as a tarball"""
    TAR_FILE = temp_dir + '/' + file_path.split('/')[-1] + '.tar'
    strm, _ = cont.get_archive(file_path)
    with open(TAR_FILE, 'wb') as f:
        for chunk in strm:
            f.write(chunk)

def extract_tar_file(temp_dir, file_path):
    """Extract a local tar file contents"""
    file_name = file_path.split('/')[-1] + '.tar'
    tar = tarfile.open(temp_dir + '/' + file_name)
    tar.extractall(temp_dir)
    tar.close()

def extract_files(version, platform_area):
    """Extract config files from an image"""
    repo.login(REPO_NAME)
    repo_url = repo.url(REPO_NAME)
    image = repo_url + ':' + version
    client = docker.from_env()
    img = client.images.pull(image)
    cont = client.containers.create(img)
    temp_dir = tempfile.mkdtemp()
    paths = [ALLSPARK_CONFIG_FILE, platform_area+STAGE00, platform_area+STAGE01, platform_area+STAGE02, platform_area+STAGE03]
    for name in paths:
        try:
            get_container_files(cont, name, temp_dir)
            extract_tar_file(temp_dir, name)
        except docker.errors.NotFound:
            print("{} not found in release container, skipping".format(name))
    cont.remove()
    client.images.remove(image=image, force=True)
    return temp_dir

def cleanup(temp_dir):
    """Cleanup temporary director"""
    if temp_dir:
        shutil.rmtree(temp_dir)

def add_or_remove_component(cluster_name, component_name, temp_dir, context, filename=None, uninstall=False):
    """Install specified component to cluster"""
    if uninstall:
        operand = 'delete'
    else:
        operand = 'apply'

    if filename:
        for f in sorted(os.listdir(temp_dir + '/' + component_name)):
            if filename == f:
                f = filename
            if filename != f:
                continue

            cmd = ("kubectl --context %s %s -f %s/%s/%s --all") % (
                context, operand, temp_dir, component_name, f)
            print("Running:", cmd)
            (status, out) = utils.command(cmd, streaming=True)
            if (status != 0):
                print("Error performing %s %s on cluster %s: %s" % (
                      operand, component_name, cluster_name, out))
                return status
    else:
        cmd = ("kubectl --context %s %s -f %s/%s") % (
            context, operand, temp_dir, component_name)
        print("Running:", cmd)
        (status, out) = utils.command(cmd, streaming=True)
        if (status != 0):
            print("Error performing %s %s on cluster %s: %s" % (
                  operand, component_name, cluster_name, out))
            return status
    return 0

def generate_runtime_config(saas_domain_name, saas_api_dns, skip_verify, eks_cluster_name=""):
    data = dict(SaasDomainName=saas_domain_name,
                SaasApiDomainName=saas_api_dns,
                ClusterDeploymentSkipVerify=skip_verify,
                EksClusterName=eks_cluster_name)
    return data


def display_pods(cluster_name, namespace=None, is_eks=False):
    """Display all pods with a given namespace in a cluster"""
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    if namespace:
        ret = v1.list_namespaced_pod(namespace)
    else:
        ret = v1.list_pod_for_all_namespaces(watch=False)
    print("Namespace\tStatus\t\tName")
    for i in ret.items:
        print("%s\t%s\t\t%s" % (i.metadata.namespace, i.status.phase,
                                i.metadata.name))

def delete_namespace(cluster_name, namespace, is_eks=False):
    """Delete namespace from cluster"""
    print("Deleting namespace %s from cluster %s" % (
          namespace, cluster_name))
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    return v1.delete_namespace(namespace)

def delete_namespaced_deployments(context, namespace):
    """Delete all deployments in a namespace"""
    config.load_kube_config(context=context)
    v1 = client.ExtensionsV1beta1Api()
    try:
        ret = v1.list_namespaced_deployment(namespace)
        for i in ret.items:
            v1.delete_namespaced_deployment(i.metadata.name, namespace, body=client.V1DeleteOptions(
                propagation_policy='Foreground',
                grace_period_seconds=5
            ))

        if nsxsmOps.wait_for_deployment_deletion(namespace) == "FAILURE":
            return 1

    except ApiException as e:
        print("Exception when trying to delete deployment in namespace {}: {}".format(namespace, e))
        return 1
    return 0

def configure_network_policies(context):
    """Add/update labels for specific namespace and apply network policies to operator namespace"""
    body = {"metadata": {"labels": {"name": utils.ISTIO_NAMESPACE}}}
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    try:
        # Use force to override any pre-existing labels
        v1.patch_namespace(utils.ISTIO_NAMESPACE, body)
        print("Namespace {} labeled.".format(utils.ISTIO_NAMESPACE))
    except ApiException as e:
        print("Unable to label namespace {} with error: {}".format(utils.ISTIO_NAMESPACE, e))
        return 1
    return 0

def wait_for_cluster_ready(api, client_cluster):
    """Get client cluster status using graphql queries"""
    cluster_ready = False
    count = 20
    subquery = "{root { inventory { clusters(name: \"%s\") { name connected domains { name } } } } }" % (client_cluster)
    query = {"fetchPolicy": "network-only", "variables": {}, "query": subquery}
    try:
        while not cluster_ready and count > 0:
            r = api.get_client_clusters(query)
            assert r.status_code == 200
            if len(r.json()['data']['root']['inventory']['clusters']) > 0:
                # Always take the first element from the list
                c = r.json()['data']['root']['inventory']['clusters'][0]
                if c['connected'] and len(c['domains']) > 0:
                    table = PrettyTable()
                    table.field_names = ["Cluster Name", "Domain"]
                    for domain in c["domains"]:
                        table.add_row([client_cluster, domain['name']])
                    print(table)
                    cluster_ready = True
                    break
            count -= 1
            time.sleep(15)
        if not cluster_ready and count == 0:
            return 1
        return 0
    except Exception as e:
        print("Unable to query client information: ", str(e))

def wait_api_for_with_status(api, cluster_name, status):
    end_time = time.time() + 60
    while time.time() < end_time:
        resp = api.get_cluster(cluster_name)

        if resp.status_code == 404:
            print(f'Cluster  {cluster_name} not connected')
            return 1

        if resp.status_code != 200:
            error_message = resp.json().get('message')
            print(f"Error during get cluster: {error_message}")
            return 1

        if resp.json().get('status') and resp.json().get('status').get('state') == status:
            return 0

    return 1

def wait_for_with_status(cluster_name, namespace, statuses,
                         num_pods, timeout_in_seconds, context=None,
                         period_in_seconds=DEFAULT_PERIOD,
                         pod_name=None, is_eks=False):
    """Wait until condition is met"""
    if not context:
        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)

    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        count = 0
        ret = v1.list_namespaced_pod(namespace)
        for i in ret.items:
            if pod_name is None:
                if i.status.phase in statuses:
                    count += 1
            else:
                if re.search(pod_name, i.metadata.name) and \
                        i.status.phase in statuses:
                    count += 1
        if count == num_pods:
            return 0
        time.sleep(period_in_seconds)
    if pod_name:
        print("Timed out waiting for pod %s in state %s with %s namespace in cluster %s" % (
              pod_name, str(statuses), namespace, cluster_name))
    else:
        print("Timed out waiting for %d pods in state %s with %s namespace in cluster %s" % (
              num_pods, str(statuses), namespace, cluster_name))
        ret = v1.list_namespaced_pod(namespace)
        for i in ret.items:
            print("%s -- %s" % (i.metadata.name, i.status.phase))
    return 1

def create_namespace_secret(cluster_name, namespace, secret_name, key, cert, is_eks=False):
    """Create a namespace secret using a private key and cert"""
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    metadata = {'name': secret_name, 'namespace': namespace}
    data = {'tls.crt': cert.decode('utf-8'), 'tls.key': key.decode('utf-8')}
    body = client.V1Secret('v1', data, 'Secret', metadata,
                           type='kubernetes.io/tls')

    try:
        v1.create_namespaced_secret(namespace, body)
        return 0
    except ApiException as e:
        if e.status == 409:
            print("Secret %s already exists in namespace %s, skipping creation" % (secret_name, namespace))
            return 0

        print("Exception when calling CoreV1Api->create_namespaced_secret: %s\n" % e)
        return 1

def wait_for_services(cluster_name, namespace, statuses, timeout_in_seconds,
                      period_in_seconds=DEFAULT_PERIOD, is_eks=False):
    """Wait until condition is met"""
    if verbose_flag:
        print("wait_for_services")
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    end_time = time.time() + timeout_in_seconds
    pods_ready = False
    bad_pods = []
    good_pods = []
    while time.time() < end_time:
        ret = v1.list_namespaced_pod(namespace)
        bad_pods = []
        good_pods = []
        for i in ret.items:
            if i.status.phase not in statuses:
                bad_pods.append(i.metadata.name)
                pods_ready = False
                break
            else:
                pods_ready = True
                good_pods.append(i.metadata.name)
        if pods_ready:
            if verbose_flag:
                print('pods ok')
                print(good_pods)
            return 0
        time.sleep(period_in_seconds)
    print("Timed out waiting for pods in state %s with %s namespace in cluster %s" % (
        str(statuses), namespace, cluster_name))
    print('pods ok')
    print(good_pods)
    print('pods not ok')
    print(bad_pods)
    return 1


def wait_for_crds(context, count, timeout_in_seconds, period_in_seconds=DEFAULT_PERIOD):
    """Wait until CRD count equals or exceeds"""
    cmd = ["kubectl", "--context", context, "get", "crds"]
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        crd_cnt = 0
        (status, out) = utils.command(cmd)
        assert status == 0, 'Failed to get CRDs for cluster'
        for lines in out.splitlines():
            if 'istio.io' in lines:
                crd_cnt += 1
        if crd_cnt >= count:
            return 0
        time.sleep(period_in_seconds)
    print("Timed out waiting for %d CRDs" % (count))
    return 1

def wait_for_dns(dns, timeout_in_seconds, period_in_seconds=DEFAULT_PERIOD):
    """Verify if the API GW can be DNS resolved"""
    end_time = time.time() + timeout_in_seconds
    while time.time() < end_time:
        try:
            socket.getaddrinfo(dns, 443)
            return 0
        except Exception:
            pass
        time.sleep(period_in_seconds)
    print("Timed out waiting for {} to be resolved".format(dns))
    return 1

def display_istio_services(api, cluster_name):
    """Display istio services running on the target cluster"""
    cluster_data = api.get_services(cluster_name)
    if cluster_data:
        table = PrettyTable()
        table.field_names = ["Domain", "Service Name"]
        domains = cluster_data.get("domains")
        for domain in domains or []:
            if domain["name"] == 'istio-system':
                services = domain["services"]
                for service in services:
                    table.add_row([domain["name"], service["name"]])
        print(table)


def install_istio(cluster_name, context, temp_dir, upgrade=False):
    try:
        if 'istio.yaml' in sorted(os.listdir(temp_dir + '/' + STAGE01)):
            print("\nInstalling Istio CRDs\n")
            assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio-crds.yaml') == 0, "Failed to install Allspark Saas Stage01 components"
            assert wait_for_crds(context, 23, 60) == 0, 'Failed to validate CRDs in cluster'
            print("\nInstalling Istio\n")
            assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio.yaml') == 0, "Failed to install Allspark Saas Stage01 components"
        else:
            with open(temp_dir + '/' + STAGE01 + '/istio-operator.yaml') as yf:
                istio_operator = yaml.safe_load(yf)
            istio_version = istio_operator["spec"]["tag"]
            pwd = os.getcwd()
            cmd = "git clone --branch istio-1-6-14 https://gitlab.eng.vmware.com/nsx-allspark_users/allspark-istio-deployment.git " + temp_dir + "/allspark-istio-deployment"
            (r, out) = utils.command(cmd, streaming=True)
            assert r == 0, "Failed to download allspark-istio-deployment repo"
            os.chdir(temp_dir + "/allspark-istio-deployment/istio-v" + istio_version)
            if upgrade:
                cmd = ["sh", "./istio-upgrade.sh", "-c", context, "-d"]
                (r, out) = utils.command(cmd, streaming=True, lex=False)
                assert r == 0, "Istio upgrade failed"
            else:
                cmd = ["sh", "./istio-install.sh", "-c", context]
                (r, out) = utils.command(cmd, streaming=True, lex=False)
                assert r == 0, "Istio install failed"
            os.chdir(pwd)
        return 0
    except AssertionError as e:
        print("Failed to install/upgrade istio: " + str(e))
        return 1


def install_allspark_components(cluster_name, context, temp_dir, ingress_dns, api_dns, upgrade=False):
    dns_setup = False
    with ThreadPoolExecutor() as executor:
        stage00 = executor.submit(add_or_remove_component, cluster_name, STAGE00, temp_dir, context)
        print("\nInstalling Allspark SaaS stage 00\n")
        assert stage00.result() == 0, "Failed to install Allspark Saas Stage00 components"

    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    assert install_istio(cluster_name, context, temp_dir, upgrade) == 0, "Istio installation failed"

    assert configure_network_policies(context) == 0, "Failed to configure network policies for Saas cluster"
    assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio_policies.yaml') == 0, "Failed to apply policies to istio-system namespace"
    total_pods_in_istio_system = len(v1.list_namespaced_pod('istio-system').items)
    assert wait_for_with_status(cluster_name, 'istio-system', ['Running', 'Succeeded'],
                                total_pods_in_istio_system, 600, None, DEFAULT_PERIOD) == 0, 'Istio installation timedout'

    istio_gw = infra.get_lb(cluster_name, 'istio-system', 600, INGRESS_GATEWAY, context=context)
    if not istio_gw:
        print('Failed to obtain Istio routing gateway')
        return 1

    with ThreadPoolExecutor() as executor:
        if not upgrade:
            print("\nSetting up ingress DNS\n")
            idns = executor.submit(setup_dns, ingress_dns, istio_gw)
            wildcardIDns = executor.submit(setup_dns, "*." + ingress_dns, istio_gw)

            print("\nGenerating self signed certificate for the ingress gateway\n")
            certificate = executor.submit(utils.generate_self_signed_cert, ingress_dns)

        print("\nInstalling stage 02 of allspark\n")
        stage02 = executor.submit(add_or_remove_component, cluster_name, STAGE02, temp_dir, context)

        # For upgrades delete the deployments in operator namespace
        if upgrade:
            print("\nDeleting existing deployments in {} namespace\n".format(utils.OPERATOR_NAMESPACE))
            assert delete_namespaced_deployments(context, utils.OPERATOR_NAMESPACE) == 0

        print("\nInstalling stage 03 of allspark\n")
        stage03 = executor.submit(add_or_remove_component, cluster_name, STAGE03, temp_dir, context)
        if not upgrade:
            gw = executor.submit(infra.get_lb, cluster_name, utils.OPERATOR_NAMESPACE, 600, 'global-api-gateway', context=context)
            gw_result = gw.result()  # Bubble up potential exception before moving forward
            gwdns = executor.submit(setup_dns, api_dns, gw_result)
            gw_readiness = executor.submit(wait_for_dns, gw_result, 600)

            assert idns.result() == 0, 'Failed to create Ingress DNS entry {}'.format(ingress_dns)
            assert wildcardIDns.result() == 0, "Failed to create wildcard Ingress DNS entry {}".format(ingress_dns)
            dns_setup = True
            key, cert = certificate.result()

            executor.submit(create_namespace_secret, cluster_name, 'istio-system', 'istio-ingressgateway-certs', key, cert)
            assert gwdns.result() == 0, 'Failed to create API DNS entry {}'.format(api_dns)
            print("\nWaiting for ingress DNS to be ready\n")
            assert gw_readiness.result() == 0, "Failed waiting for the API gateway DNS to be ready"

        assert stage02.result() == 0, "Failed to install Allspark Saas Stage02 components"
        assert stage03.result() == 0, "Failed to install Allspark Saas Stage03 components"

    # Check running pods: registration, api-gateway, allspark-ui
    with ThreadPoolExecutor() as executor:
        regsvc = executor.submit(wait_for_with_status, cluster_name, utils.OPERATOR_NAMESPACE, ['Running'], 1, 60, context=context, pod_name='global-registration-service')
        gw = executor.submit(wait_for_with_status, cluster_name, utils.OPERATOR_NAMESPACE, ['Running'], 1, 60, context=context, pod_name='global-api-gateway')
        ui = executor.submit(wait_for_with_status, cluster_name, utils.OPERATOR_NAMESPACE, ['Running'], 1, 60, context=context, pod_name='allspark-ui')
        assert regsvc.result() == 0, "Global registration service is not healthy"
        assert gw.result() == 0, "Global API gateway is not healthy"
        assert ui.result() == 0, "UI is not healthy"

    return 0, istio_gw, dns_setup

def deinit_tenant_cluster(arg):
    tenant_name = arg['<tenant_name>']
    saas_cluster_name = arg['<saas_cluster_name>']
    client_cluster_name = arg['<client_cluster_name>']
    username = arg['<username>']
    password = arg['--password']
    is_eks = arg['--eks']
    tenant_id = None
    if not password:
        password = username

    cluster = get_cluster(cluster_name=saas_cluster_name)
    if not cluster:
        raise Exception("Saas cluster {} does not exist".format(saas_cluster_name))
    for _, item in enumerate(cluster['tenants']):
        if tenant_name == item['tenant_name']:
            tenant_id = item['tenant_id']
    if not tenant_id:
        raise Exception("Tenant {} not found in cluster {}".format(tenant_name, saas_cluster_name))
    try:
        api_session = api.setup(saas_cluster_name, username=username, password=password)
        assert api_session is not None, 'Failed to setup API session'
        r = api_session.istio('uninstall', client_cluster_name)
        assert r.status_code == 200

        # TODO: this check should be removed once https://jira.eng.vmware.com/browse/AS-5871 is addressed.
        context = nsxsmOps.generate_context(client_cluster_name, is_eks=is_eks)
        config.load_kube_config(context=context)
        v1 = client.CoreV1Api()
        while True:
            try:
                v1.read_namespace("istio-system")
                time.sleep(3)
            except ApiException:
                return 0

        return 1
    except AssertionError as e:
        print("Failed to de-init tenant successfully: " + str(e))
        return 1

def apply_runtime_config(config_file_path, tmpl_dir=None, tmpl_file=None, out_dir=None):
    try:
        with open(config_file_path) as yf:
            runtime_conf = yaml.safe_load(yf)
            print("Using config file: {}".format(config_file_path))
    except FileNotFoundError:
        print('Config file was not found at the requested location: {} or unable to read file.'.format(config_file_path))
        return 1

    return utils.apply_template(runtime_conf, template_dir=tmpl_dir, template_file=tmpl_file, output_dir=out_dir)


# FIXME: a lot of the below is duplicated from the DNS module.
def fetch_recordset_dns(cname_val):
    zones = dns.list_hosted_zones(output=False)
    assert len(zones) > 0, 'Unable to obtain DNS zones'
    # For now there should be only one zone
    zone_id = zones[0]['Id']
    record_sets = dns.list_resource_record_sets(zone_id, record_type='CNAME', output=False)

    for record in record_sets:
        if cname_val in record["ResourceRecords"] or []:
            record_name = record.get("Name")
            if record_name is None:
                raise Exception("Ho value for record name")

            record["Name"] = record_name.replace("\\052", "*")  # FIXME: totally duplicated from the DNS module.
            print("Validated that the record set exists for domain name: {}".format(record_name))
            return record_name

    raise Exception("Unable to find associated record set for the ELB: {}".format(cname_val))


def validate_zone(domain_name):
    zones = dns.list_hosted_zones(output=False)
    assert len(zones) > 0, 'Unable to obtain DNS zones'
    zone_name = zones[0]['Name'][:-1]
    if zone_name in domain_name:
        print("Valid domain name with associated hosted zone: {}".format(domain_name))
        return 0
    return 1


def setup_dns(domain_name, elb_url, create=True):
    zones = dns.list_hosted_zones(output=False)
    # For now there should be only one zone
    zone_id = zones[0]['Id']
    if create:
        ret = dns.create_cname_record_set(zone_id, domain_name, elb_url, True)
    else:
        ret = dns.delete_cname_record_set(zone_id, domain_name, elb_url)
    return ret

def is_cluster_from_pool(cluster):
    return cluster.get('from_pool')

def get_cluster(cluster_name):
    cluster = state.get_cluster(cluster_name=cluster_name)
    if not cluster:
        service = cluster_pool_service.ClusterPoolService()
        cluster = service.get_cluster_by_name(cluster_name)

        if cluster:
            cluster['from_pool'] = True
            cluster_flavor = cluster.get('flavor')
            flavor = flavor_config.get_flavor(cluster_flavor)
            if not flavor:
                raise Exception(f"No such flavor {cluster_flavor}")

            cluster['type'] = flavor.get("type").lower()
    return cluster

def update_pool_cluster(cluster_name, **kwargs):
    service = cluster_pool_service.ClusterPoolService()
    return service.update_cluster(cluster_name, **kwargs)


def install_allspark(arg):
    """Install specific Allspark version to a cluster"""
    version = arg['<nsxsm_version>']
    cluster_name = arg['<cluster_name>']
    ingress_dns = arg['<ingress_dns>']
    api_dns = arg['<api_dns>']
    production = arg['--production']
    is_eks = arg['--eks']
    isolation_enabled = arg.get('--node-isolation', False)
    dns_setup = False
    temp_dir = None
    res = 0
    ret = 0

    # Verify whether domain names can be associated with a hosted zone.
    print("Verifying that the ingress_dns and api_dns names can be associated with a hosted zone.")
    try:
        assert validate_zone(ingress_dns) == 0, "Route53 Hosted Zone was not found for requested domain name {}".format(ingress_dns)
        assert validate_zone(api_dns) == 0, "Route53 Hosted Zone was not found for requested domain name {}".format(api_dns)
    except AssertionError as e:
        print("Domain name validation failed. {}".format(e))
        return 1

    cluster = get_cluster(cluster_name=cluster_name)

    if not cluster:
        raise Exception("Cluster {} does not exist".format(cluster_name))

    # Restrict Saas to be only installed on KOPS and EKS clusters
    if cluster.get("type").lower() != "kops" and cluster.get("type").lower() != "eks":
        raise Exception("Cannot install Saas on cluster type {}".format(cluster.get("type").lower()))

    try:
        skip_verify = 'false'
        print("\nExtracting files from release {}\n".format(version))
        temp_dir = extract_files(version, ALLSPARK_SAAS)
        if production:
            print("Updating volume sizes to 500G for production deployment")
            status = utils.replace_config_parameter(temp_dir, '50Gi', '500Gi')
            if status == 0:
                print("Successfully updated volumes sizes to 500Gi")
            else:
                print("Failed to update volume sizes to 500Gi")

            print("Production cluster detected, setting skip_verify to {}".format(skip_verify))
        else:
            skip_verify = 'true'
            print("Non-production cluster detected, setting skip_verify to {}".format(skip_verify))

        eks_cluster_name = cluster_name if isolation_enabled else ''
        runtime_conf = generate_runtime_config(ingress_dns, api_dns, skip_verify, eks_cluster_name)
        ret = utils.apply_template(runtime_conf, template_dir=temp_dir)
        assert ret == 0, 'Failed to apply runtime config to deployment files'

        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)

        if isolation_enabled:
            ret = nsxsmOps.patch_aws_auth_roles(cluster_name, context,
                                                'allspark', 'reg-svc', ['system:masters'])
            assert ret == 0, 'Failed to patch aws roles'

        ret_code, istio_gw, dns_setup = install_allspark_components(cluster_name, context, temp_dir, ingress_dns, api_dns)
        assert ret_code == 0, 'Failed to install Allspark components'

        # Dump all the pods
        display_pods(cluster_name, 'istio-system', is_eks=is_eks)
        display_pods(cluster_name, utils.OPERATOR_NAMESPACE, is_eks=is_eks)
        cluster["nsxsm_version"] = version
        nsxsmOps.add_or_remove_instance_tag(cluster_name, cluster.get("type").lower(),
                                            cluster.get("region").lower(), utils.CID, ingress_dns, utils.ADD)

        if not is_cluster_from_pool(cluster):
            state.update_cluster(cluster)
        else:
            update_pool_cluster(cluster_name, nsxsm_version=version)

    except requests.HTTPError as e:
        print("Request failed: %s" % str(e))
        res = 1
    except AssertionError as e:
        print("Unable to install Allspark successfully: " + str(e))
        # Cleanup ingress DNS entry only if it were created
        if dns_setup:
            ret = setup_dns(ingress_dns, istio_gw, create=False)
            ret += setup_dns("*." + ingress_dns, istio_gw, create=False)
        if ret != 0:
            print("Failed to cleanup ingress DNS entries for domain {}".format(ingress_dns))
        res = 1
    except requests.ConnectionError as e:
        print("connection error. It's possible that docker is not running. {}".format(e))
        res = 1
    except Exception as e:
        print("Unexpected error during install: " + str(e))
        raise
    finally:
        cleanup(temp_dir)
    return res

@deprecated(details="This method deprecated")
def install_tenants(arg):
    name_prefix = arg['<tenant_name_prefix>']
    saas_cluster_name = arg['<saas_cluster_name>']
    password = arg['--password']
    no_failure_rollback = arg['--no-failure-rollback']

    # Perform some initial validations
    try:
        num_tenants = int(arg['<num_tenants>'])
    except ValueError:
        raise Exception("Invalid type for <num_tenants>. Expecting an integer value")
    # What range of values to accept here?
    if num_tenants < 1 or num_tenants > 100:
        raise Exception("<num_tenants> must be in the range 1-100")
    cluster = get_cluster(cluster_name=saas_cluster_name)
    if not cluster:
        raise Exception("Cluster {} does not exist".format(saas_cluster_name))

    api_session = api.setup(saas_cluster_name)
    tenant_id, name, username = None, None, None
    try:
        assert api_session is not None, 'Failed to setup API session'
        for i in range(1, num_tenants+1):
            if len(name_prefix) > 8:
                name_prefix = name_prefix[:8]
            name = '%s%02d' % (name_prefix, i)
            email = name + '@'
            print("Registering tenant with name {} and email {}".format(name, email))
            r_tenant = api_session.register_tenant(name, email, 'test', 'test', True)
            assert r_tenant is not None, 'Failed to make the async tenant registration request. HTTP request failed.'
            assert r_tenant.status_code == 200, 'Failed to register tenant {} using sync API with error {}:{}'.format(name, r_tenant.status_code, r_tenant.text)
            print("Tenant {} registered successfully".format(name))
            tenant_id = r_tenant.json()['id']
            username = 'testuser%s%03d' % (name_prefix, i)
            user_password = password if password else username
            r_user = api_session.create_user('testuser', name, '555-1212',
                                             'admin', username, user_password,
                                             username+'@example.web',
                                             tenant_id)
            assert r_user is not None, 'Failed to make the user creation request for the tenant {}. HTTP request failed'.format(tenant_id)
            assert r_user.status_code == 200, 'Failed to register user {} in tenant {} with error {}:{}'.format(username, name, r_user.status_code, r_user.text)
            print("User {} created successfully in tenant {}".format(username, name))

            assert wait_for_services(saas_cluster_name, tenant_id, ['Running', 'Succeeded'], 60) == 0
            assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'],
                                        1, 60, pod_name='stream-proxy') == 0
            assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'], 1,
                                        60, pod_name='stream-filter-backend') == 0
            tenant_data = {"tenant_name": name, "tenant_id": tenant_id, "username": username, "status": "Created"}
            cluster["tenants"].append(tenant_data)

            if is_cluster_from_pool(cluster):
                update_pool_cluster(saas_cluster_name, tenants=cluster['tenants'])
            else:
                state.update_cluster(cluster)

            print("Successfully provisioned tenant {} and user {}".format(name, username))
        return 0
    except AssertionError as e:
        print("Failed to provision tenants successfully: " + str(e))
        is_eks = arg['--eks']
        if tenant_id is not None:
            try:
                context = nsxsmOps.generate_context(saas_cluster_name, is_eks=is_eks)
                print("collecting log bundle for {} allspark".format(saas_cluster_name))
                nsxsmOps.collect_logbundle(saas_cluster_name, context, name_space='allspark')
                print("collecting log bundle for {} {}".format(saas_cluster_name, tenant_id))
                nsxsmOps.collect_logbundle(saas_cluster_name, context, name_space=tenant_id)

            except BaseException as err:
                print("unable to collect logs for {}".format(saas_cluster_name))
                print(err)

            if no_failure_rollback:
                print("Overriding un-registration of failed tenant. Please use flash to unregister the failed tenant.")
                tenant_data = {"tenant_name": name, "tenant_id": tenant_id, "username": username, "status": "Failed"}
                cluster["tenants"].append(tenant_data)

                if is_cluster_from_pool(cluster):
                    update_pool_cluster(saas_cluster_name, tenants=cluster['tenants'])
                else:
                    state.update_cluster(cluster)

            else:
                print("Cleaning up tenant {} and resources created during failed attempt.".format(tenant_id))
                r = api_session.unregister_tenant(tenant_id, True)
                if r is None:
                    print("Failed to unregister tenant {} using async API. HTTP request failed".format(tenant_id))
                elif r.status_code != 200:
                    print('Failed to unregister tenant {}  using async API with error {}:{}'.format(tenant_id, r.status_code, r.text))
        return 1

def install_tenant(arg):
    name = arg['<tenant_name>']
    saas_cluster_name = arg['<saas_cluster_name>']
    password = arg['--password']
    username = arg['--username']
    no_failure_rollback = arg['--no-failure-rollback']
    output = arg['--logging-format']

    log = logging.log(output)
    log_error = logging.log_error(output)

    cluster = get_cluster(cluster_name=saas_cluster_name)
    if not cluster:
        raise Exception("Cluster {} does not exist".format(saas_cluster_name))

    api_session = api.setup(saas_cluster_name, verbose=verbose_flag)
    assert api_session is not None, 'Failed to setup API session'

    tenant_id = None
    try:
        name = name[:8] if len(name) > 8 else name
        email = name + '@'
        r_tenant = api_session.register_tenant(name, email, 'test_address', 'test_company_size', True)
        assert r_tenant is not None, 'Failed to make the async tenant registration request. HTTP request failed.'
        assert r_tenant.status_code == 200, 'Failed to register tenant {} using sync API with error {}:{}'.format(name, r_tenant.status_code, r_tenant.text)
        log(f"Tenant {name} registered successfully")

        tenant_id = r_tenant.json()['id']
        r_user = api_session.create_user('testuser', name, '555-1212', 'admin', username, password,
                                         username+'@example.web', tenant_id)
        assert r_user is not None, 'Failed to make the user creation request for the tenant {}. HTTP request failed'.format(tenant_id)
        assert r_user.status_code == 200, 'Failed to register user {} in tenant {} with error {}:{}'.format(username, name, r_user.status_code, r_user.text)
        log(f"User {username} created successfully in tenant {name}")

        assert wait_for_services(saas_cluster_name, tenant_id, ['Running', 'Succeeded'], 60) == 0
        assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'],
                                    1, 60, pod_name='stream-proxy') == 0
        assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'], 1,
                                    60, pod_name='stream-filter-backend') == 0

        tenant_data = {
            "tenant_name": name,
            "tenant_id": tenant_id,
            "username": username,
            "status": "Created"
        }

        cluster["tenants"].append(tenant_data)

        if is_cluster_from_pool(cluster):
            update_pool_cluster(saas_cluster_name, tenants=cluster['tenants'])
        else:
            state.update_cluster(cluster)

        log(f"Successfully provisioned tenant {name} and user {username}")

        return (0, tenant_id)
    except AssertionError as e:
        base_error_msg = f"Failed to provision tenants successfully: {str(e)}"
        log(base_error_msg)

        is_eks = arg['--eks']

        if tenant_id is not None:
            try:
                context = nsxsmOps.generate_context(saas_cluster_name, is_eks=is_eks)

                log(f"collecting log bundle for {saas_cluster_name} allspark")
                nsxsmOps.collect_logbundle(saas_cluster_name, context, name_space='allspark', disable_output=bool(output))

                log(f"collecting log bundle for {saas_cluster_name} {tenant_id}")
                nsxsmOps.collect_logbundle(saas_cluster_name, context, name_space=tenant_id, disable_output=bool(output))

            except BaseException as err:
                err_msg = f"unable to collect logs for {saas_cluster_name}"
                log_error(f"{base_error_msg} \n {err_msg} \n {err}")

            if no_failure_rollback:
                log("Overriding un-registration of failed tenant. Please use flash to unregister the failed tenant.")
                tenant_data = {"tenant_name": name, "tenant_id": tenant_id, "username": username, "status": "Failed"}
                cluster["tenants"].append(tenant_data)

                if is_cluster_from_pool(cluster):
                    update_pool_cluster(saas_cluster_name, tenants=cluster['tenants'])
                else:
                    state.update_cluster(cluster)

                log_error(base_error_msg)
            else:
                log(f"Cleaning up tenant {tenant_id} and resources created during failed attempt.")
                r = api_session.unregister_tenant(tenant_id, True)

                if r is None:
                    log_error(f"{base_error_msg}\n Failed to unregister tenant {tenant_id} using async API. HTTP request failed")
                elif r.status_code != 200:
                    log_error(f'{base_error_msg}\n Failed to unregister tenant {tenant_id}  using async API with error {r.status_code}:{r.text}')
                else:
                    log_error(base_error_msg)

        return (1, None)

def collect_tenant_cluster_logs(arg):
    tenant_name = arg['<tenant_name>']
    saas_cluster_name = arg['<saas_cluster_name>']
    client_cluster_name = arg['<client_cluster_name>']
    log_type = arg['<log_type>']
    namespace = arg['--namespace']
    username = arg['<username>']
    password = arg['--password']
    if not password:
        password = username
    tenant_id = None

    cluster = get_cluster(cluster_name=saas_cluster_name)
    if not cluster:
        raise Exception("Saas cluster {} does not exist".format(saas_cluster_name))
    if not get_cluster(cluster_name=client_cluster_name):
        raise Exception("Client cluster {} does not exist".format(client_cluster_name))
    for _, item in enumerate(cluster['tenants']):
        if tenant_name == item['tenant_name']:
            tenant_id = item['tenant_id']
            break
    if not tenant_id:
        raise Exception("Tenant {} not found in cluster {}".format(tenant_name, saas_cluster_name))

    try:
        api_session = api.setup(saas_cluster_name, username=username, password=password)
        assert api_session is not None, 'Failed to setup API session'
        # What do we pass as the cluster type or should be assume this as kops
        client_cluster = get_cluster(cluster_name=client_cluster_name)
        r = api_session.fetch_logs(log_type, namespace, client_cluster_name, type=client_cluster.get("type").lower())
        assert r.status_code == 200, 'Failed to fetch client cluster logs'

        url = r.json().get('url')
        r = requests.get(url, stream=True)
        if r.status_code != 200:
            raise Exception('Failed to download {} logs at {}'.format(log_type, url))

        home = os.path.expanduser('~')
        url_parts = urllib.parse.urlparse(url)
        file_name = url_parts[2].rpartition('/')[2]
        log_file_path = os.path.join(home, file_name)
        with open(log_file_path, 'wb') as target:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, target)
        print('Saved {} logs from cluster {} to {}'.format(log_type, client_cluster_name, log_file_path))
        return 0
    except AssertionError as e:
        print('Failed to fetch client cluster logs: ' + str(e))
        return 1

def install_tenant_cluster(arg):
    ret = 0
    tenant_id = None
    tenant_name = arg['<tenant_name>']
    saas_cluster_name = arg['<saas_cluster_name>']
    client_cluster_name = arg['<client_cluster_name>']

    client_cluster = get_cluster(cluster_name=client_cluster_name)
    if not client_cluster:
        raise Exception("Client cluster {} does not exist".format(client_cluster_name))

    cluster = get_cluster(cluster_name=saas_cluster_name)
    username = arg['<username>']
    password = arg['--password']
    is_eks = arg['--eks']
    is_upgraded = arg['--use-board-api']
    if not password:
        password = username
    if not cluster:
        raise Exception("Saas cluster {} does not exist".format(saas_cluster_name))
    for _, item in enumerate(cluster['tenants']):
        if tenant_name == item['tenant_name']:
            tenant_id = item['tenant_id']
    if not tenant_id:
        raise Exception("Tenant {} not found in cluster {}".format(tenant_name, saas_cluster_name))
    fd1 = None
    cluster_yaml = None
    try:
        assert nsxsmOps.validate_cluster_type(
            client_cluster_name, KOPS_CLIENT_NETWORKING, flavor=client_cluster.get("type").lower()) == 0, "Cannot install on the client cluster"

        api_session = api.setup(saas_cluster_name, username=username, password=password)
        assert api_session is not None, 'Failed to setup API session'

        try:
            cluster_token = api_session.get_cluster_token(client_cluster_name, is_upgraded)
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 409:
                print("Cluster with name {} already registered for tenant {}, nothing to do".format(client_cluster_name, tenant_name))
                return 0  # TODO: clean up exit codes and keep them at the level of where commands are executed from the CLI.

            print("Failed to get cluster token: {}".format(e))
            return 1

        # The upsert cluster API doesn't return 409, but instead returns an empty token.
        if not cluster_token:
            print("Cluster with name {} already upserted for tenant {}, nothing to do".format(client_cluster_name, tenant_name))
            return 0  # TODO: clean up exit codes and keep them at the level of where commands are executed from the CLI.

        print("Getting cluster deployment yaml")
        r = api_session.get_cluster_agent_script(is_upgraded=is_upgraded)
        assert r.status_code == 200, 'Failed to obtain cluster installer YAML'
        fd1, cluster_yaml = tempfile.mkstemp()
        with open(cluster_yaml, 'w') as f:
            f.write(r.text)

        if is_upgraded:
            agent_ns = utils.AGENT_NAMESPACE
        else:
            agent_ns = utils.OPERATOR_NAMESPACE

        # FIXME: The PKS name no longer exists. This probably needs some updates.
        if client_cluster.get("type").lower() == 'pks':
            print("Installing PKS cluster {}".format(client_cluster_name))
            assert pks.upload_file(cluster_yaml, client_cluster_name+'.yaml') == 0, 'Failed to upload onboarding YAML to Jumper VM'
            cmd = "pks get-credentials %s" % (client_cluster_name)
            assert pks.execute_command(cmd) == 0, 'Failed to fetch credentials for PKS cluster'
            cmd = "kubectl --context %s apply -f %s.yaml" % (client_cluster_name, client_cluster_name)
            assert pks.execute_command(cmd) == 0, 'Failed to apply onboarding YAML to PKS cluster'

            print("Injecting token to cluster {}".format(client_cluster_name))
            cmd_tmpl = "kubectl --context %s -n %s create secret generic cluster-token --from-literal=token=%s"
            cmd = (cmd_tmpl) % (client_cluster_name, agent_ns, cluster_token)
            assert pks.execute_command(cmd) == 0, 'Failed to apply onboarding YAML to PKS cluster'
        elif client_cluster.get("type").lower() == 'tkgs':
            status = tkgs.apply_agent_script(client_cluster_name, agent_ns, r.text)
            assert status == 0, 'Failed to apply onboarding YAML'

            status = tkgs.create_secret(client_cluster_name, cluster_token, agent_ns)
            assert status == 0, 'Failed to create secret'

        else:
            context = nsxsmOps.generate_context(client_cluster_name, is_eks=is_eks)
            yaml_cmd = ("kubectl --context %s apply -f %s") % (context, cluster_yaml)
            secret_cmd_tmpl = "kubectl --context %s -n %s create secret generic cluster-token --from-literal=token=%s"
            secret_cmd = (secret_cmd_tmpl) % (context, agent_ns, cluster_token)
            (status, _) = utils.command(yaml_cmd, streaming=True)

            print("Installing cluster {}".format(client_cluster_name))
            assert status == 0, 'Failed to apply onboarding YAML'
            (status, _) = utils.command(secret_cmd, streaming=True)

            print("Injecting token to cluster {}".format(client_cluster_name))
            assert status == 0, 'Failed to create secret'
        cluster_hash = utils.get_cluster_hash(client_cluster_name)
        pod_pattern = '(' + client_cluster_name + '|' + cluster_hash + ')'

        assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'], 1,
                                    600, pod_name='k8s-connector-'+pod_pattern) == 0

        assert wait_for_with_status(saas_cluster_name, tenant_id, ['Running'], 1,
                                    600, pod_name='proxy-server-'+pod_pattern) == 0

        skip_verification_types = ['pks', 'cpks']
        if client_cluster.get("type").lower() in skip_verification_types:
            print("Skipping verification on PKS client cluster")
        elif client_cluster.get("type").lower() == 'tkgs':
            assert wait_api_for_with_status(api_session, client_cluster_name, 'Connected') == 0, f'Cluster {client_cluster_name} isn\'t connected'
        else:
            if is_upgraded:
                assert wait_for_with_status(client_cluster_name, agent_ns,
                                            ['Running', 'Succeeded'], 4, 320) == 0
            else:
                assert wait_for_with_status(client_cluster_name, agent_ns,
                                            ['Running', 'Succeeded'], 3, 160) == 0
        assert wait_for_cluster_ready(api_session, client_cluster_name) == 0, 'Timed out waiting for {} to be in READY state'.format(client_cluster_name)
    except AssertionError as e:
        print("Failed to install tenant cluster successfully: " + str(e))
        ret = 1
    finally:
        if fd1:
            os.close(fd1)
        if cluster_yaml:
            os.remove(cluster_yaml)
    return ret

def uninstall_tenant_cluster(arg):
    ret = 0
    saas_cluster_name = arg['<saas_cluster_name>']
    client_cluster_name = arg['<client_cluster_name>']  # Don't I need the client_cluster here too?
    username = arg['<username>']
    password = arg['--password']
    is_eks = arg['--eks']
    is_upgraded = arg['--use-board-api']
    cluster = get_cluster(cluster_name=saas_cluster_name)
    client_cluster = get_cluster(cluster_name=client_cluster_name)
    if not password:
        password = username
    fd2 = None
    cluster_yaml = None

    if not cluster:
        raise Exception("Saas cluster {} does not exist".format(saas_cluster_name))
    if not client_cluster:
        raise Exception("Client cluster {} does not exist".format(client_cluster_name))
    try:

        # Unregister from the SaaS first to work around https://jira.eng.vmware.com/browse/AS-5890
        # Once CLM is in place and we remove the state machine from the API gateway the order of when this is done should not matter.
        api_session = api.setup(saas_cluster_name, username=username, password=password)
        assert api_session is not None, 'Failed to setup API session'
        print("Unregistering cluster {} from SaaS".format(saas_cluster_name))
        r = api_session.delete_cluster(client_cluster_name)
        if r.status_code == 404:
            print("Skipping cluster {} as it is not currently registered".format(client_cluster_name))
        else:
            assert r.status_code == 202, "Failed to unregister cluster: {} {}".format(r.status_code, r.reason)

        print("Getting cluster deployment yaml")
        r = api_session.get_cluster_agent_script(is_upgraded=is_upgraded)
        assert r.status_code == 200, 'Failed to obtain cluster uninstaller YAML'
        fd2, cluster_yaml = tempfile.mkstemp()
        with open(cluster_yaml, 'w') as f:
            f.write(r.text)

        if is_upgraded:
            agent_ns = utils.AGENT_NAMESPACE
        else:
            agent_ns = utils.OPERATOR_NAMESPACE

        if client_cluster.get("type").lower() == 'pks':
            print("Uninstalling PKS cluster {}".format(client_cluster_name))
            assert pks.upload_file(cluster_yaml, client_cluster_name+'.yaml') == 0, 'Failed to upload onboarding YAML to Jumper VM'
            cmd = "pks get-credentials %s" % (client_cluster_name)
            assert pks.execute_command(cmd) == 0, 'Failed to fetch credentials for PKS cluster'

            print("Deleting cluster components from {}".format(client_cluster_name))
            cmd = "kubectl --context %s delete -f %s.yaml --ignore-not-found=true" % (client_cluster_name, client_cluster_name)
            assert pks.execute_command(cmd) == 0, 'Failed to delete onboarding YAML on PKS cluster'
        elif client_cluster.get("type").lower() == 'tkgs':
            print("Deleting cluster components from {}".format(client_cluster_name))
            status = tkgs.delete_agent_script(client_cluster_name, agent_ns, r.text)
            assert status == 0, 'Failed to delete onboarding YAML on TKG-S cluster'
            assert wait_api_for_with_status(api_session, client_cluster_name, 'Connected') != 0, f'Cluster {client_cluster_name} still connected'
        else:
            context = nsxsmOps.generate_context(client_cluster_name, is_eks=is_eks)
            print("Deleting cluster components from {}".format(client_cluster_name))
            cmd = ("kubectl --context %s delete -f %s --ignore-not-found=true") % (context, cluster_yaml)
            (status, _) = utils.command(cmd, streaming=True)
            assert status == 0, 'Failed to delete onboarding YAML'

            assert wait_for_with_status(client_cluster_name, agent_ns,
                                        ['Running', 'Succeeded'], 0, 60) == 0

    except Exception as e:
        print("Failed to uninstall tenant cluster successfully: " + str(e))
        ret = 1
    finally:
        if fd2:
            os.close(fd2)
        if cluster_yaml:
            os.remove(cluster_yaml)
    return ret

def init_tenant_cluster(arg):
    tenant_name = arg['<tenant_name>']
    saas_cluster_name = arg['<saas_cluster_name>']
    client_cluster_name = arg['<client_cluster_name>']
    username = arg['<username>']
    password = arg['--password']
    if not password:
        password = username
    tenant_id = None

    cluster = get_cluster(cluster_name=saas_cluster_name)
    if not cluster:
        raise Exception("Saas cluster {} does not exist".format(saas_cluster_name))
    if not get_cluster(cluster_name=client_cluster_name):
        raise Exception("Client cluster {} does not exist".format(client_cluster_name))
    for _, item in enumerate(cluster['tenants']):
        if tenant_name == item['tenant_name']:
            tenant_id = item['tenant_id']
    if not tenant_id:
        raise Exception("Tenant {} not found in cluster {}".format(tenant_name, saas_cluster_name))

    try:
        api_session = api.setup(saas_cluster_name, username=username, password=password)
        assert api_session is not None, 'Failed to setup API session'
        r = api_session.istio('install', client_cluster_name, tsm_version=arg['--tsm-version'])
        assert r.status_code == 200, 'Failed to install tenant cluster'
        return 0
    except AssertionError as e:
        print("Failed to init tenant successfully: " + str(e))
        return 1

def __clean_dns_entry(cluster_name, namespace, service, context):
    gw = infra.get_lb(cluster_name, namespace, 60, service, context=context)
    try:
        dns = fetch_recordset_dns(gw)
    except Exception as e:
        raise Exception("Failed to fetch record set") from e

    if service == INGRESS_GATEWAY:  # FIXME: restructure this func so we don't have to do this.

        # FIXME: this shouldn't return an exit code.
        ret = setup_dns("*." + dns, gw, create=False)
        assert ret == 0, "Failed to delete wildcard gateway DNS entry for {}: {}".format(service, dns)

    # FIXME: this shouldn't return an exit code.
    ret = setup_dns(dns, gw, create=False)
    assert ret == 0, 'Failed to delete gateway DNS entry for {}: {}'.format(service, dns)


@deprecated(details="This method deprecated")
def uninstall_allspark(cluster_name, is_eks):
    res = 0
    cluster = get_cluster(cluster_name=cluster_name)
    if not cluster:
        raise Exception("Cluster {} does not exist".format(cluster_name))

    istio_ns = "istio-system"
    allspark_ns = "allspark"
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    v1 = client.CoreV1Api()
    try:
        v1.read_namespace(allspark_ns)
    except ApiException:
        print("%s namespace not found, nothing to do" % allspark_ns)
        return res

    # Take out all existing tenants first, otherwise this will leave the system in a broken state.
    # E.g. tenant services will be running with sidecars when there's no Istio installed.
    # E.g. all state about tenants will have been wiped out as this is stored in the DB in the allspark namespace.
    tenants = cluster.get("tenants")
    print("Uninstalling existing tenants before uninstalling allspark")

    # TODO: these tenant uninstalls should be done in parallel and joined on at the end.
    # We can't do this yet since the registration service is using old/unmaintained Go data model code.
    # That code has many races throughout it and has a few known cache corruption issues.
    # Revisit this once our Go stuff is in better shape.
    for tenant in tenants:
        tenant_name = tenant.get("tenant_name")
        print("Uninstalling tenant %s" % tenant_name)
        tenant_ret = uninstall_tenant({
            "<tenant_name>": tenant.get("tenant_name"),
            "<saas_cluster_name>": cluster_name
        })
        if tenant_ret != 0:
            print("Failed to uninstall tenant %s" % tenant_name)
            print("Couldn't uninstall all tenants before uninstalling allspark, halting")
            return tenant_ret

    try:
        print("Cleaning DNS entries associated with SAAS cluster")
        istio_gw = infra.get_lb(cluster_name, istio_ns, 60, INGRESS_GATEWAY, context=context)
        try:
            ingress_dns = fetch_recordset_dns(istio_gw)
        except Exception as e:
            print("Failed to fetch record set: {}".format(e))
            return 1

        executor = ThreadPoolExecutor()
        ingress_removal = executor.submit(__clean_dns_entry, cluster_name, istio_ns, INGRESS_GATEWAY, context)
        api_removal = executor.submit(__clean_dns_entry, cluster_name, utils.OPERATOR_NAMESPACE, 'global-api-gateway', context)

        # TODO: currently the Istio CRDs are not uninstalled correctly. Some extra work needed to handle this case.
        if 'nsxsm_version' in cluster:
            # We know the version and istio type, uninstall Istio the recommended way
            temp_dir = extract_files(cluster['nsxsm_version'], ALLSPARK_SAAS)
            # no module use api dns when uninstall
            runtime_conf = generate_runtime_config(ingress_dns, '', 'false')
            ret = utils.apply_template(runtime_conf, template_dir=temp_dir)
            assert ret == 0, 'Failed to apply runtime config to deployment files'
            assert add_or_remove_component(cluster_name, STAGE03, temp_dir, context, uninstall=True) == 0
            assert add_or_remove_component(cluster_name, STAGE02, temp_dir, context, uninstall=True) == 0

            # Istio 1.6.X and later have different install/uninstall process
            # if 'istio.yaml' is present, then istio version is 1.3.0 else if istio-operator.yaml is present the version is 1.6 or greater.
            if 'istio.yaml' in sorted(os.listdir(temp_dir + '/' + STAGE01)):
                assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio.yaml', uninstall=True) == 0
                assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio_policies.yaml',
                                               uninstall=True) == 0
                # Do not assert on this yet as the image may not have the istio deletion crds
                add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio-delete-crds.yaml',
                                        uninstall=True) == 0
            elif 'istio-operator.yaml' in sorted(os.listdir(temp_dir + '/' + STAGE01)):
                assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio-manifest.yaml', uninstall=True) == 0
                assert add_or_remove_component(cluster_name, STAGE01, temp_dir, context, filename='istio_policies.yaml',
                                               uninstall=True) == 0

            assert add_or_remove_component(cluster_name, STAGE00, temp_dir, context, filename='allspark_setup.yaml', uninstall=True) == 0
            add_or_remove_component(cluster_name, STAGE00, temp_dir, context, uninstall=True)
        else:
            # Else do the old way
            delete_namespace(cluster_name, istio_ns)
            delete_namespace(cluster_name, utils.OPERATOR_NAMESPACE)

        end_time = time.time() + 100
        for ns in [istio_ns, allspark_ns]:
            while time.time() < end_time:
                try:
                    api_res = v1.read_namespace_status(ns)
                    print("Namespace %s is still in %s phase, waiting until it's fully deleted" % (ns, api_res.status.phase))
                except ApiException:
                    break
                time.sleep(3)

        if "nsxsm_version" in cluster:
            del(cluster["nsxsm_version"])
        if "istio_type" in cluster:
            del(cluster["istio_type"])
        nsxsmOps.add_or_remove_instance_tag(cluster_name, cluster.get("type").lower(),
                                            cluster.get("region").lower(), utils.CID, ingress_dns, utils.DELETE)

        # Bubble up potential exceptions from the assert calls.
        ingress_removal.result()
        api_removal.result()

        if not is_cluster_from_pool(cluster):
            state.update_cluster(cluster)

        print("Allspark components uninstalled from cluster {}".format(cluster_name))

    except ApiException as e:
        print("Error when deleting namespace from cluster: {}".format(e))
        res = 1
    except AssertionError as e:
        print("Unable to uninstall Allspark: {}".format(e))
        res = 1
    except Exception as e:
        print("Unexpected error during uninstall: {}".format(e))
        raise
    return res


def uninstall_tenant(arg):
    tenant_name = arg['<tenant_name>']
    cluster_name = arg['<saas_cluster_name>']
    cluster = get_cluster(cluster_name=cluster_name)
    tenant_id = None
    del_idx = None
    res = 0
    if not cluster:
        raise Exception("Cluster {} does not exist".format(cluster_name))
    for idx, item in enumerate(cluster['tenants']):
        if tenant_name == item['tenant_name']:
            tenant_id = item['tenant_id']
            del_idx = idx
    if not tenant_id:
        print("Tenant {} not found for cluster {} in the state file".format(tenant_name, cluster_name))
        print("Proceeding with tenant deletion using ID {}".format(tenant_name))
        tenant_id = tenant_name
    try:
        api_session = api.setup(cluster_name)
        assert api_session is not None, 'Failed to setup API session'
        r = api_session.unregister_tenant(tenant_id, True)
        assert r.status_code == 200, 'Failed to unregister tenant {} using async API with error {}:{}'.format(tenant_name, r.status_code, r.text)
        assert wait_for_with_status(cluster_name, tenant_id, ['Running'], 0, 120) == 0
        if del_idx:
            del cluster['tenants'][del_idx]

            if is_cluster_from_pool(cluster):
                update_pool_cluster(cluster_name, tenants=cluster['tenants'])
            else:
                state.update_cluster(cluster)

        print("Tenant {} unregistered successfully".format(tenant_name))
    except AssertionError as e:
        print("Unable to unregister tenant {}: {}".format(tenant_name, str(e)))
        return 1
    return res

@deprecated(details="This method deprecated")
def process_list_tenants(arg):
    saas.list_tenants(arg)

def list_clusters(cluster_name, namespace, is_eks):
    """Display all clusters and their corresponding hashes for a given tenant"""
    saas_cluster = get_cluster(cluster_name=cluster_name)
    if not saas_cluster:
        if is_eks:
            cluster.envsetup(cluster_name, external_cluster='eks')
        else:
            cluster.envsetup(cluster_name, external_cluster='kops')
    try:
        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
        config.load_kube_config(context=context)
        v1_client = client.CoreV1Api()
        config_map_list = v1_client.list_namespaced_config_map(namespace=namespace)
        table = PrettyTable()
        table.field_names = ["Cluster Name", "Cluster Hash"]
        for cfg_map in config_map_list.items:
            if 'k8s-connector' in cfg_map.metadata.name:
                cluster_name = None
                cluster_hash = None
                cfgmap_data = yaml.load(cfg_map.data['.allsparkconf'], Loader=yaml.CLoader)
                try:
                    base_key = ('services', 'local', 'k8sConnector')
                    for k in base_key:
                        cfgmap_data = cfgmap_data[k]
                    if cfgmap_data['clusterName']:
                        cluster_name = cfgmap_data['clusterName']
                    if cfgmap_data['clusterNameHash']:
                        cluster_hash = cfgmap_data['clusterNameHash']
                except TypeError as e:
                    print("Failed to parse configmap: {}".format(e))
                except KeyError as e:
                    print("Failed to parse configmap: {}".format(e))
                if cluster_name and cluster_hash:
                    table.add_row([cluster_name, cluster_hash])
                else:
                    print("Unable to get cluster data for {}: {} {}".format(cfg_map.metadata.name, cluster_name, cluster_hash))
        print(table)
        return 0
    except ApiException as err:
        print("Exception when calling CoreV1Api: {}".format(err))
        print("Failed to list cluster name and hash")
        return 1


def list_service_versions(cluster_name, namespace, is_eks=False, return_object=False, context_set=False):
    """Display all service versions for a given namespace in a cluster"""
    saas_cluster = get_cluster(cluster_name=cluster_name)
    if not saas_cluster and not context_set:
        if is_eks:
            cluster.envsetup(cluster_name, external_cluster='eks')
        else:
            cluster.envsetup(cluster_name, external_cluster='kops')
    try:
        context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
        config.load_kube_config(context=context)
        v1beta = client.ExtensionsV1beta1Api()
        v1 = client.CoreV1Api()
        ret = v1beta.list_namespaced_deployment(namespace)
        if len(ret.items) > 0:
            print("Tenant ID: {}".format(namespace))
            t = PrettyTable(['Service Name', 'Release Version', 'Version'])
            svc_list = []
            for i in ret.items:
                if "etcd" not in i.metadata.name:
                    for c in i.spec.template.spec.containers:
                        if c.name in i.metadata.name:
                            image = c.image
                            version = image.split(':')[1]
                            r = v1.read_namespaced_config_map(c.name, namespace)
                            details = r.data['.allsparkconf']
                            allspark_version = re.search('allsparkVersion: (.*)', details).group(1)
                    t.add_row([i.metadata.name, allspark_version, version])
                    tup = (i.metadata.name, i.spec.template.metadata.labels.get("app"), version)
                    svc_list.append(tup)
            if return_object is True:
                return svc_list
            print(t)
            return 0
        else:
            print("No services found for tenant {}".format(namespace))
            if return_object:
                return None
            return 1
    except Exception as e:
        print("Unable to list tenant services: ", str(e))

def upgrade_operator(arg):
    cluster_name = arg['<saas_cluster_name>']
    nsxsm_version = arg['<nsxsm_version>']
    force_update = arg['--force']
    is_eks = arg['--eks']
    production = arg['--production']
    config_file = arg['<config_file_path>']
    namespace = "allspark"

    cluster = get_cluster(cluster_name=cluster_name)
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)

    temp_dir_saas = extract_files(nsxsm_version, ALLSPARK_SAAS)
    print("Extracted files are here: {}".format(temp_dir_saas))
    try:
        status, changelist = nsxsmOps.check_major_version_upgrade(cluster_name, namespace, force_update, is_eks, temp_dir_saas)
        assert status == 0, "Function check_major_version_upgrade returned non-zero status code"
    except AssertionError as err:
        print("Upgrade operator failed {}".format(err))
        return 1
    print("Upgrading operator {} to Allspark release version: {}".format(namespace, nsxsm_version))

    assert apply_runtime_config(config_file,
                                tmpl_dir=temp_dir_saas) == 0, 'Failed to apply runtime config on extract release package'
    if production:
        print("Updating volume sizes to 500G for production deployment")
        status = utils.replace_config_parameter(temp_dir_saas, '50Gi', '500Gi')
        if status == 0:
            print("Successfully updated volumes sizes to 500Gi")
        else:
            print("Failed to update volume sizes to 500Gi")

    ret_code, _, _ = install_allspark_components(cluster_name, context, temp_dir_saas, None, None, upgrade=True)
    assert ret_code == 0, 'Failed to upgrade Operator namespace to version {}'.format(nsxsm_version)
    if cluster:
        cluster["nsxsm_version"] = nsxsm_version

        if is_cluster_from_pool(cluster):
            update_pool_cluster(cluster_name, nsxsm_version=nsxsm_version)
        else:
            state.update_cluster(cluster)

    return 0

def __get_batched_tenants(tenantlist, batch=DEFAULT_BATCH_SIZE):
    for i in range(0, len(tenantlist), batch):
        yield tenantlist[i:i + batch]

def __get_tenantlist_from_file(tenantlist_file_path):
    with open(tenantlist_file_path) as tl:
        tenantlist = tl.read().splitlines()
        print("Using tenant list in file : {}".format(tenantlist_file_path))
        return tenantlist

def __validate_tenantlist(tenantlist, cluster_name, is_eks):
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)
    api = client.CoreV1Api()
    all_tenant_set = set([tenant.metadata.name for tenant in api.list_namespace(label_selector="component=nsxsm-tenant").items])
    upgrade_tenant_set = set(tenantlist)
    invalid_tenants = upgrade_tenant_set.difference(all_tenant_set)
    valid_tenants = upgrade_tenant_set & all_tenant_set
    return list(invalid_tenants), list(valid_tenants)

def batch_upgrade_tenants(arg):
    tenantlist_file_path = arg['--inventory_file']
    nsxsm_version = arg['<nsxsm_version>']
    cluster_name = arg['<saas_cluster_name>']
    batch_str = arg['--batch']
    is_eks = arg['--eks']
    log_location = arg['--logs_dir']
    if not batch_str:
        batch = DEFAULT_BATCH_SIZE
    else:
        batch = int(batch_str)

    if not log_location:
        log_location = tempfile.gettempdir()
    else:
        try:
            pathlib.Path(log_location).mkdir(parents=True, exist_ok=True)
        except FileExistsError as e:
            print("Failed to create logs-dir {} , a file exists with same name: {}".format(log_location, str(e)))
            raise

    tenantlist = __get_tenantlist_from_file(tenantlist_file_path)
    invalid_tenants, valid_tenants = __validate_tenantlist(tenantlist, cluster_name, is_eks)
    if len(invalid_tenants) > 0:
        print("Ignoring invalid tenants in input tenantfile for batched upgrade: {}".format(invalid_tenants))
    batched_tenantlist = __get_batched_tenants(valid_tenants, batch)
    kube_manifest_path = extract_files(nsxsm_version, ALLSPARK_TENANTS)
    print("Extracted files are here: {}".format(kube_manifest_path))

    manager = Manager()
    success_tenant_list = manager.list()
    failed_tenant_list = manager.list()

    for batch in batched_tenantlist:
        jobs = []
        for tenant in batch:
            tenant_temp_dir = tempfile.mkdtemp(prefix=tenant)
            dir_util.copy_tree(kube_manifest_path, tenant_temp_dir)
            proc = Process(target=__upgrade_tenant_wrapper, args=(arg, tenant_temp_dir, tenant, success_tenant_list, failed_tenant_list, log_location), name=tenant + "-proc")
            jobs.append(proc)

        print("Updating the following batch of tenants: {}".format(batch))
        for j in jobs:
            j.start()

        for j in jobs:
            j.join()

    print("Upgrade attempted for {} tenants".format(len(valid_tenants)))
    print("Upgrade successful for following {} tenants: \n {}".format(len(success_tenant_list), success_tenant_list))
    print("Upgrade failed for following {} tenants: \n {}".format(len(failed_tenant_list), failed_tenant_list))
    if len(failed_tenant_list) > 0:
        return 1
    else:
        return 0

def __upgrade_tenant_wrapper(arg, kube_manifest_path, namespace, success_tenant_list, failed_tenant_list, log_location=None):
    tenant_logfile = os.path.join(log_location, namespace + "-upgrade.logs")
    upgrade_status = 1
    with open(tenant_logfile, 'w') as log:
        with redirect_stdout(log), redirect_stderr(log):
            try:
                upgrade_status = upgrade_tenant(arg, kube_manifest_path, namespace)
            except Exception as e:
                traceback.print_exc()
                print("Failed to upgrade tenant {}: {} ".format(namespace, str(e)))
                upgrade_status = 1

    if upgrade_status == 0:
        success_tenant_list = success_tenant_list.append(namespace)
        print("Tenant {} upgraded successfully".format(namespace))
    else:
        failed_tenant_list = failed_tenant_list.append(namespace)
        print("Tenant {} failed upgrade, check logs {}".format(namespace, tenant_logfile))


def upgrade_tenant(arg, kube_manifest_path, namespace):
    cluster_name = arg['<saas_cluster_name>']
    nsxsm_version = arg['<nsxsm_version>']
    force_update = arg['--force']
    is_eks = arg['--eks']

    v1_client = client.CoreV1Api()

    try:
        status, changelist = nsxsmOps.check_major_version_upgrade(cluster_name, namespace, force_update, is_eks, kube_manifest_path, context_set=True)
        assert status == 0, "Function check_major_version_upgrade returned non-zero status code"
    except AssertionError as err:
        print("Upgrade tenant operation failed {}".format(err))
        return 1
    print("Upgrading tenant {} to Allspark release version: {}".format(namespace, nsxsm_version))
    print("Updating ConfigMaps...")
    try:
        cfgmap_patch_status, cfgmap_patch_obj = nsxsmOps.patch_config_map_all(namespace, kube_manifest_path)
        assert cfgmap_patch_status != 1, "Function patch_config_map_all returned non-zero status code"
    except AssertionError as err:
        print("Patching configMaps failed {}".format(err))
        return 1

    print("Updating Services...")
    try:
        svc_patch_status, svc_patch_obj = nsxsmOps.handle_service_updates(v1_client, namespace, kube_manifest_path,
                                                                          cfgmap_patch_obj)
        assert svc_patch_status != 1, "Function handle_service_updates returned non-zero status code."
    except AssertionError as err:
        print("Updating services failed {}".format(err))
        return 1

    print("Updating deployments...")
    try:
        dep_update_status = nsxsmOps.handle_deployment_updates(
            v1_client, cluster_name, namespace, kube_manifest_path, nsxsm_version, changelist, cfgmap_patch_obj,
            svc_patch_obj, is_eks)
        assert dep_update_status != 1, "Function handle_deployment_updates returned non-zero status code."
    except AssertionError as err:
        print("Updating deployments failed {}".format(err))
        return 1

    print("Tenant {} has been successfully upgraded to NSXSM release version: {}".format(namespace, nsxsm_version))
    return 0

def process_upgrade(arg):
    cluster_name = arg['<saas_cluster_name>']
    is_eks = arg['--eks']
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)
    config.load_kube_config(context=context)

    if arg['saas']:
        if cluster.restricted_cluster_check(cluster_name, arg) == 0:
            return 1
        return upgrade_operator(arg)
    elif arg['tenant']:
        if arg['<tenant_id>']:
            namespace = arg['<tenant_id>']
            nsxsm_version = arg['<nsxsm_version>']
            kube_manifest_path = extract_files(nsxsm_version, ALLSPARK_TENANTS)
            print("Extracted files are here: {}".format(kube_manifest_path))
            return upgrade_tenant(arg, kube_manifest_path, namespace)
        elif arg['--inventory_file']:
            return batch_upgrade_tenants(arg)

def process_install(arg):
    if arg['tenant']:
        if arg['cluster']:
            return install_tenant_cluster(arg)
        else:
            output = arg['--logging-format']

            if output and (output not in ('json')):
                sys.stderr.write(f"Format {output} not supported\n")
                sys.stderr.write(__doc__)
                sys.exit(1)

            log_result = logging.log_result(output)

            code, tenant_id = install_tenant(arg)

            if code == 0:
                log_result({"tenant_id": tenant_id})
            return code

    elif arg['tenants']:
        return install_tenants(arg)
    else:
        if cluster.restricted_cluster_check(arg['<cluster_name>'], arg) == 0:
            return 1
        return install_allspark(arg)

def process_uninstall(arg):
    if arg['tenant']:
        if arg['cluster']:
            return uninstall_tenant_cluster(arg)
        else:
            return uninstall_tenant(arg)
    else:
        if cluster.restricted_cluster_check(arg['<cluster_name>'], arg) == 0:
            return 1

        cluster_name = arg['<cluster_name>']
        is_eks = arg['--eks']
        return uninstall_allspark(cluster_name, is_eks)

def process_logbundle(arg):
    if arg['tenant'] and arg['cluster']:
        return collect_tenant_cluster_logs(arg)
    else:
        print('This method deprecated')
        return saas.logbundle(arg)

def process_list(arg):
    if arg['versions']:
        return list_service_versions(arg['<saas_cluster_name>'], arg['<tenant_id>'], is_eks=arg['--eks'])
    elif arg['clusters']:
        return list_clusters(arg['<saas_cluster_name>'], arg['<tenant_id>'], arg['--eks'])
    else:
        print('This method deprecated')
        return process_list_tenants(arg)

def process_backup_restore(arg):
    cluster_name = arg['<saas_cluster_name>']
    is_eks = arg['--eks']
    context = nsxsmOps.generate_context(cluster_name, is_eks=is_eks)

    if nsxsmOps.is_tool(utils.VELERO):
        if arg['backups']:
            print('This method deprecated')
            return nsxsmOps.list_backup_restore(cluster_name, context)
        if arg['restores']:
            print('This method deprecated')
            return nsxsmOps.list_backup_restore(cluster_name, context, operation='restore')
        elif arg['restore']:
            return nsxsmOps.restore_tenant(cluster_name, arg['<tenant_id>'], arg['<backup_name>'], context)
        else:
            raise Exception("Unknown command")
    else:
        print("Velero executable not found in system path.")
        print("Please install velero before attempting this command.")
        return 1

def process():
    # If no matching sub commands are specified then make sure we show the full help output.
    if len(sys.argv) == 2:
        sys.argv.append('-h')
    args = docopt(__doc__)

    if args['--verbose']:
        global verbose_flag
        verbose_flag = True

    if args['init']:
        return init_tenant_cluster(args)
    elif args['config']:
        config_file_path = args['<config_file_path>']
        tmpl_dir = args.get("--template_dir")
        tmpl_file = args.get("--template_file")
        out_dir = args.get("--output_dir")
        return apply_runtime_config(config_file_path, tmpl_dir=tmpl_dir, tmpl_file=tmpl_file, out_dir=out_dir)
    elif args['upgrade']:
        return process_upgrade(args)
    elif args['deinit']:
        return deinit_tenant_cluster(args)
    elif args['install']:
        return process_install(args)
    elif args['backups'] or args['restore'] or args['restores']:
        return process_backup_restore(args)
    elif args['list']:
        return process_list(args)
    elif args['logbundle']:
        return process_logbundle(args)
    elif args['uninstall']:
        return process_uninstall(args)
