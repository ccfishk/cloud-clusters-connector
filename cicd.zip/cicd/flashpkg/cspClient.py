from flashpkg import cspAuth
from flashpkg.state import state
import http.client
import json


def createClient(clientDef, useDeprecated=False):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "csp-auth-token": state.get_csp_access_token(),
        "Accept": "application/json",
        "Content-type": "application/json"
    }
    path = ''
    if (useDeprecated):
        path = '/csp/gateway/am/api/services/clients'
    else:
        path = '/csp/gateway/am/api/orgs/{}/oauth-apps'.format(state.get_csp_orgid())
    print(path)
    print(clientDef)
    conn.request(
        'POST', path,
        body=clientDef,
        headers=headers)
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not Create Client with data:' + clientDef)


def deleteClient(clientName, useDeprecated=False):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "application/json"
    }
    if useDeprecated:
        conn.request(
            'DELETE', '/csp/gateway/am/api/services/clients/' + clientName,
            headers=headers)
    else:
        conn.request(
            'DELETE',
            '/csp/gateway/am/api/orgs/{}/oauth-apps'.format(state.get_csp_orgid()),
            body=json.dumps({
                'clientIdsToDelete': [
                    clientName
                ]
            }),
            headers=headers
        )
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not Delete Client ' + clientName)

def getClient(clientName, useDeprecated=False):
    conn = http.client.HTTPSConnection(cspAuth.getCspUrl())
    headers = {
        "Accept": "application/json",
        "csp-auth-token": state.get_csp_access_token(),
        "Content-type": "application/json"
    }
    if useDeprecated:
        conn.request(
            'GET', '/csp/gateway/am/api/services/clients/' + clientName,
            headers=headers)
    else:
        conn.request(
            'GET',
            '/csp/gateway/am/api/orgs/{}/oauth-apps/{}'.format(state.get_csp_orgid(), clientName),
            headers=headers
        )
    resp = conn.getresponse()
    if resp.status != 200:
        print("ERROR: RESP status " + str(resp.status) + " Reason " + resp.reason)
        print("RESP DATA : " + str(resp.read()))
        raise Exception('Could not Get Client ' + clientName)
    dt = resp.read().decode('utf-8')
    jdt = json.loads(dt)
    return jdt
