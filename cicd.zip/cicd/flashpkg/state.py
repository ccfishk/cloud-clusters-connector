"""
Usage:
  flash state whoami
  flash state list clusters
  flash state list all clusters
  flash state list all users
  flash state delete cluster <cluster-name> <user-id>
  flash state delete cluster <cluster-name>
"""
from docopt import docopt
from datetime import datetime
from configobj import ConfigObj
from enum import Enum
from pkg_resources import resource_string
from flashpkg.aws.dynamo import Dynamo
from prettytable import PrettyTable
import flashpkg
import json
import fcntl
import sys
import os
import boto3
import traceback

class TMC(Enum):
    tmc = 'tmc'
    orgid = 'orgid'
    access_token = 'access-token'
    refresh_token = 'refresh-token'

class CSP(Enum):
    csp = 'csp'
    orgid = 'orgid'
    env = 'env'
    access_token = 'access-token'


class State(object):
    class Clusterkey():
        user_arn = 'user_arn'
        cluster_type = 'cluster_type'
        cluster_create_account = 'cluster_create_account'
        instance_type = 'instance_type'
        workers = 'workers'
        region = 'region'
        flavor = 'flavor'
        zones = 'zones'
        state = 'state'
        creation_time = 'creation_time'
        tools = 'tools'
        tools_k8s = 'k8s'

    def __init__(self):
        state_file = ''
        try:
            state_file = os.environ['ALLSPARK_FLASH_STATE']
        except Exception:
            pass
        if state_file is None or state_file == '':
            cfile = "/.flash.state.conf"
            home_cfg_file = os.environ['HOME'] + cfile
            if not os.path.exists(home_cfg_file):
                state_template = resource_string(__name__, ".flash.state.conf").decode("utf-8")
                with open(home_cfg_file, "w") as cfg_file:
                    cfg_file.write(state_template)

            state_file = home_cfg_file

        self.file = open(state_file, "r")
        self.state = ConfigObj(state_file, encoding='UTF8')
        self.__check_version()
        self.dynamo = Dynamo()
        try:
            self.dynamo.init()
        except Exception as err:
            print("Warning: Unable to init dynamo table")
            print(err)
            traceback.print_tb(err.__traceback__)
        if self.dynamo.isInitDone():
            self.__syncLocalStateToDynamo()

    def getLocalUser(self):
        uk = "Unknown"
        userName = os.environ.get("USER", uk)
        gitlabUser = os.environ.get("GITLAB_USER_EMAIL", uk)
        # other gitlab variable CI_PROJECT_NAME, CI_PIPELINE_ID, CI_COMMIT_SHA
        if userName == uk and gitlabUser != uk:
            return gitlabUser
        return userName

    def getAwsUser(self):
        try:
            response = boto3.client('sts').get_caller_identity()
            return response
        except Exception:
            print("Warning: Unable to get user IAM ARN.")
            return "Unknown"

    def __syncLocalStateToDynamo(self):
        userName = self.getLocalUser()
        user_arn = self.getAwsUser()["Arn"]
        awsAccount = user_arn.split(':')[4]
        if "infrastructure" in self.state and "clusters" in self.state["infrastructure"]:
            for clusterStr in self.state["infrastructure"]["clusters"]:
                try:
                    cluster = json.loads(clusterStr)
                    clusterName = cluster["name"]
                    if clusterName == "":
                        clusterName = "Unknown"
                    if cluster["ready"]:
                        clusterState = "Ready"
                    else:
                        clusterState = "NotReady"
                    account = awsAccount
                    if "org" in cluster:
                        account = cluster["org"]

                    self.dynamo.upsertItem(userName, clusterName, {
                        self.Clusterkey.user_arn: user_arn,
                        self.Clusterkey.cluster_create_account: account,
                        self.Clusterkey.cluster_type: cluster["type"],
                        self.Clusterkey.instance_type: cluster["instance_type"],
                        self.Clusterkey.workers: str(cluster["workers"]),
                        self.Clusterkey.region: cluster["region"],
                        self.Clusterkey.flavor: cluster["flavor"],
                        self.Clusterkey.zones: cluster["zones"],
                        self.Clusterkey.state: clusterState,
                        self.Clusterkey.creation_time: "-",
                        self.Clusterkey.tools: json.dumps({
                            self.Clusterkey.tools_k8s: cluster["version"]
                        })
                    })
                except Exception as err:
                    print("WARN: While trying to sync local flash state file to dynamo db")
                    print(err)
                    traceback.print_tb(err.__traceback__)

    def __del__(self):
        self.file.close()

    def __check_version(self):
        default_state = os.path.dirname(flashpkg.__file__) + "/.flash.state.conf"
        if not self.get_version():
            print("WARNING::State is missing version information, Please update it to match:", default_state)

        default_parsed = ConfigObj(default_state)
        if self.get_version() != default_parsed.get("version"):
            print("WARNING::State version {}:{} does not match {}:{}".format(
                self.get_version(), self.file.name,
                default_parsed.get("version"), default_state
            ))

    def __lock_file(f):
        def wrapper(*args, **kwargs):
            this = args[0]
            fcntl.flock(this.file, fcntl.LOCK_EX)
            try:
                this.state.reload()
                return f(*args, **kwargs)
            finally:
                fcntl.flock(this.file, fcntl.LOCK_UN)

        return wrapper

    def __get_clusters_section(self):
        return self.state["infrastructure"]["clusters"]

    def __get_clustergroups_section(self):
        return self.state["infrastructure"]["testbeds"]

    def file_name(self):
        return self.file.name

    @__lock_file
    def get_version(self):
        return self.state.get('version')

    @__lock_file
    def add_cluster(self, cluster):
        self.upsert_cluster_v2(cluster)
        clusters = self.__get_clusters_section()
        clusters.append(json.dumps(cluster))
        self.state.write()

    @__lock_file
    def add_clustergroup(self, clustergroup):
        clustergroups = self.__get_clustergroups_section()
        clustergroups.append(json.dumps(clustergroup))
        self.state.write()

    def update_cluster(self, cluster):
        self.upsert_cluster_v2(cluster)
        clusters = self.__get_clusters_section()
        for i, c in enumerate(clusters):
            current_cluster = json.loads(c)
            if cluster.get("name") == current_cluster.get("name"):
                del clusters[i]
                self.state.write()
        self.add_cluster(cluster)

    @__lock_file
    def remove_cluster(self, cluster_name):
        clusters = self.__get_clusters_section()
        for i, c in enumerate(clusters):
            cluster = json.loads(c)
            if cluster.get("name") == cluster_name:
                del clusters[i]

        self.state.write()
        # also remove from dynamo
        userName = self.getLocalUser()
        self.dynamo.deleteItem(userName, cluster_name)

    @__lock_file
    def remove_clustergroup(self, cluster_group_name):
        clustergroups = self.__get_clustergroups_section()
        for i, t in enumerate(clustergroups):
            clustergroup = json.loads(t)
            if clustergroup.get("cluster_group_name") == cluster_group_name:
                del clustergroups[i]

        self.state.write()

    @__lock_file
    def get_clusters(self, flavor_name=None, cluster_name=None, cluster_group_name=None, all=False):
        clusters = self.__get_clusters_section()
        for i, c in enumerate(clusters):
            cluster = json.loads(c)
            if all:
                yield cluster
            elif flavor_name and cluster.get("flavor") == flavor_name:
                yield cluster
            elif cluster_name and cluster.get("name") == cluster_name:
                yield cluster
            elif cluster_group_name and cluster.get("cluster_group_name") == cluster_group_name:
                yield cluster

    @__lock_file
    def get_clustergroups(self, testbed_name=None, cluster_group_name=None, all=False):
        clustergroups = self.__get_clustergroups_section()
        for i, t in enumerate(clustergroups):
            clustergroup = json.loads(t)
            if all:
                yield clustergroup
            elif testbed_name and clustergroup.get("testbed_name") == testbed_name:
                yield clustergroup
            elif cluster_group_name and clustergroup.get("cluster_group_name") == cluster_group_name:
                yield clustergroup

    @__lock_file
    def get_cluster(self, flavor_name=None, cluster_group_name=None, cluster_name=None):
        clusters = self.__get_clusters_section()
        for i, c in enumerate(clusters):
            cluster = json.loads(c)
            if flavor_name and cluster.get("flavor") == flavor_name:
                return cluster
            elif cluster_name and cluster.get("name") == cluster_name:
                return cluster
            elif cluster_group_name and cluster.get("cluster_group_name") == cluster_group_name:
                return cluster

    @__lock_file
    def get_clustergroup(self, testbed_name=None, cluster_group_name=None):
        clustergroups = self.__get_clustergroups_section()
        for i, t in enumerate(clustergroups):
            clustergroup = json.loads(t)
            if cluster_group_name and clustergroup.get("cluster_group_name") == cluster_group_name:
                return clustergroup
            elif testbed_name and clustergroup.get("testbed_name") == testbed_name:
                return clustergroup

    def get_cluster_v2(self, cluster_name):
        userName = self.getLocalUser()
        userTable = self.dynamo.loadUserTable(userName)
        if cluster_name in userTable:
            return userTable[cluster_name]
        return None

    def get_clusters_v2(self):
        userName = self.getLocalUser()
        return state.dynamo.loadUserTable(userName)

    def upsert_cluster_v2(self, cluster):
        userName = self.getLocalUser()
        user_arn = self.getAwsUser()["Arn"]
        awsAccount = user_arn.split(':')[4]
        clusterName = cluster["name"]
        if clusterName == "":
            clusterName = "Unknown"
        if cluster["ready"]:
            clusterState = "Ready"
        else:
            clusterState = "NotReady"
        account = awsAccount
        if "org" in cluster:
            account = cluster["org"]

        data = {
            self.Clusterkey.user_arn: user_arn,
            self.Clusterkey.cluster_create_account: account,
            self.Clusterkey.cluster_type: cluster["type"],
            self.Clusterkey.instance_type: cluster["instance_type"],
            self.Clusterkey.workers: str(cluster["workers"]),
            self.Clusterkey.region: cluster["region"],
            self.Clusterkey.flavor: cluster["flavor"],
            self.Clusterkey.zones: cluster["zones"],
            self.Clusterkey.state: clusterState,
            self.Clusterkey.creation_time: datetime.utcnow().isoformat(),
            self.Clusterkey.tools: json.dumps({
                self.Clusterkey.tools_k8s: cluster["version"]
            })
        }

        self.dynamo.upsertItem(userName, clusterName, data)

    def get_cluster_token(self, cluster_name):
        cluster = self.get_cluster(cluster_name)
        return cluster.get("token")

    @__lock_file
    def get_csp(self):
        if CSP.csp.value not in self.state:
            self.state[CSP.csp.value] = {}
        return self.state[CSP.csp.value]

    def get_csp_orgid(self):
        return self.get_csp()[CSP.orgid.value]

    def is_orgid_valid(self):
        csp = self.get_csp()
        return CSP.orgid.value in csp

    def is_env_valid(self):
        csp = self.get_csp()
        return CSP.env.value in csp

    @__lock_file
    def get_tmc(self):
        if TMC.tmc.value not in self.state:
            self.state[TMC.tmc.value] = {}
        return self.state[TMC.tmc.value]

    @__lock_file
    def set_tmc_orgid(self, orgid):
        tmc = self.get_tmc()
        tmc[TMC.orgid.value] = orgid
        self.state.write()

    @__lock_file
    def set_tmc_access_token(self, token):
        tmc = self.get_tmc()
        tmc[TMC.access_token.value] = token
        self.state.write()

    @__lock_file
    def set_tmc_refresh_token(self, token):
        tmc = self.get_tmc()
        tmc[TMC.refresh_token.value] = token
        self.state.write()

    @__lock_file
    def set_csp_orgid(self, orgid):
        csp = self.get_csp()
        csp[CSP.orgid.value] = orgid
        self.state.write()

    def get_csp_env(self):
        return self.get_csp()[CSP.env.value]

    @__lock_file
    def set_csp_env(self, e):
        csp = self.get_csp()
        csp[CSP.env.value] = e
        self.state.write()

    @__lock_file
    def set_csp_access_token(self, token):
        csp = self.get_csp()
        csp[CSP.access_token.value] = token
        self.state.write()

    def get_csp_access_token(self):
        csp = self.get_csp()
        return csp[CSP.access_token.value]

    def get_tmc_access_token(self):
        tmc = self.get_tmc()
        return tmc[TMC.access_token.value]

    def get_tmc_refresh_token(self):
        tmc = self.get_tmc()
        return tmc[TMC.refresh_token.value]

    def get_tmc_org_id(self):
        tmc = self.get_tmc()
        return tmc[TMC.orgid.value]

    def whoami(self):
        user = self.getAwsUser()
        localUser = self.getLocalUser()
        print(user)
        t = PrettyTable(['Local User Name', 'Aws User Name', 'UserArn'])
        t.add_row([localUser, user['UserName'], user["Arn"]])
        print(t)
        print()

    def listMyClusters(self):
        userName = self.getLocalUser()
        userTable = state.dynamo.loadUserTable(userName)
        t = PrettyTable(['Cluster Name', 'Type', 'State', 'Flavor', 'Instance Type', 'Workers', 'Region', 'Creation Time', 'Tool Version'])
        for key in userTable:
            dt = userTable[key]
            t.add_row([
                key,
                dt[self.Clusterkey.cluster_type], dt[self.Clusterkey.state], dt[self.Clusterkey.flavor], dt[self.Clusterkey.instance_type],
                dt[self.Clusterkey.workers], dt[self.Clusterkey.region], dt[self.Clusterkey.creation_time], dt[self.Clusterkey.tools]
            ])
        print(t)
        print()

    def listAllClusters(self):
        fullTable = state.dynamo.loadFullTable()
        t = PrettyTable(['User Name', 'user_arn', 'Cluster Name', 'Type', 'State', 'Flavor', 'Instance Type', 'Workers', 'Region', 'Creation Time', 'Tool Version'])
        for user in fullTable:
            userTable = fullTable[user]
            for key in userTable:
                dt = userTable[key]
                t.add_row([
                    user,
                    dt[self.Clusterkey.user_arn],
                    key,
                    dt[self.Clusterkey.cluster_type], dt[self.Clusterkey.state],
                    dt[self.Clusterkey.flavor], dt[self.Clusterkey.instance_type],
                    dt[self.Clusterkey.workers], dt[self.Clusterkey.region],
                    dt[self.Clusterkey.creation_time], dt[self.Clusterkey.tools]
                ])
        print(t)
        print()

    def listClustersGroupedByUsers(self):
        fullTable = state.dynamo.loadFullTable()
        t = PrettyTable(['User Name', 'Number of Clusters', 'Number of Nodes'])
        for user in fullTable:
            userTable = fullTable[user]
            clusterCnt = 0
            nodeCnt = 0
            for key in userTable:
                dt = userTable[key]
                clusterCnt += 1
                nodeCnt += int(dt[self.Clusterkey.workers])
            t.add_row([user, clusterCnt, nodeCnt])
        print(t)
        print()

    def deleteState(self, clusterName, userName):
        if userName is None or userName == "":
            userName = self.getLocalUser()
        self.dynamo.deleteItem(userName, clusterName)


state = State()


def process():
    if len(sys.argv) == 2:
        sys.argv.append('-h')
    args = docopt(__doc__)
    if args['whoami']:
        return state.whoami()
    if args['list']:
        if args['all'] and args['clusters']:
            return state.listAllClusters()
        if args['all'] and args['users']:
            return state.listClustersGroupedByUsers()
        if args['clusters']:
            return state.listMyClusters()
    if args['delete'] and args['cluster']:
        return state.deleteState(args['<cluster-name>'], args['<user-id>'])
