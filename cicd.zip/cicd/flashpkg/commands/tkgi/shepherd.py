import sys
import re
import io
import shlex
import subprocess
import json
import yaml
from shutil import which
from flashpkg.commands.tkgi.errors import PrerequisitesError, ShepherdError
from flashpkg.logging import log, log_error

class Shepherd:
    def __init__(self, namespace, logging_format=None):
        self.ctl = 'sheepctl'
        self.namespace = namespace
        self.logging_format = logging_format

        self.__log = log(logging_format)
        self.__log_error = log_error(logging_format)

        self.__is_sheepctl_installed()

    def __is_sheepctl_installed(self):
        if not which(self.ctl):
            raise PrerequisitesError(f"{self.ctl} tool isn't installed")

    def create_user(self):
        cmd = f'{self.ctl} target set -n {self.namespace} -u shepherd.run'
        (status_code, resp, _) = self.__execute_cmd(cmd)
        if status_code != 0:
            raise ShepherdError(f'Error creating shepard user! \n {resp}')
        self.__log('User created successfully!')

    def create_lock(self, lock_file):
        cmd = f"{self.ctl} lock create -f {lock_file} --lifetime 72h"
        (status_code, resp, lock_id) = self.__execute_cmd(cmd, 'Lock request accepted with ID (.*?)$')
        if status_code != 0:
            raise ShepherdError(f'Error creating lock!\n {resp}')
        self.__log(f'Lock created with id: {lock_id}')
        return lock_id

    def get_lock(self, lock_id):
        self.__log('Requesting lock details!')
        namespace = self.namespace
        cmd = f'{self.ctl} lock get {lock_id} -n {namespace}'
        (status, out, error) = self.__execute_cmd_output(cmd)

        if status != 0:
            raise ShepherdError(f'GET LOCK: requesting lock details : `{lock_id}`\n Possibly the lock doesn\'t exist \n {error}')

        wrapper_divider = 'Retrieving lock\n'
        body_blocks = out.split(wrapper_divider)

        if len(body_blocks) != 2:
            raise ShepherdError(f'GET LOCK: inconsistent number of text blocks: \n {body_blocks}')

        access_divider = "Access Info:\n"
        details_blocks = body_blocks[1].split(access_divider)

        if len(details_blocks) != 2:
            print(f'GET LOCK: Lock must be failed: {lock_id}')
            lock_details = self.__parse_json(details_blocks[0])
            if lock_details.get('status') == 'failed':
                raise ShepherdError(f"GET LOCK: Lock isn't created successfully : {lock_id}")

        lock_details = yaml.load(details_blocks[1], Loader=yaml.FullLoader)

        return lock_details

    def __parse_json(self, out):
        payload = self.__wipe_json_response(out)
        return json.loads(payload)

    def create_namespace(self):
        ns_exists = self.get_namespace()

        if not ns_exists:
            self.__log("Namespace doesn't exist!")
            cmd = f'{self.ctl} namespace create'
            (status_code, out, error) = self.__execute_cmd_output(cmd)

            if status_code != 0:
                raise ShepherdError(f'Error creating shepard namespace! With code: {status_code},\n {error}', )

            self.__log('Namespace created successfully!')

    def get_namespace(self):
        cmd = f'{self.ctl} namespace get {self.namespace}'
        (exit_code, out, error) = self.__execute_cmd_output(cmd)

        if exit_code != 0:
            return False
        return True

    def __wipe_json_response(self, resp):
        ansi_escape = re.compile(r'''
                \x1B  # ESC
                (?:   # 7-bit C1 Fe (except CSI)
                [@-Z\\-_]
                |     # or [ for CSI, followed by a control sequence
                \[
                [0-?]*  # Parameter bytes
                [ -/]*  # Intermediate bytes
                [@-~]   # Final byte
            )
        ''', re.VERBOSE)

        result = ansi_escape.sub('', resp)
        result = re.sub(",[ \t\r\n]+}", "}", result)
        result = re.sub(",[ \t\r\n]+]", "]", result)

        return result

    def __execute_cmd_output(self, cmd):
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            shell=True,
            bufsize=-1,
            universal_newlines=True
        )
        self.__log(f'Execute command: {cmd}')

        out, error = process.communicate()
        status = process.returncode

        return status, out, error

    def __execute_cmd(self, cmd, find_pattern=None, output=True):
        found = None
        self.__log(f'Execute command: {cmd}')

        cmd = shlex.split(cmd)

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=-1,
            universal_newlines=True
        )
        stdout = io.TextIOWrapper(process.stdout.buffer, encoding='utf-8', errors='backslashreplace')
        resp = []
        for line in stdout:
            row = line.encode('utf-8', 'ignore').decode('utf-8')
            resp.append(row)

            if (find_pattern):
                m = re.search(find_pattern, row)

                if m:
                    found = m.group(1)

            if not self.logging_format:
                sys.stdout.write(row)
                sys.stdout.flush()

        stdout.close()

        rc = process.wait()
        return rc, resp, found
