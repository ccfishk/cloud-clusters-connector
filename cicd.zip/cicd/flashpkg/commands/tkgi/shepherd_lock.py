import operator

from functools import reduce

class ShepherdLock:
    def __init__(self, lock):
        self.lock = lock

    def find(self, path):
        return reduce(operator.getitem, path.split('.'), self.lock)

    def retrieve_proxy_ip(self):
        return self.find('network.http proxy.ip')

    def get_jumper_vm_host(self):
        ip = self.retrieve_proxy_ip()
        host = ip.split(':')[0]
        return host

    def generate_np0(self):
        t0_router_id = self.find('network.routers.t0-shared.id')

        fip_pool_ids_0 = self.find('network.routers.t0-shared.floating ip pools')[0]
        fip_pool_ids_1 = self.find('network.routers.t0-shared.floating ip pools')[1]

        pod_ip_block_ids_0 = self.find('network.routers.t0-shared.pod ip blocks')[0]
        pod_ip_block_ids_1 = self.find('network.routers.t0-shared.pod ip blocks')[1]

        return """{
                    "name": "np0",
                    "description": "Network Profile for Tanzu Service Mesh",
                    "parameters": {
                        "lb_size": "small",
                        "t0_router_id": "%s",
                        "fip_pool_ids": [
                            "%s",
                            "%s"
                        ],
                        "pod_ip_block_ids": [
                            "%s",
                            "%s"
                        ]
                    }
                }
        """ % (t0_router_id, fip_pool_ids_0, fip_pool_ids_1, pod_ip_block_ids_0, pod_ip_block_ids_1)
