class PrerequisitesError(Exception):
    pass

class ShepherdError(Exception):
    pass
