"""
Usage:
    flash tkgi create testbed [--username=<username> --logging-format=<logging-format>]
"""
import os
import tempfile
import sys
import traceback
import json

from pexpect import pxssh
from flashpkg.commands.tkgi.shepherd import Shepherd
from flashpkg.commands.tkgi.shepherd_lock import ShepherdLock
from flashpkg.commands.tkgi.ssh_executor import SSHExecutor
from flashpkg.commands.tkgi.errors import PrerequisitesError
from flashpkg.logging import log_error, log_result, log
from docopt import docopt

DEFAULT_USERNAME = 'tsm-systemtest'

def create_lock_file():
    json_tmpl = """
    {
        "recipe": {
            "fetcher": "git",
            "launcher": "vane",
            "source": "git@gitlab.eng.vmware.com:PKS/tooling/hack-nimbus.git",
            "symbol": "master",
            "data": {
                "esx-build": "ob-15847429",
                "vc-build": "ob-15952498",
                "nsxt-build": "ob-16404613",
                "path": "pks-dev-with-nsx-t",
                "size-profile": "large",
                "nsx-edge-clusters": "2",
                "pks-tile": "true",
                "opsman-url": "http://files.pks.eng.vmware.com/ci/artifacts/opsman/ops-manager-vsphere-2.9.9-build.164.ova",
                "pks-tile-url":     "http://files.pks.eng.vmware.com/ci/artifacts/pks/1.9.0/pivotal-container-service-1.9.0-build.32.pivotal",
                "pks-stemcell-url": "http://files.pks.eng.vmware.com/ci/artifacts/stemcell/bosh-stemcell-621.84-vsphere-esxi-ubuntu-xenial-go_agent.tgz"
            },
            "meta": {
                "nimbus_user": "svc.tsm-nimbus",
                "nimbus_location": "sc"
            }
        }
    }
    """

    try:
        fd1, lock_json = tempfile.mkstemp()
        with open(lock_json, 'w') as f:
            f.write(json_tmpl)
    finally:
        os.close(fd1)

    return lock_json

def requirements():
    ssh_username = os.environ.get("JUMPER_USERNAME")
    if not ssh_username:
        raise PrerequisitesError("JUMPER_USERNAME doesn\'t exist")

    ssh_password = os.environ.get("JUMPER_PASSWORD")
    if not ssh_password:
        raise PrerequisitesError("JUMPER_PASSWORD doesn\'t exist")

    return ssh_username, ssh_password

def create_testbed(username, logging_format):
    namespace = username or DEFAULT_USERNAME

    _log_error = log_error(logging_format)
    _log_result = log_result(logging_format)
    _log = log(logging_format)

    try:
        (ssh_username, ssh_password) = requirements()
    except PrerequisitesError as e:
        _log_error(str(e))
        return 1

    _log('TKGI: run testbed creating!')

    custom_lock_id = os.environ.get("TKGI_LOCK_ID")
    if custom_lock_id:
        _log(f'Running with custom lock ID: {custom_lock_id}')

    lock_json_path = create_lock_file()
    try:
        shepherd = Shepherd(namespace, logging_format)
        shepherd.create_user()
        shepherd.create_namespace()

        lock_id = shepherd.create_lock(lock_json_path) if not custom_lock_id else custom_lock_id
        loc_details = shepherd.get_lock(lock_id)

        shepherd_lock = ShepherdLock(loc_details)
        host = shepherd_lock.get_jumper_vm_host()

        content = shepherd_lock.generate_np0()

        ssh_executor = SSHExecutor(
            host,
            ssh_username,
            ssh_password,
            logging_format)
        ssh_executor.ssh_create_profile_file(content)
        ssh_executor.ssh_pks_login()
        ssh_executor.ssh_pks_create_namespace()

        _log_result({'jumper_vm': host})

    except json.JSONDecodeError as e:
        _log_error(f'JSON decode failed: {e}')
        return 1

    except pxssh.ExceptionPxssh as e:
        _log_error(f'Pxssh failed: {e}')
        return 1

    except PrerequisitesError as e:
        _log_error(str(e))
        return 1

    except Exception as e:
        _log_error(str(e))
        if not logging_format:
            traceback.print_exc()
        return 1

    finally:
        if lock_json_path:
            os.remove(lock_json_path)

    return 0

def process():
    if len(sys.argv) == 2:
        sys.argv.append('-h')

    args = docopt(__doc__)

    username = args['--username'] or DEFAULT_USERNAME
    logging_format = args['--logging-format']

    if args['create'] and args['testbed']:
        return create_testbed(username, logging_format)
