import sys

from flashpkg.logging import log, log_error
from pexpect import pxssh
from contextlib import contextmanager

def retry(times):
    def decorator(func):
        def fn(*args, **kwargs):
            attempt = 0
            while attempt < times:
                try:
                    return func(*args, **kwargs)
                except pxssh.ExceptionPxssh:
                    attempt += 1
            return func(*args, **kwargs)
        return fn
    return decorator


class SSHExecutor:
    def __init__(self, ssh_host, ssh_username, ssh_password, logging_format=None):
        self.ssh_host = ssh_host
        self.ssh_username = ssh_username
        self.ssh_password = ssh_password

        self.logging_format = logging_format
        self.__log = log(logging_format)
        self.__log_error = log_error(logging_format)

    @contextmanager
    def connect(self):
        s = pxssh.pxssh()
        if not self.logging_format:
            s.logfile_read = sys.stdout.buffer

        s.login(self.ssh_host, self.ssh_username, self.ssh_password)
        yield s
        s.close()

    def ssh_pks_login(self):
        cmd = 'pks login -a api.pks.local -u default -p default -k'
        with self.connect() as connection:
            connection.sendline(cmd)
            connection.expect('Login successful.')

    def ssh_create_profile_file(self, content):
        cmd = f'OUTPUT=$(cat <<\'EOF\'\n{content}\nEOF\n) && echo "$OUTPUT" > ~/np0.json && echo "file created"'
        with self.connect() as connection:
            connection.sendline(cmd)
            connection.expect('file created')

    def ssh_pks_create_namespace(self):
        cmd = 'pks create-network-profile np0.json'
        with self.connect() as connection:
            connection.sendline(cmd)
            result_expect_lines = [
                'Network profile np0 successfully created',
                'Error: The network profile named "np0" has already been created. Please use a different name.'
            ]

            namespace_expect = connection.expect(result_expect_lines)
            if namespace_expect == 0:
                self.__log('Network profile successfully created!')
            if namespace_expect == 1:
                self.__log('Network profile already created!')

    @retry(times=3)
    def ssh_add_host(self, master_ip, cluster_name):
        cmd = f'if grep -q \'{master_ip} {cluster_name}\' "/etc/hosts"; then echo 1; else sudo -- sh -c "echo \'{master_ip} {cluster_name}.local\' >> /etc/hosts" && echo 0; fi'
        with self.connect() as connection:
            connection.sendline(cmd)
            connection.prompt()
            self.__log(f'\n\'{master_ip} {cluster_name}.local\' added to /etc/hosts')

    @retry(times=3)
    def ssh_upsert_host(self, master_ip, cluster_name):
        cmd = f'''
            if grep -q '{master_ip} {cluster_name}' "/etc/hosts"
            then
                echo 'Record already exists'
            else
                if grep -q {master_ip} "/etc/hosts"
                then
                    echo 'IP exists'
                    sudo -- sh -c "sed -i_bak -e '/{master_ip}/d' /etc/hosts"
                    sudo -- sh -c "echo '{master_ip} {cluster_name}.local' >> /etc/hosts"
                else
                    echo 'No IP exists, insert full line'
                    sudo -- sh -c "echo '{master_ip} {cluster_name}.local' >> /etc/hosts"
                fi
            fi
        '''
        with self.connect() as connection:
            connection.sendline(cmd)
            connection.prompt()
            self.__log(f'\n\'{master_ip} {cluster_name}.local\' added to /etc/hosts')

    def ssh_remove_host(self, cluster_name):
        cmd = f"sudo sed -i_bak -e '/{cluster_name}\\.local/d' /etc/hosts"
        with self.connect() as connection:
            connection.sendline(cmd)
            connection.prompt()
            self.__log(f'\n\'{cluster_name}.local\' removed from /etc/hosts')
