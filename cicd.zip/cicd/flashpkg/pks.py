import os
import socket
import paramiko
import json
from flashpkg import utils, logging


def start(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    # return __cloud_start(*args)

    return __local_start(*args, **kwargs)


def cleanup(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    # return __cloud_cleanup(*args)

    return __local_cleanup(*args)


def list(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    #    return __cloud_status(*args)

    return __local_list(*args)


def envsetup(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    #   return __cloud_envsetup(*args, prefix=prefix)

    return __local_envsetup(*args)


def status(*args, **kwargs):
    # TODO: add support for cloud mode.
    # cloud = kwargs.get("cloud")
    # if cloud:
    #    return __cloud_status(*args)

    return __local_status(*args)

def upload_file(localfile, remotefile):
    try:
        jumper_vm = os.environ.get("JUMPER_VM")
        username = os.environ.get("JUMPER_USERNAME", 'kubo')
        password = os.environ.get("JUMPER_PASSWORD", 'Ponies!23')
        client = utils.ssh_setup(jumper_vm, username, password)
        ftp_client = client.open_sftp()
        ftp_client.put(localfile, remotefile)
    except paramiko.ssh_exception.AuthenticationException:
        print("Authentication failed to jumper host. Please check your credentials")
        raise
    except paramiko.ssh_exception.NoValidConnectionsError:
        print("Unable to connect to jumper_vm {}".format(jumper_vm))
        raise
    except socket.error:
        print("Unable to connect to jumper_vm {} within 30 seconds".format(jumper_vm))
        raise
    return 0

def execute_command(cmd, list=False, envsetup=False, output=False):
    status = 1
    try:
        jumper_vm = os.environ.get("JUMPER_VM")
        username = os.environ.get("JUMPER_USERNAME", 'kubo')
        password = os.environ.get("JUMPER_PASSWORD", 'Ponies!23')
        client = utils.ssh_setup(jumper_vm, username, password)
        login_cmd = "pks login -a  api.pks.local -u default -p default -k"
        sin, sout, serr = client.exec_command(login_cmd)
        status = sout.channel.recv_exit_status()
        if status != 0:
            print("Failed to authenticate with PKS cluster")
            for err in serr:
                print(err.strip('\n'))
            return status
        else:
            for out in sout:
                print(out.strip('\n'))
        sin, sout, serr = client.exec_command(cmd)
        status = sout.channel.recv_exit_status()
        if status != 0:
            print("Failed to execute command: ", cmd)
            for out in serr:
                print(out.strip('\n'))
        else:
            if list:
                print("\nPKS Clusters:")
            if envsetup:
                for err in serr:
                    print(err.strip('\n'))
                print("You need to run the command from the jumper_vm host")
            else:
                if output:
                    return sout.read().decode('ascii').strip("\n")
                for out in sout:
                    print(out.strip('\n'))
    except paramiko.ssh_exception.AuthenticationException:
        print("Authentication failed to jumper host. Please check your credentials")
        raise
    except paramiko.ssh_exception.NoValidConnectionsError:
        print("Unable to connect to jumper_vm {}".format(jumper_vm))
        raise
    except socket.error:
        print("Unable to connect to jumper_vm {} within 30 seconds".format(jumper_vm))
        raise

    return status

def __local_start(name, region, plan, workers, version, logging_format):
    log = logging.log(logging_format)
    log_error = logging.log_error(logging_format)

    log("Starting cluster on region {} with name {}, plan {} version {}".format(
        region, name, plan, version
    ))

    try:
        num_nodes = os.environ.get("PKS_WORKERS", workers)
        pks_plan = os.environ.get("PKS_PLAN", plan)
        cmd = "pks create-cluster {} -e {}.local --plan '{}' --network-profile np0 -n {} --wait".format(
            name, name, pks_plan, num_nodes)
        assert execute_command(cmd) == 0, log_error("Failed to create PKS cluster {}".format(name))
    except AssertionError as e:
        log_error("Failed to launch pks cluster: " + str(e))
        raise

    return 0


def __local_cleanup(name):
    print("Cleaning up cluster {}".format(name))
    try:
        cmd = "pks delete-cluster {} --non-interactive".format(name)
        assert execute_command(cmd) == 0, "Failed to delete PKS cluster {}".format(name)
    except AssertionError as e:
        print("Failed to delete pks cluster: " + str(e))
        raise

    return 0


def __local_list():
    try:
        cmd = "pks clusters"
        assert execute_command(cmd, list=True) == 0, "Failed to list PKS clusters"
    except AssertionError as e:
        print("Failed to list pks cluster: " + str(e))
        raise

    return 0


def __local_envsetup(name):
    try:
        cmd = "pks get-credentials {}".format(name)
        assert execute_command(cmd, envsetup=True) == 0, "Failed to get credentials for cluster {}".format(name)
    except AssertionError as e:
        print("Failed to get credentials for pks cluster: " + str(e))
        raise

    return 0


def __local_status(name):
    try:
        cmd = "pks cluster {}".format(name)
        assert execute_command(cmd) == 0, "Failed to get status of cluster {}".format(name)
    except AssertionError as e:
        print("Failed to get pks cluster status: " + str(e))
        raise

    return 0

def get_cluster_details_json(name):
    cmd = "pks cluster {} --json".format(name)
    details = execute_command(cmd, output=True)
    return json.loads(details)

def process(arg):
    cloud = arg.get('--cloud')
    if arg['start']:
        return start(
            arg['<name>'], arg['--instance'], arg['--worker'],
            arg['--authorization'], cloud=cloud)
    elif arg['cleanup']:
        return cleanup(arg['<name>'], cloud=cloud)
    elif arg['status']:
        return status(arg['<name>'], cloud=cloud)
    elif arg['list']:
        return list(cloud=cloud)
    elif arg['envsetup']:
        return envsetup(arg['<name>'], cloud=cloud)
