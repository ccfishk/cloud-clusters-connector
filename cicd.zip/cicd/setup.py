#!/usr/bin/env python3

from setuptools import setup

# To install the library, run the following
#
# ./setup.py install

setup(
    include_package_data=True,
    name='flash',
    setup_requires=['better-setuptools-git-version'],
    version_config={
        "version_format": "{tag}-{sha}",
    },
    zip_safe=False,
    description="NSX-SM Infrastructure CLI",
    author_email="sushils@vmware.com",
    author="Sushil Singh",
    keywords=["CI", "CD", "Cloud", "Jupyter"],
    install_requires=[
        "kubernetes==11.0.0",
        "boto3==1.14.22",
        "docker==3.7.2",
        "docopt==0.6.2",
        "PyYAML==5.1",
        "GitPython==2.1.11",
        "gitdb2==2.0.6",
        "setuptools==40.8.0",
        "configobj==5.0.6",
        "six==1.11.0",
        "Jinja2==2.10",
        "urllib3==1.24.2",
        "requests>=2.13.0",
        "prettytable==0.7.2",
        "cryptography==2.6.1",
        "paramiko>=2.5.0",
        "deepdiff==4.0.6",
        "deprecation==2.1.0",
        "pyjwt==1.7.1",
        "python-dateutil==2.8.1",
        "pexpect==4.8.0",
        "bullet==2.2.0",
        "python-dynamodb-lock==0.9.1"
    ],
    extras_require={
        "extras": [
            "IPython[extras]==4.2.1",
            "ipykernel[extras]==4.5.1",
            "jupyter[extras]==1.0.0",
            "jupyter-console[extras]==5.2.0",
            "matplotlib[extras]==2.0.0"
        ]
    },
    packages=['flashpkg',
              'flashpkg/aws',
              'flashpkg/aws/dynamodb',
              'flashpkg/aws/dynamodb/models',
              'flashpkg/aws/dynamodb/services',
              'flashpkg/aws/dynamodb/services/cluster_pool',
              'flashpkg/aws/dynamodb/services/cluster_pool/mixins',
              'flashpkg/infra',
              'flashpkg/platforms',
              'flashpkg/commands',
              'flashpkg/commands/tkgi',
              'tsm',
              'tsm/platform'
              ],
    scripts=['scripts/flash'],
    data_files=[('flashpkg/config', ['flashpkg/config/flash_cloud.pem']),
                ('flashpkg/config', ['flashpkg/config/cf-deployment.yml']),
                ('flashpkg/config', ['flashpkg/config/aws.yml']),
                ('flashpkg/config', ['flashpkg/config/buildspec.yml.tmpl']),
                ('flashpkg/config',
                 ['flashpkg/config/use-compiled-releases.yml']),
                ('flashpks/aws', ['flashpkg/aws/additionalPolicies.yaml']),
                ('flashpks/aws', ['flashpkg/aws/additionalPolicies.json']),
                ('flashpks/aws', ['flashpkg/aws/clusterWithIRSA.tmpl.yaml']),
                ('flashpkg', ['flashpkg/.flash.conf']),
                ('flashpkg', ['flashpkg/.flash.state.conf'])],
    classifiers=[
        "Topic :: Utilities",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
    ]
)
